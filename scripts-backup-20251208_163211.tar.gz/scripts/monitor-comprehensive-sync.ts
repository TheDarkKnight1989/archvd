#!/usr/bin/env npx tsx
/**
 * Real-time monitor for comprehensive cleanup and sync
 * Shows live progress updates every 10 seconds
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function monitor() {
  console.clear()
  console.log('╔═══════════════════════════════════════════════════════════════════════╗')
  console.log('║          Comprehensive Sync - Real-Time Progress Monitor             ║')
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n')

  // Get current database state
  const { data: allData } = await supabase
    .from('master_market_data')
    .select('provider_product_id, sku, region_code, size_key, lowest_ask, is_flex, is_consigned, provider_source, created_at')
    .eq('provider', 'stockx')

  const totalRows = allData?.length || 0
  const uniqueProducts = new Set(allData?.map(r => r.provider_product_id))
  const uniqueCombinations = new Set(
    allData?.map(r => `${r.provider_product_id}|${r.region_code}|${r.size_key}|${r.is_flex}|${r.is_consigned}|${r.provider_source}`)
  )

  const hasDuplicates = uniqueCombinations.size !== totalRows

  console.log(`📊 Current Database State (${new Date().toLocaleTimeString()})\n`)
  console.log(`   Total rows:          ${totalRows}`)
  console.log(`   Unique products:     ${uniqueProducts.size}/125 (${((uniqueProducts.size / 125) * 100).toFixed(1)}%)`)
  console.log(`   Unique combinations: ${uniqueCombinations.size}`)
  console.log(`   Has duplicates:      ${hasDuplicates ? '❌ YES' : '✅ NO'}`)

  // Check region coverage
  const productRegions = new Map<string, Set<string>>()
  allData?.forEach(row => {
    if (!productRegions.has(row.provider_product_id)) {
      productRegions.set(row.provider_product_id, new Set())
    }
    productRegions.get(row.provider_product_id)!.add(row.region_code)
  })

  let fullCoverage = 0
  let partialCoverage = 0
  productRegions.forEach((regions) => {
    if (regions.size === 3) {
      fullCoverage++
    } else {
      partialCoverage++
    }
  })

  console.log(`\n🌍 Region Coverage:\n`)
  console.log(`   Full (3 regions):    ${fullCoverage} products`)
  console.log(`   Partial:             ${partialCoverage} products`)

  // Check data quality
  const pricesInCents = allData?.filter(r => r.lowest_ask && r.lowest_ask >= 1000).length || 0
  const pricesInDollars = allData?.filter(r => r.lowest_ask && r.lowest_ask < 1000 && r.lowest_ask > 0).length || 0

  console.log(`\n💰 Price Format:\n`)
  console.log(`   In cents (≥1000):    ${pricesInCents} rows ${pricesInCents > 0 ? '✅' : ''}`)
  console.log(`   In dollars (<1000):  ${pricesInDollars} rows ${pricesInDollars > 0 ? '❌' : '✅'}`)

  // Get recent products (last 5 minutes)
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString()
  const recentProducts = new Set(
    allData?.filter(r => r.created_at >= fiveMinutesAgo).map(r => r.provider_product_id)
  )

  console.log(`\n🔄 Recent Activity (last 5 min):\n`)
  console.log(`   Products synced:     ${recentProducts.size}`)

  if (recentProducts.size > 0) {
    const recentSkus = new Set(
      allData?.filter(r => r.created_at >= fiveMinutesAgo).map(r => r.sku)
    )
    console.log(`   Latest SKUs:         ${Array.from(recentSkus).slice(0, 5).join(', ')}`)
  }

  // Estimate time remaining
  if (recentProducts.size > 0) {
    const productsRemaining = 125 - uniqueProducts.size
    const productsPerMinute = recentProducts.size / 5
    const minutesRemaining = productsRemaining / productsPerMinute

    console.log(`\n⏱️  Estimated Time:\n`)
    console.log(`   Products remaining:  ${productsRemaining}`)
    console.log(`   Rate:                ${productsPerMinute.toFixed(1)} products/min`)
    console.log(`   Time remaining:      ~${Math.ceil(minutesRemaining)} minutes`)
  }

  // Overall quality score
  console.log(`\n` + '═'.repeat(75))

  const isComplete = uniqueProducts.size === 125
  const noDuplicates = !hasDuplicates
  const allPricesInCents = pricesInDollars === 0
  const fullRegionCoverage = partialCoverage === 0

  if (isComplete && noDuplicates && allPricesInCents && fullRegionCoverage) {
    console.log(`✅ PERFECT - 100% complete with perfect data quality!`)
  } else if (uniqueProducts.size >= 50) {
    const qualityScore = [noDuplicates, allPricesInCents, fullRegionCoverage].filter(Boolean).length
    console.log(`🟡 IN PROGRESS - ${uniqueProducts.size}/125 products (${qualityScore}/3 quality checks passed)`)
  } else {
    console.log(`🟡 STARTING UP - ${uniqueProducts.size}/125 products synced`)
  }

  console.log('═'.repeat(75) + '\n')
}

// Run monitoring loop
async function monitorLoop() {
  while (true) {
    await monitor()
    console.log('Refreshing in 10 seconds... (Ctrl+C to stop)\n')
    await new Promise(resolve => setTimeout(resolve, 10000))
  }
}

monitorLoop().catch(console.error)
