#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function debug() {
  console.log('═══════════════════════════════════════════════════════════');
  console.log('DEBUGGING: Why only 52 SKUs when log says 125?');
  console.log('═══════════════════════════════════════════════════════════\n');

  // Get all StockX data with timestamps
  const { data: stockxData, count } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact' })
    .eq('provider', 'stockx')
    .order('created_at', { ascending: false });

  console.log(`Total StockX rows: ${count}`);

  if (stockxData && stockxData.length > 0) {
    const uniqueSkus = new Set(stockxData.map(r => r.sku));
    console.log(`Unique SKUs: ${uniqueSkus.size}`);
    console.log(`\nMost recent entry: ${stockxData[0].created_at}`);
    console.log(`Oldest entry: ${stockxData[stockxData.length - 1].created_at}`);

    // Show all unique SKUs
    console.log(`\nAll ${uniqueSkus.size} SKUs in database:`);
    Array.from(uniqueSkus).sort().forEach((sku, i) => {
      console.log(`${i + 1}. ${sku}`);
    });
  }

  // Check raw snapshots table
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('Checking raw_stockx_market_snapshots...');

  const { count: snapshotCount } = await supabase
    .from('raw_stockx_market_snapshots')
    .select('*', { count: 'exact', head: true });

  console.log(`Raw snapshots: ${snapshotCount || 0}`);
}

debug();
