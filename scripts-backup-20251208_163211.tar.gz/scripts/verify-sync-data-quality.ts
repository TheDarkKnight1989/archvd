#!/usr/bin/env npx tsx
/**
 * Verify Data Quality of Recent Sync
 * Check for nulls, missing fields, data completeness
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🔍 Verifying Sync Data Quality\n')

  // Check StockX data from recent sync (last 10 minutes)
  const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString()

  const { data: stockxData, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')
    .gte('snapshot_at', tenMinutesAgo)

  if (error) {
    console.error('❌ Failed to fetch data:', error.message)
    return
  }

  console.log(`📦 Found ${stockxData?.length || 0} StockX snapshots from recent sync\n`)

  if (!stockxData || stockxData.length === 0) {
    console.log('⚠️  No recent StockX data found')
    return
  }

  // Data Quality Checks
  let nullLowestAsk = 0
  let nullHighestBid = 0
  let nullLastSale = 0
  let missingSize = 0
  let missingSku = 0
  let missingCurrency = 0
  let validRecords = 0

  for (const record of stockxData) {
    let isValid = true

    if (!record.lowest_ask) nullLowestAsk++
    if (!record.highest_bid) nullHighestBid++
    if (!record.last_sale_price) nullLastSale++
    if (!record.size_key && !record.size_numeric) {
      missingSize++
      isValid = false
    }
    if (!record.sku) {
      missingSku++
      isValid = false
    }
    if (!record.currency_code) {
      missingCurrency++
      isValid = false
    }

    if (isValid && (record.lowest_ask || record.highest_bid || record.last_sale_price)) {
      validRecords++
    }
  }

  console.log('📊 Data Quality Report:\n')
  console.log('Critical Fields (must exist):')
  console.log(`  ✅ Has SKU: ${stockxData.length - missingSku}/${stockxData.length}`)
  console.log(`  ✅ Has Size: ${stockxData.length - missingSize}/${stockxData.length}`)
  console.log(`  ✅ Has Currency: ${stockxData.length - missingCurrency}/${stockxData.length}`)

  console.log('\nPrice Fields (at least one should exist):')
  console.log(`  📈 Has Lowest Ask: ${stockxData.length - nullLowestAsk}/${stockxData.length}`)
  console.log(`  📉 Has Highest Bid: ${stockxData.length - nullHighestBid}/${stockxData.length}`)
  console.log(`  💰 Has Last Sale: ${stockxData.length - nullLastSale}/${stockxData.length}`)

  console.log('\nOverall Quality:')
  console.log(`  ✅ Valid Records: ${validRecords}/${stockxData.length}`)
  console.log(`  ❌ Invalid Records: ${stockxData.length - validRecords}/${stockxData.length}`)
  console.log(`  📈 Quality Rate: ${((validRecords / stockxData.length) * 100).toFixed(1)}%`)

  // Check unique products synced
  const uniqueSkus = new Set(stockxData.map(r => r.sku))
  console.log(`\n📦 Unique Products: ${uniqueSkus.size}`)

  // Sample a few records to show structure
  console.log('\n🔍 Sample Records (first 3):')
  stockxData.slice(0, 3).forEach((record, i) => {
    console.log(`\n${i + 1}. ${record.sku} - Size ${record.size_key || record.size_numeric}`)
    console.log(`   Lowest Ask: ${record.lowest_ask || 'null'}`)
    console.log(`   Highest Bid: ${record.highest_bid || 'null'}`)
    console.log(`   Last Sale: ${record.last_sale_price || 'null'}`)
    console.log(`   Currency: ${record.currency_code}`)
    console.log(`   Region: ${record.region_code}`)
  })

  // Overall verdict
  console.log('\n' + '='.repeat(80))
  if (validRecords === stockxData.length) {
    console.log('✅ ALL RECORDS VALID - 100% data quality')
  } else if (validRecords / stockxData.length > 0.95) {
    console.log('✅ EXCELLENT - >95% data quality')
  } else if (validRecords / stockxData.length > 0.8) {
    console.log('⚠️  GOOD - >80% data quality, but some issues')
  } else {
    console.log('❌ POOR - <80% data quality, needs attention')
  }
}

main().catch(console.error)
