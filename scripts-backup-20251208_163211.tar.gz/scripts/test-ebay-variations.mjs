#!/usr/bin/env node

/**
 * Test eBay two-step API to see variation data
 */

import 'dotenv/config'
import { EbayClient } from '../src/lib/services/ebay/client.js'
import { enrichEbaySoldItem } from '../src/lib/services/ebay/extractors.js'

const SKU = process.argv[2] || 'DZ4137-700'

console.log('\n' + '='.repeat(80))
console.log('eBay Variation Detection Test - ' + SKU)
console.log('='.repeat(80) + '\n')

console.log('Fetching from eBay with two-step API...\n')

const client = new EbayClient()

const result = await client.searchSold({
  query: SKU,
  limit: 50,
  conditionIds: [1000, 1500, 1750],
  qualifiedPrograms: ['AUTHENTICITY_GUARANTEE'],
  categoryIds: ['15709', '95672', '155194'],
  soldItemsOnly: true,
  fetchFullDetails: true, // Two-step API
})

console.log('Fetched ' + result.items.length + ' items\n')
console.log('Full details fetched: ' + result.fullDetailsFetched + '\n')

if (result.items.length === 0) {
  console.log('No items returned')
  process.exit(0)
}

// Enrich all items
result.items.forEach((item) => {
  enrichEbaySoldItem(item)
})

// Show first 3 items in detail
console.log('='.repeat(80))
console.log('SAMPLE ITEMS (First 3)')
console.log('='.repeat(80) + '\n')

result.items.slice(0, 3).forEach((item, i) => {
  console.log((i + 1) + '. ' + item.title)
  console.log('   Price: ' + item.currency + ' ' + item.price)
  console.log('   Condition: ' + item.conditionId)
  console.log('   AG: ' + (item.authenticityVerification ? 'YES' : 'NO'))

  if (item.variations && item.variations.length > 0) {
    console.log('   Has ' + item.variations.length + ' variation(s)')
    if (item.variations[0].localizedAspects) {
      console.log('   Variation aspects:')
      item.variations[0].localizedAspects.forEach((aspect) => {
        console.log('     - ' + aspect.name + ': ' + aspect.value)
      })
    }
  } else {
    console.log('   No variations (will parse title)')
  }

  if (item.sizeInfo) {
    console.log('   EXTRACTED:')
    console.log('     Size: ' + item.sizeInfo.normalizedKey)
    console.log('     System: ' + item.sizeInfo.system)
    console.log('     Confidence: ' + item.sizeInfo.confidence)
  } else {
    console.log('   EXTRACTED: No size found')
  }

  console.log()
})

// Analyze confidence
console.log('='.repeat(80))
console.log('CONFIDENCE BREAKDOWN')
console.log('='.repeat(80) + '\n')

const byConf = {}
result.items.forEach((item) => {
  const conf = item.sizeInfo?.confidence || 'NONE'
  byConf[conf] = (byConf[conf] || 0) + 1
})

Object.entries(byConf).forEach(([conf, count]) => {
  console.log(conf + ': ' + count)
})

// Analyze size systems
console.log('\n' + '='.repeat(80))
console.log('SIZE SYSTEM BREAKDOWN')
console.log('='.repeat(80) + '\n')

const bySys = {}
result.items
  .filter((i) => i.sizeInfo)
  .forEach((item) => {
    const sys = item.sizeInfo.system
    bySys[sys] = (bySys[sys] || 0) + 1
  })

Object.entries(bySys).forEach(([sys, count]) => {
  console.log(sys + ': ' + count)
})

// Show what would be included
console.log('\n' + '='.repeat(80))
console.log('INCLUSION ANALYSIS')
console.log('='.repeat(80) + '\n')

const included = result.items.filter((item) => {
  return (
    item.conditionId === 1000 &&
    item.authenticityVerification &&
    item.sizeInfo &&
    item.sizeInfo.system !== 'UNKNOWN' &&
    item.sizeInfo.confidence === 'HIGH'
  )
})

console.log('Total items: ' + result.items.length)
console.log('Would be INCLUDED: ' + included.length)
console.log('Would be EXCLUDED: ' + (result.items.length - included.length))

console.log('\n' + '='.repeat(80) + '\n')
