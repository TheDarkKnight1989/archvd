import { refreshStockxMarketData } from '@/lib/services/stockx/market-refresh'

const STOCKX_PRODUCT_ID = '15795a80-5cc8-4d2d-9ed0-20250d83be7f'

async function main() {
  console.log('Testing StockX market refresh for product:', STOCKX_PRODUCT_ID)

  const result = await refreshStockxMarketData(undefined, STOCKX_PRODUCT_ID, 'USD')

  console.log('\nResult:', JSON.stringify(result, null, 2))
}

main().catch(console.error)
