#!/usr/bin/env npx tsx
/**
 * Check Mapping Status - Verify dual mapping and uniqueness
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('\n📊 MAPPING STATUS VERIFICATION')
  console.log('='.repeat(80))

  // Check for duplicate StockX mappings
  const { data: variants } = await supabase
    .from('product_variants')
    .select('stockx_product_id')
    .not('stockx_product_id', 'is', null)

  const idCounts = new Map<string, number>()
  variants?.forEach(v => {
    const id = v.stockx_product_id
    idCounts.set(id, (idCounts.get(id) || 0) + 1)
  })

  const duplicates = Array.from(idCounts.entries()).filter(([_, count]) => count > 1)

  console.log(`\nStockX Mapping Check:`)
  console.log(`  Total variants with StockX IDs: ${variants?.length || 0}`)
  console.log(`  Unique StockX product IDs: ${idCounts.size}`)

  if (duplicates.length > 0) {
    console.log(`\n  ❌ DUPLICATES FOUND:`)
    duplicates.forEach(([id, count]) => {
      console.log(`     ${id}: ${count} products`)
    })
  } else {
    console.log(`  ✅ All mappings are UNIQUE - no duplicates!`)
  }

  // Check dual mapping status
  const { data: products } = await supabase
    .from('products')
    .select(`
      id,
      sku,
      product_variants (
        alias_catalog_id,
        stockx_product_id
      )
    `)

  let bothMapped = 0
  let aliasOnly = 0
  let stockxOnly = 0
  let neitherMapped = 0

  products?.forEach((p: any) => {
    const hasAlias = p.product_variants.some((v: any) => v.alias_catalog_id)
    const hasStockX = p.product_variants.some((v: any) => v.stockx_product_id)

    if (hasAlias && hasStockX) bothMapped++
    else if (hasAlias) aliasOnly++
    else if (hasStockX) stockxOnly++
    else neitherMapped++
  })

  console.log(`\nDual Mapping Status:`)
  console.log(`  Total products: ${products?.length || 0}`)
  console.log(`  ✅ Both Alias + StockX: ${bothMapped}`)
  console.log(`  📍 Alias only: ${aliasOnly}`)
  console.log(`  🟢 StockX only: ${stockxOnly}`)
  console.log(`  ❌ Neither mapped: ${neitherMapped}`)
  console.log('')
}

main().catch(console.error)
