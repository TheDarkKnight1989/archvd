/**
 * Show consigned vs non-consigned pricing for FV5029-010
 */

import { createAliasClient } from '@/lib/services/alias/client'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS CONSIGNED VS NON-CONSIGNED PRICING')
  console.log('SKU:', SKU)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()

  // Search for product
  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const product = searchResults.catalog_items[0]

  console.log(`Product: ${product.name}`)
  console.log(`Catalog ID: ${product.catalog_id}\n`)

  // Get all pricing variants
  const availabilities = await client.listPricingInsights(product.catalog_id)

  console.log(`Total variants: ${availabilities.variants.length}\n`)

  // Group by consignment status and condition
  const consignedVariants = availabilities.variants.filter(v => v.consigned === true)
  const nonConsignedVariants = availabilities.variants.filter(v => v.consigned === false || v.consigned === undefined)
  const newGoodVariants = availabilities.variants.filter(v =>
    v.product_condition === 'PRODUCT_CONDITION_NEW' &&
    v.packaging_condition === 'PACKAGING_CONDITION_GOOD_CONDITION'
  )

  console.log('BREAKDOWN:')
  console.log(`  Consigned (consigned=true): ${consignedVariants.length}`)
  console.log(`  Non-consigned (consigned=false/undefined): ${nonConsignedVariants.length}`)
  console.log(`  NEW + GOOD_CONDITION (standard filter): ${newGoodVariants.length}\n`)

  // Show consigned variants if any exist
  if (consignedVariants.length > 0) {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('CONSIGNED VARIANTS')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    for (const variant of consignedVariants) {
      console.log(`Size ${variant.size}:`)
      console.log(`  Condition: ${variant.product_condition}`)
      console.log(`  Packaging: ${variant.packaging_condition}`)
      console.log(`  Consigned: ${variant.consigned}`)
      if (variant.availability) {
        console.log(`  Lowest Ask: $${variant.availability.lowest_listing_price_cents ? parseInt(variant.availability.lowest_listing_price_cents) / 100 : 0}`)
        console.log(`  Highest Bid: $${variant.availability.highest_offer_price_cents ? parseInt(variant.availability.highest_offer_price_cents) / 100 : 0}`)
        console.log(`  Last Sale: $${variant.availability.last_sold_listing_price_cents ? parseInt(variant.availability.last_sold_listing_price_cents) / 100 : 0}`)
      }
      console.log()
    }
  } else {
    console.log('⚠️  NO CONSIGNED VARIANTS FOUND\n')
    console.log('This could mean:')
    console.log('  1. This product has no consigned listings currently')
    console.log('  2. Alias API doesn\'t return consigned flag for this product')
    console.log('  3. We need to pass a parameter to get consigned data\n')
  }

  // Show first few NEW + GOOD variants with their consignment flag
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STANDARD VARIANTS (NEW + GOOD_CONDITION)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const standardVariants = newGoodVariants.slice(0, 10)
  for (const variant of standardVariants) {
    console.log(`Size ${variant.size}:`)
    console.log(`  Consigned flag: ${variant.consigned === true ? 'TRUE' : variant.consigned === false ? 'FALSE' : 'UNDEFINED'}`)
    if (variant.availability) {
      console.log(`  Ask: $${variant.availability.lowest_listing_price_cents ? parseInt(variant.availability.lowest_listing_price_cents) / 100 : 0} | Bid: $${variant.availability.highest_offer_price_cents ? parseInt(variant.availability.highest_offer_price_cents) / 100 : 0} | Last: $${variant.availability.last_sold_listing_price_cents ? parseInt(variant.availability.last_sold_listing_price_cents) / 100 : 0}`)
    }
    console.log()
  }

  // Try fetching with consigned=true filter
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('TESTING: Fetch with consigned=true filter')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  try {
    const consignedOnly = await client.listPricingInsights(product.catalog_id, undefined, true)
    console.log(`✅ Success! Found ${consignedOnly.variants.length} variants with consigned=true filter`)
    console.log()

    if (consignedOnly.variants.length > 0) {
      console.log('Sample consigned variants:')
      for (const variant of consignedOnly.variants.slice(0, 5)) {
        console.log(`  Size ${variant.size}: consigned=${variant.consigned}, Ask=$${variant.availability?.lowest_listing_price_cents ? parseInt(variant.availability.lowest_listing_price_cents) / 100 : 0}`)
      }
      console.log()
    }
  } catch (error: any) {
    console.log(`❌ Failed: ${error.message}\n`)
  }

  // Try fetching with consigned=false filter
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('TESTING: Fetch with consigned=false filter')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  try {
    const nonConsignedOnly = await client.listPricingInsights(product.catalog_id, undefined, false)
    console.log(`✅ Success! Found ${nonConsignedOnly.variants.length} variants with consigned=false filter`)
    console.log()

    if (nonConsignedOnly.variants.length > 0) {
      console.log('Sample non-consigned variants:')
      for (const variant of nonConsignedOnly.variants.slice(0, 5)) {
        console.log(`  Size ${variant.size}: consigned=${variant.consigned}, Ask=$${variant.availability?.lowest_listing_price_cents ? parseInt(variant.availability.lowest_listing_price_cents) / 100 : 0}`)
      }
      console.log()
    }
  } catch (error: any) {
    console.log(`❌ Failed: ${error.message}\n`)
  }

  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
