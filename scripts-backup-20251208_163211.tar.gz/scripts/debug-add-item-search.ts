/**
 * Self-Check Script: Add Item Search Pairing Validation
 *
 * PHASE 4: Validates that generic SKU normalization and pairing works correctly
 *
 * Test Strategy:
 * 1. Test with diverse queries (jordan 1/4/11/15, air max 1/90, specific SKUs)
 * 2. For each query:
 *    - Call raw StockX API
 *    - Call raw Alias API
 *    - Build canonical SKU maps from both
 *    - Call merged /api/add-item/search endpoint
 *    - Assert: if canonicalSku in BOTH raw results → MUST be in merged with hasStockx=true and hasAlias=true
 *    - Log any pairing errors
 *
 * Run: npx tsx scripts/debug-add-item-search.ts
 */

import { StockxCatalogService } from '../src/lib/services/stockx/catalog'
import { createAliasClient } from '../src/lib/services/alias'
import { normalizeSkuForMatching } from '../src/lib/sku/normalizeSkuForMatching'

// Test queries covering diverse sneaker types
const TEST_QUERIES = [
  // Name searches
  { query: 'jordan 1', type: 'name', expected: 'high volume' },
  { query: 'jordan 4', type: 'name', expected: 'high volume' },
  { query: 'jordan 11', type: 'name', expected: 'high volume' },
  { query: 'jordan 15', type: 'name', expected: 'moderate volume' },
  { query: 'air max 1', type: 'name', expected: 'high volume' },
  { query: 'air max 90', type: 'name', expected: 'high volume' },

  // SKU searches (if available)
  { query: 'DZ5485-410', type: 'sku', expected: 'exact match' },
  { query: 'DD1391-100', type: 'sku', expected: 'exact match' },
  { query: 'IH0296-400', type: 'sku', expected: 'exact match' },
]

interface RawResult {
  stockx: any[]
  alias: any[]
  canonicalMap: Map<string, { stockx: any; alias: any | null }>
}

interface ValidationResult {
  query: string
  passed: boolean
  errors: string[]
  warnings: string[]
  stats: {
    stockxCount: number
    aliasCount: number
    bothCount: number
    mergedCount: number
    matchedCount: number
    missedPairings: number
  }
}

async function fetchRawStockX(query: string, limit: number = 10): Promise<any[]> {
  try {
    const catalogService = new StockxCatalogService()
    const results = await catalogService.searchProducts(query, {
      limit: limit, // Use same limit as merged endpoint for fair comparison
      currencyCode: 'GBP',
    })
    return results || []
  } catch (error: any) {
    console.error('[Test] StockX search failed:', error.message)
    return []
  }
}

async function fetchRawAlias(query: string, limit: number = 10): Promise<any[]> {
  try {
    const aliasClient = createAliasClient()
    const response = await aliasClient.searchCatalog(query, {
      limit: limit, // Use same limit as merged endpoint for fair comparison
    })
    return response.catalog_items || []
  } catch (error: any) {
    console.error('[Test] Alias search failed:', error.message)
    return []
  }
}

async function fetchMergedEndpoint(query: string, limit: number = 10): Promise<any> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
    const response = await fetch(`${baseUrl}/api/add-item/search?q=${encodeURIComponent(query)}&limit=${limit}`)

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }

    return await response.json()
  } catch (error: any) {
    console.error('[Test] Merged endpoint failed:', error.message)
    return { results: [] }
  }
}

function buildCanonicalMaps(stockxResults: any[], aliasResults: any[]): Map<string, { stockx: any; alias: any | null }> {
  const map = new Map<string, { stockx: any; alias: any | null }>()

  // Add StockX results
  for (const product of stockxResults) {
    const canonical = normalizeSkuForMatching(product.styleId)
    if (canonical === null) continue

    if (!map.has(canonical)) {
      map.set(canonical, { stockx: product, alias: null })
    }
  }

  // Add Alias results
  for (const item of aliasResults) {
    if (!item.sku) continue

    const canonical = normalizeSkuForMatching(item.sku)
    if (canonical === null) continue

    const existing = map.get(canonical)
    if (existing) {
      existing.alias = item
    } else {
      map.set(canonical, { stockx: null, alias: item })
    }
  }

  return map
}

async function validateQuery(query: string): Promise<ValidationResult> {
  console.log(`\n${'='.repeat(80)}`)
  console.log(`Testing query: "${query}"`)
  console.log('='.repeat(80))

  const result: ValidationResult = {
    query,
    passed: true,
    errors: [],
    warnings: [],
    stats: {
      stockxCount: 0,
      aliasCount: 0,
      bothCount: 0,
      mergedCount: 0,
      matchedCount: 0,
      missedPairings: 0,
    }
  }

  // Step 1: Fetch raw data
  console.log('\n[1/3] Fetching raw API data...')
  const [stockxResults, aliasResults] = await Promise.all([
    fetchRawStockX(query),
    fetchRawAlias(query),
  ])

  result.stats.stockxCount = stockxResults.length
  result.stats.aliasCount = aliasResults.length

  console.log(`  StockX: ${stockxResults.length} results`)
  console.log(`  Alias:  ${aliasResults.length} results`)

  // Step 2: Build canonical maps
  console.log('\n[2/3] Building canonical SKU maps...')
  const canonicalMap = buildCanonicalMaps(stockxResults, aliasResults)

  // Count items in both
  const bothCanonicalSkus = new Set<string>()
  for (const [canonical, { stockx, alias }] of canonicalMap) {
    if (stockx && alias) {
      bothCanonicalSkus.add(canonical)
      result.stats.bothCount++
    }
  }

  console.log(`  Canonical SKUs in BOTH: ${bothCanonicalSkus.size}`)

  if (bothCanonicalSkus.size > 0) {
    console.log(`  Examples:`)
    let count = 0
    for (const canonical of bothCanonicalSkus) {
      if (count >= 3) break
      const { stockx, alias } = canonicalMap.get(canonical)!
      console.log(`    - ${canonical}: "${stockx.styleId}" (StockX) ↔ "${alias.sku}" (Alias)`)
      count++
    }
  }

  // Step 3: Fetch merged endpoint
  console.log('\n[3/3] Fetching merged endpoint...')
  const mergedResponse = await fetchMergedEndpoint(query)
  const mergedResults = mergedResponse.results || []

  result.stats.mergedCount = mergedResults.length
  console.log(`  Merged: ${mergedResults.length} results`)

  // Step 4: Validation - check that all "both" items are in merged with correct flags
  console.log('\n[Validation] Checking pairing completeness...')

  for (const canonical of bothCanonicalSkus) {
    // Find this canonical SKU in merged results
    const mergedRow = mergedResults.find((row: any) => {
      const rowCanonical = normalizeSkuForMatching(row.styleId)
      return rowCanonical === canonical
    })

    if (!mergedRow) {
      result.errors.push(
        `❌ PAIRING ERROR: Canonical SKU "${canonical}" exists in BOTH raw results but NOT in merged results`
      )
      result.stats.missedPairings++
      result.passed = false
    } else {
      // Check flags
      if (!mergedRow.hasStockx) {
        result.errors.push(
          `❌ FLAG ERROR: Canonical SKU "${canonical}" has hasStockx=false but should be true`
        )
        result.passed = false
      }
      if (!mergedRow.hasAlias) {
        result.warnings.push(
          `⚠️  FLAG WARNING: Canonical SKU "${canonical}" has hasAlias=false but should be true (may need second-pass lookup)`
        )
      } else {
        result.stats.matchedCount++
      }
    }
  }

  // Summary
  console.log('\n[Summary]')
  console.log(`  Items in BOTH raw results: ${bothCanonicalSkus.size}`)
  console.log(`  Items correctly paired in merged: ${result.stats.matchedCount}`)
  console.log(`  Missed pairings: ${result.stats.missedPairings}`)
  console.log(`  Pairing success rate: ${bothCanonicalSkus.size > 0 ? Math.round((result.stats.matchedCount / bothCanonicalSkus.size) * 100) : 0}%`)

  if (result.errors.length > 0) {
    console.log('\n❌ ERRORS:')
    result.errors.forEach(err => console.log(`  ${err}`))
  }

  if (result.warnings.length > 0) {
    console.log('\n⚠️  WARNINGS:')
    result.warnings.forEach(warn => console.log(`  ${warn}`))
  }

  if (result.passed && result.warnings.length === 0) {
    console.log('\n✅ PASSED: All items correctly paired!')
  } else if (result.passed) {
    console.log('\n✅ PASSED: Critical tests passed (some warnings)')
  } else {
    console.log('\n❌ FAILED: Critical errors detected')
  }

  return result
}

async function main() {
  console.log('┌' + '─'.repeat(78) + '┐')
  console.log('│' + ' '.repeat(78) + '│')
  console.log('│' + '  ADD ITEM SEARCH PAIRING VALIDATION'.padEnd(78) + '│')
  console.log('│' + '  Phase 4: Self-Check Script'.padEnd(78) + '│')
  console.log('│' + ' '.repeat(78) + '│')
  console.log('└' + '─'.repeat(78) + '┘')

  const results: ValidationResult[] = []

  // Run tests sequentially to avoid rate limiting
  for (const testCase of TEST_QUERIES) {
    const result = await validateQuery(testCase.query)
    results.push(result)

    // Wait between tests to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 1000))
  }

  // Final summary
  console.log('\n\n' + '='.repeat(80))
  console.log('FINAL SUMMARY')
  console.log('='.repeat(80))

  const totalTests = results.length
  const passedTests = results.filter(r => r.passed).length
  const failedTests = totalTests - passedTests

  console.log(`\nTotal tests: ${totalTests}`)
  console.log(`Passed: ${passedTests} ✅`)
  console.log(`Failed: ${failedTests} ❌`)
  console.log(`Success rate: ${Math.round((passedTests / totalTests) * 100)}%`)

  console.log('\nPer-query results:')
  for (const result of results) {
    const status = result.passed ? '✅' : '❌'
    const pairingRate = result.stats.bothCount > 0
      ? Math.round((result.stats.matchedCount / result.stats.bothCount) * 100)
      : 0
    console.log(`  ${status} "${result.query}": ${result.stats.matchedCount}/${result.stats.bothCount} paired (${pairingRate}%)`)
  }

  if (failedTests > 0) {
    console.log('\n❌ SOME TESTS FAILED - Review errors above')
    process.exit(1)
  } else {
    console.log('\n✅ ALL TESTS PASSED!')
    process.exit(0)
  }
}

// Run the script
main().catch(error => {
  console.error('\n💥 FATAL ERROR:', error)
  process.exit(1)
})
