#!/usr/bin/env node

/**
 * Show all eBay sales and compute average per size
 */

import 'dotenv/config'
import { EbayClient } from '../src/lib/services/ebay/client'
import { enrichEbaySoldItem } from '../src/lib/services/ebay/extractors'

const SKU = process.argv[2] || 'DZ4137-700'

async function main() {
  const client = new EbayClient()

  const result = await client.searchSold({
    query: SKU,
    limit: 50,
    conditionIds: [1000], // Only NEW condition
    qualifiedPrograms: ['AUTHENTICITY_GUARANTEE'],
    categoryIds: ['15709', '95672', '155194'],
    soldItemsOnly: true,
    fetchFullDetails: true,
  })

  // Enrich all items
  result.items.forEach((item) => {
    enrichEbaySoldItem(item)
  })

  console.log('\n' + '═'.repeat(80))
  console.log(`ALL SALES - ${SKU}`)
  console.log('═'.repeat(80) + '\n')

  result.items.forEach((item, i) => {
    const size = item.sizeInfo?.normalizedKey || 'NO SIZE'
    const title = item.title.substring(0, 60)
    console.log(`${String(i + 1).padStart(2, '0')}. ${title.padEnd(60)} → ${size.padEnd(10)} ${item.currency} ${item.price}`)
  })

  // Compute average per size (only HIGH confidence)
  const included = result.items.filter(
    (item) =>
      item.conditionId === 1000 &&
      item.authenticityVerification &&
      item.sizeInfo &&
      item.sizeInfo.system !== 'UNKNOWN' &&
      item.sizeInfo.confidence === 'HIGH'
  )

  const bySize = included.reduce((acc, item) => {
    const key = item.sizeInfo!.normalizedKey
    if (!acc[key]) {
      acc[key] = []
    }
    acc[key].push(item.price)
    return acc
  }, {} as Record<string, number[]>)

  console.log('\n' + '═'.repeat(80))
  console.log('AVERAGE MARKET PRICE PER SIZE (HIGH confidence only)')
  console.log('═'.repeat(80) + '\n')

  const sizes = Object.keys(bySize).sort((a, b) => {
    const aNum = parseFloat(a.split(' ')[1])
    const bNum = parseFloat(b.split(' ')[1])
    return aNum - bNum
  })

  sizes.forEach((size) => {
    const prices = bySize[size]
    const avg = prices.reduce((sum, p) => sum + p, 0) / prices.length
    const min = Math.min(...prices)
    const max = Math.max(...prices)
    console.log(
      `${size.padEnd(10)} → Avg: £${avg.toFixed(2).padStart(7)} | Min: £${min.toFixed(2).padStart(7)} | Max: £${max.toFixed(2).padStart(7)} | Count: ${prices.length}`
    )
  })

  console.log('\n' + '═'.repeat(80))
  console.log(`Total sales: ${result.items.length}`)
  console.log(`Included (HIGH confidence): ${included.length}`)
  console.log(`Excluded: ${result.items.length - included.length}`)
  console.log('═'.repeat(80) + '\n')
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message)
  process.exit(1)
})
