/**
 * Complete StockX Data Report for FV5029-010
 * Shows all data including flex prices
 */

import { createClient } from '@supabase/supabase-js'
import { refreshStockxMarketData } from '@/lib/services/stockx/market-refresh'

const SKU = 'FV5029-010'
const STOCKX_PRODUCT_ID = '15795a80-5cc8-4d2d-9ed0-20250d83be7f'

async function main() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  console.log('================================================================================')
  console.log('COMPLETE STOCKX UK DATA REPORT')
  console.log('================================================================================\n')
  console.log('SKU:', SKU)
  console.log('Product ID:', STOCKX_PRODUCT_ID)
  console.log('Currency: GBP')
  console.log('Region: UK')
  console.log()

  // Step 1: Sync fresh data
  console.log('🔄 Syncing fresh data from StockX...\n')
  const syncResult = await refreshStockxMarketData(undefined, STOCKX_PRODUCT_ID, 'GBP')

  if (!syncResult.success) {
    console.error('❌ Sync failed:', syncResult.error)
    return
  }

  console.log('✅ Sync complete!\n')

  // Step 2: Get variant size mappings
  console.log('📋 Loading size mappings from stockx_variants...\n')
  const { data: variants } = await supabase
    .from('stockx_variants')
    .select('stockx_variant_id, variant_value, size_display')
    .eq('stockx_product_id', STOCKX_PRODUCT_ID)
    .order('variant_value', { ascending: true })

  const variantMap = new Map<string, any>()
  if (variants) {
    for (const v of variants) {
      variantMap.set(v.stockx_variant_id, {
        size: v.variant_value || 'Unknown',
        display: v.size_display || v.variant_value || 'Unknown'
      })
    }
  }

  console.log(`✅ Found ${variants?.length || 0} size mappings\n`)

  // Step 3: Get all market data with prices
  console.log('💰 Loading market data from master_market_data...\n')
  const { data: marketData, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('sku', SKU)
    .eq('provider', 'stockx')
    .eq('currency_code', 'GBP')
    .eq('region_code', 'UK')
    .order('created_at', { ascending: false })

  if (error) {
    console.error('❌ Query error:', error.message)
    return
  }

  if (!marketData || marketData.length === 0) {
    console.log('❌ No market data found')
    return
  }

  console.log(`✅ Found ${marketData.length} rows\n`)

  // Step 4: Group by variant and organize standard vs flex
  const variantGroups = new Map<string, any[]>()
  for (const row of marketData) {
    const variantId = row.provider_variant_id
    if (!variantGroups.has(variantId)) {
      variantGroups.set(variantId, [])
    }
    variantGroups.get(variantId)!.push(row)
  }

  // Step 5: Display comprehensive report
  console.log('================================================================================')
  console.log('FULL PRICING DATA (ALL SIZES)')
  console.log('================================================================================\n')

  // Sort by size
  const sortedVariants = Array.from(variantGroups.entries()).sort((a, b) => {
    const sizeA = parseFloat(variantMap.get(a[0])?.size || '999')
    const sizeB = parseFloat(variantMap.get(b[0])?.size || '999')
    return sizeA - sizeB
  })

  for (const [variantId, rows] of sortedVariants) {
    const sizeInfo = variantMap.get(variantId) || { size: 'Unknown', display: 'Unknown' }

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log(`📦 SIZE ${sizeInfo.size} US`)
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log(`Variant ID: ${variantId}`)
    console.log()

    // Separate standard and flex pricing based on provider_source
    const standardRows = rows.filter(r => r.provider_source === 'stockx_market_data')
    const flexRows = rows.filter(r => r.provider_source === 'stockx_market_data_flex')

    // Display standard pricing
    if (standardRows.length > 0) {
      const row = standardRows[0]
      console.log('📊 STANDARD PRICING')
      console.log('   Lowest Ask:     £' + (row.lowest_ask || 'N/A'))
      console.log('   Highest Bid:    £' + (row.highest_bid || 'N/A'))
      console.log('   Last Sale:      £' + (row.last_sale_price || 'N/A'))
      if (row.spread_absolute) {
        console.log('   Spread:         £' + row.spread_absolute + ' (' + row.spread_percentage?.toFixed(2) + '%)')
      }
      if (row.sales_last_72h) {
        console.log('   Sales (72h):    ' + row.sales_last_72h)
      }
      if (row.sales_last_30d) {
        console.log('   Sales (30d):    ' + row.sales_last_30d)
      }
      console.log()
    }

    // Display flex pricing
    if (flexRows.length > 0) {
      const row = flexRows[0]
      console.log('💎 FLEX PRICING')
      console.log('   Lowest Ask:     £' + (row.lowest_ask || 'N/A'))
      console.log('   Highest Bid:    £' + (row.highest_bid || 'N/A'))
      console.log('   Last Sale:      £' + (row.last_sale_price || 'N/A'))
      if (row.spread_absolute) {
        console.log('   Spread:         £' + row.spread_absolute + ' (' + row.spread_percentage?.toFixed(2) + '%)')
      }
      console.log()
    }

    // Raw API response excerpt
    console.log('🔍 RAW API DATA')
    if (standardRows.length > 0) {
      console.log('   Standard:', JSON.stringify(standardRows[0].raw_response_excerpt, null, 2).replace(/\n/g, '\n   '))
    }
    if (flexRows.length > 0) {
      console.log('   Flex:', JSON.stringify(flexRows[0].raw_response_excerpt, null, 2).replace(/\n/g, '\n   '))
    }
    console.log()
  }

  console.log('================================================================================')
  console.log('SUMMARY')
  console.log('================================================================================')
  console.log('Total unique sizes:', variantGroups.size)
  console.log('Total pricing rows:', marketData.length)
  console.log('Standard pricing rows:', marketData.filter(r => r.provider_source === 'stockx_market_data').length)
  console.log('Flex pricing rows:', marketData.filter(r => r.provider_source === 'stockx_market_data_flex').length)
  console.log()
}

main().catch(console.error)
