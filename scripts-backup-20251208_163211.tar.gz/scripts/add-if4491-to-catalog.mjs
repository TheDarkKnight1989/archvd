#!/usr/bin/env node
/**
 * Search StockX for IF4491-100 and add to catalog
 */

import { createClient } from '@supabase/supabase-js';

const SKU = 'IF4491-100';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

console.log('================================================================================');
console.log(`ADDING ${SKU} TO CATALOG`);
console.log('================================================================================\n');

// ============================================================================
// STEP 1: Search StockX for the product
// ============================================================================

console.log('🔍 STEP 1: Searching StockX for', SKU, '...\n');

const { StockxCatalogService } = await import('../src/lib/services/stockx/catalog.ts');

const catalogService = new StockxCatalogService(undefined); // App-level auth

let searchResults;
try {
  searchResults = await catalogService.searchProducts(SKU);
} catch (error) {
  console.error('❌ StockX search failed:', error.message);
  process.exit(1);
}

if (!searchResults || searchResults.length === 0) {
  console.log('❌ No results found for', SKU);
  console.log('\nTrying partial search (first 7 chars)...');

  try {
    searchResults = await catalogService.searchProducts(SKU.substring(0, 7));
  } catch (error) {
    console.error('❌ Partial search also failed:', error.message);
    process.exit(1);
  }
}

if (!searchResults || searchResults.length === 0) {
  console.log('❌ Still no results. Product may not exist on StockX.');
  process.exit(1);
}

console.log(`✅ Found ${searchResults.length} results\n`);

// Show results
searchResults.slice(0, 5).forEach((product, idx) => {
  console.log(`${idx + 1}. ${product.productName}`);
  console.log(`   SKU: ${product.styleId || 'N/A'}`);
  console.log(`   Product ID: ${product.productId}`);
  console.log(`   Brand: ${product.brand || 'N/A'}`);
  console.log('');
});

// Find exact match
let exactMatch = searchResults.find(p => p.styleId === SKU);

if (!exactMatch) {
  console.log(`⚠️  No exact SKU match for ${SKU}`);
  console.log('Using first result instead...\n');
  exactMatch = searchResults[0];
}

console.log('✅ Selected product:');
console.log('   Name:', exactMatch.productName);
console.log('   SKU:', exactMatch.styleId || 'N/A');
console.log('   StockX Product ID:', exactMatch.productId);
console.log('   Brand:', exactMatch.brand || 'N/A');
console.log('   Colorway:', exactMatch.colorway || 'N/A');

console.log('\n' + '='.repeat(80) + '\n');

// ============================================================================
// STEP 2: Add to product_catalog
// ============================================================================

console.log('📦 STEP 2: Adding to product_catalog...\n');

const { error: insertError } = await supabase
  .from('product_catalog')
  .upsert({
    sku: exactMatch.styleId || SKU,
    stockx_product_id: exactMatch.productId,
    model: exactMatch.productName,  // Use 'model' not 'name'
    brand: exactMatch.brand,
    colorway: exactMatch.colorway,
    image_url: exactMatch.image,
    category: exactMatch.category,
    gender: exactMatch.gender,
    retail_price: exactMatch.retailPrice,  // Keep as numeric
    release_date: exactMatch.releaseDate,
  }, {
    onConflict: 'sku',
  });

if (insertError) {
  console.error('❌ Failed to insert into catalog:', insertError.message);
  process.exit(1);
}

console.log('✅ Product added to catalog!');
console.log('   SKU:', exactMatch.styleId || SKU);
console.log('   StockX Product ID:', exactMatch.productId);

console.log('\n' + '='.repeat(80));
console.log('✅ READY TO TEST');
console.log('='.repeat(80));
console.log('\nRun the test with:');
console.log(`  npx tsx scripts/test-if4491-sync.mjs`);
