#!/usr/bin/env npx tsx
/**
 * Check Sync Coverage - Which products actually synced?
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🔍 Checking Sync Coverage\n')

  const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000).toISOString()

  // Get all recent snapshots
  const { data: recentSnapshots } = await supabase
    .from('master_market_data')
    .select('sku, provider')
    .gte('snapshot_at', fifteenMinutesAgo)

  if (!recentSnapshots) {
    console.log('❌ No recent data found')
    return
  }

  // Count by provider
  const stockxSkus = new Set(
    recentSnapshots.filter(s => s.provider === 'stockx').map(s => s.sku)
  )
  const aliasSkus = new Set(
    recentSnapshots.filter(s => s.provider === 'alias').map(s => s.sku)
  )

  console.log('📊 Recent Sync Coverage (last 15 min):\n')
  console.log(`  StockX: ${stockxSkus.size} unique SKUs`)
  console.log(`  Alias: ${aliasSkus.size} unique SKUs`)
  console.log(`  Total Snapshots: ${recentSnapshots.length}`)

  // Get all products with StockX mapping
  const { data: allProducts } = await supabase
    .from('products')
    .select(`
      sku,
      product_variants (stockx_product_id, alias_catalog_id)
    `)

  const productsWithStockX = allProducts?.filter(p => {
    const variants = p.product_variants as any[]
    return variants?.some(v => v.stockx_product_id)
  }) || []

  const productsWithAlias = allProducts?.filter(p => {
    const variants = p.product_variants as any[]
    return variants?.some(v => v.alias_catalog_id)
  }) || []

  console.log(`\n📦 Expected Coverage:`)
  console.log(`  Products with StockX mapping: ${productsWithStockX.length}`)
  console.log(`  Products with Alias mapping: ${productsWithAlias.length}`)

  console.log(`\n📈 Actual vs Expected:`)
  console.log(`  StockX: ${stockxSkus.size}/${productsWithStockX.length} (${((stockxSkus.size / productsWithStockX.length) * 100).toFixed(1)}%)`)
  console.log(`  Alias: ${aliasSkus.size}/${productsWithAlias.length} (${((aliasSkus.size / productsWithAlias.length) * 100).toFixed(1)}%)`)

  // Find missing products
  const expectedStockXSkus = new Set(productsWithStockX.map(p => p.sku))
  const missingStockX = [...expectedStockXSkus].filter(sku => !stockxSkus.has(sku))

  if (missingStockX.length > 0) {
    console.log(`\n❌ Missing StockX SKUs (${missingStockX.length}):`)
    missingStockX.slice(0, 10).forEach(sku => console.log(`  - ${sku}`))
    if (missingStockX.length > 10) {
      console.log(`  ... and ${missingStockX.length - 10} more`)
    }
  }

  // Check if the test script is still running
  console.log(`\n💡 Tip: If fewer than expected products synced, the sync may still be running.`)
  console.log(`   Check: tail -f /tmp/inngest-sync-test-v2.log`)
}

main().catch(console.error)
