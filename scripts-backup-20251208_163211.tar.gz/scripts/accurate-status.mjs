#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('📊 Accurate Product Mapping Status\n')

// Get ALL products
const { data: allProducts } = await supabase
  .from('products')
  .select(`
    id,
    sku,
    product_variants (
      alias_catalog_id,
      stockx_product_id
    )
  `)

let withAlias = 0
let withStockX = 0
let withBoth = 0
let withNeither = 0

allProducts.forEach(product => {
  const hasAlias = product.product_variants.some(v => v.alias_catalog_id)
  const hasStockX = product.product_variants.some(v => v.stockx_product_id)
  
  if (hasAlias && hasStockX) withBoth++
  else if (hasAlias) withAlias++
  else if (hasStockX) withStockX++
  else withNeither++
})

console.log(`Total products: ${allProducts.length}`)
console.log(`With Alias only: ${withAlias}`)
console.log(`With StockX only: ${withStockX}`)
console.log(`With both: ${withBoth}`)
console.log(`With neither: ${withNeither}`)
console.log('')
console.log(`✅ Ready for sync: ${withAlias + withStockX + withBoth} products`)
console.log(`❌ Still unmapped: ${withNeither} products`)
