#!/usr/bin/env npx tsx
/**
 * Monitor sync progress and verify data quality at 50 products
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function verifyAt50() {
  console.log('🔍 Checking current progress...\n')

  // Get total unique products synced
  const { data: allData } = await supabase
    .from('master_market_data')
    .select('provider_product_id, sku, region_code, currency_code, lowest_ask, size_key')
    .eq('provider', 'stockx')

  const uniqueProducts = new Set(allData?.map(r => r.provider_product_id))
  const total = uniqueProducts.size

  console.log(`📊 Current: ${total} unique products synced`)

  if (total < 50) {
    console.log(`⏳ Waiting for 50... (${50 - total} more to go)\n`)
    return
  }

  console.log('\n🎉 REACHED 50 PRODUCTS! Running comprehensive verification...\n')
  console.log('═'.repeat(75) + '\n')

  // Verification 1: Check region coverage
  console.log('1️⃣  REGION COVERAGE CHECK\n')

  const productRegions = new Map<string, Set<string>>()
  allData?.forEach(row => {
    if (!productRegions.has(row.provider_product_id)) {
      productRegions.set(row.provider_product_id, new Set())
    }
    productRegions.get(row.provider_product_id)!.add(row.region_code)
  })

  let fullCoverage = 0
  let partialCoverage = 0
  const missingRegions: string[] = []

  productRegions.forEach((regions, productId) => {
    if (regions.size === 3) {
      fullCoverage++
    } else {
      partialCoverage++
      const product = allData?.find(r => r.provider_product_id === productId)
      missingRegions.push(`${product?.sku}: ${Array.from(regions).join(', ')} (missing ${3 - regions.size})`)
    }
  })

  console.log(`   ✅ Full coverage (3 regions): ${fullCoverage} products`)
  console.log(`   ⚠️  Partial coverage: ${partialCoverage} products`)
  if (missingRegions.length > 0 && missingRegions.length <= 10) {
    console.log(`   Missing regions:`)
    missingRegions.slice(0, 10).forEach(m => console.log(`      - ${m}`))
  }

  // Verification 2: Price format check (should be in cents)
  console.log('\n2️⃣  PRICE FORMAT CHECK (should be cents, not dollars)\n')

  const pricesInCents = allData?.filter(r => r.lowest_ask && r.lowest_ask >= 1000) || []
  const pricesInDollars = allData?.filter(r => r.lowest_ask && r.lowest_ask < 1000 && r.lowest_ask > 0) || []

  console.log(`   ✅ Prices in cents (≥1000): ${pricesInCents.length} rows`)
  console.log(`   ❌ Prices in dollars (<1000): ${pricesInDollars.length} rows`)

  if (pricesInDollars.length > 0) {
    console.log(`   Sample prices in dollars (BUG!):`)
    pricesInDollars.slice(0, 5).forEach(r => {
      console.log(`      - ${r.sku} size ${r.size_key}: $${(r.lowest_ask! / 100).toFixed(2)} (${r.lowest_ask} cents - WRONG!)`)
    })
  }

  // Verification 3: Size filtering check
  console.log('\n3️⃣  SIZE FILTERING CHECK\n')

  const allSizes = new Set(allData?.map(r => r.size_key).filter(Boolean))
  const invalidSizes = Array.from(allSizes).filter(size => {
    const numeric = parseFloat(size)
    return !isNaN(numeric) && (numeric < 3.5 || numeric > 16)
  })

  console.log(`   ✅ Total unique sizes: ${allSizes.size}`)
  console.log(`   ❌ Invalid sizes (should be filtered): ${invalidSizes.length}`)

  if (invalidSizes.length > 0) {
    console.log(`   Invalid sizes found: ${invalidSizes.slice(0, 10).join(', ')}`)
  }

  // Verification 4: Data completeness
  console.log('\n4️⃣  DATA COMPLETENESS CHECK\n')

  const totalRows = allData?.length || 0
  const withPrices = allData?.filter(r => r.lowest_ask !== null).length || 0
  const withoutPrices = totalRows - withPrices

  console.log(`   Total rows: ${totalRows}`)
  console.log(`   ✅ With prices: ${withPrices} (${((withPrices / totalRows) * 100).toFixed(1)}%)`)
  console.log(`   ⚠️  Without prices: ${withoutPrices} (${((withoutPrices / totalRows) * 100).toFixed(1)}%)`)

  // Summary
  console.log('\n' + '═'.repeat(75))
  console.log('📋 VERIFICATION SUMMARY\n')

  const allGood =
    partialCoverage === 0 &&
    pricesInDollars.length === 0 &&
    invalidSizes.length === 0 &&
    withoutPrices < totalRows * 0.1 // Less than 10% missing prices is acceptable

  if (allGood) {
    console.log('✅ ALL CHECKS PASSED - Data quality is excellent!')
  } else {
    console.log('⚠️  SOME ISSUES FOUND:')
    if (partialCoverage > 0) console.log(`   - ${partialCoverage} products missing some regions`)
    if (pricesInDollars.length > 0) console.log(`   - ${pricesInDollars.length} rows have prices in dollars (should be cents)`)
    if (invalidSizes.length > 0) console.log(`   - ${invalidSizes.length} invalid sizes not filtered`)
    if (withoutPrices > totalRows * 0.1) console.log(`   - ${withoutPrices} rows missing prices (>10%)`)
  }

  console.log('\n' + '═'.repeat(75) + '\n')
}

verifyAt50()
