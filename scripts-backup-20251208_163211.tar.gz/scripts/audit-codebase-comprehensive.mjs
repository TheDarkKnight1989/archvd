#!/usr/bin/env node
/**
 * Comprehensive Codebase Audit
 *
 * Scans the entire codebase to understand:
 * 1. Database schema & relationships
 * 2. API routes & endpoints
 * 3. Component structure
 * 4. Data flow patterns
 * 5. What's working vs. broken
 * 6. Migration opportunities
 */

import { createClient } from '@supabase/supabase-js'
import { promises as fs } from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const projectRoot = path.join(__dirname, '..')

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

// ═══════════════════════════════════════════════════════════════════════════
// 1. DATABASE SCHEMA AUDIT
// ═══════════════════════════════════════════════════════════════════════════

async function auditDatabaseSchema() {
  console.log('\n' + '═'.repeat(80))
  console.log('DATABASE SCHEMA AUDIT')
  console.log('═'.repeat(80))

  // Get all tables
  const { data: tables, error } = await supabase
    .from('information_schema.tables')
    .select('table_name')
    .eq('table_schema', 'public')
    .order('table_name')

  if (error) {
    console.error('Error fetching tables:', error.message)
    return
  }

  console.log(`\nFound ${tables?.length || 0} tables:\n`)

  const tableStats = []

  for (const table of tables || []) {
    const tableName = table.table_name

    // Get row count
    const { count } = await supabase
      .from(tableName)
      .select('*', { count: 'exact', head: true })

    // Get column info
    const { data: columns } = await supabase.rpc('get_table_columns', {
      table_name: tableName
    }).catch(() => ({ data: null }))

    const columnCount = columns?.length || 'unknown'

    tableStats.push({
      name: tableName,
      rows: count || 0,
      columns: columnCount,
      category: categorizeTable(tableName)
    })

    console.log(`  ${tableName.padEnd(40)} ${String(count || 0).padStart(10)} rows  ${columnCount} cols`)
  }

  // Categorize tables
  console.log('\n' + '-'.repeat(80))
  console.log('TABLE CATEGORIES:\n')

  const categories = {
    'Market Data': tableStats.filter(t => t.category === 'market'),
    'Product Catalog': tableStats.filter(t => t.category === 'catalog'),
    'User Data': tableStats.filter(t => t.category === 'user'),
    'Auth/System': tableStats.filter(t => t.category === 'system'),
    'Other': tableStats.filter(t => t.category === 'other')
  }

  for (const [category, tables] of Object.entries(categories)) {
    if (tables.length > 0) {
      console.log(`\n${category}:`)
      tables.forEach(t => {
        console.log(`  - ${t.name} (${t.rows} rows)`)
      })
    }
  }

  return tableStats
}

function categorizeTable(tableName) {
  if (tableName.includes('market') || tableName.includes('stockx') ||
      tableName.includes('alias') || tableName.includes('ebay') ||
      tableName.includes('snapshot') || tableName.includes('price')) {
    return 'market'
  }
  if (tableName.includes('catalog') || tableName.includes('product')) {
    return 'catalog'
  }
  if (tableName.includes('Inventory') || tableName.includes('portfolio') ||
      tableName.includes('watchlist') || tableName.includes('user_')) {
    return 'user'
  }
  if (tableName.includes('auth') || tableName.includes('storage') ||
      tableName.includes('migration') || tableName.startsWith('_')) {
    return 'system'
  }
  return 'other'
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. API ROUTES AUDIT
// ═══════════════════════════════════════════════════════════════════════════

async function auditAPIRoutes() {
  console.log('\n' + '═'.repeat(80))
  console.log('API ROUTES AUDIT')
  console.log('═'.repeat(80))

  const apiDir = path.join(projectRoot, 'src/app/api')
  const routes = await findAPIRoutes(apiDir)

  console.log(`\nFound ${routes.length} API routes:\n`)

  const categorized = {
    'Market Data': [],
    'User/Portfolio': [],
    'Sync/Cron': [],
    'Debug': [],
    'Other': []
  }

  routes.forEach(route => {
    if (route.includes('market') || route.includes('stockx') ||
        route.includes('alias') || route.includes('ebay')) {
      categorized['Market Data'].push(route)
    } else if (route.includes('portfolio') || route.includes('inventory') ||
               route.includes('items') || route.includes('user')) {
      categorized['User/Portfolio'].push(route)
    } else if (route.includes('cron') || route.includes('sync')) {
      categorized['Sync/Cron'].push(route)
    } else if (route.includes('debug') || route.includes('test')) {
      categorized['Debug'].push(route)
    } else {
      categorized['Other'].push(route)
    }
  })

  for (const [category, routes] of Object.entries(categorized)) {
    if (routes.length > 0) {
      console.log(`\n${category} (${routes.length}):`)
      routes.forEach(route => {
        console.log(`  ${route}`)
      })
    }
  }

  return routes
}

async function findAPIRoutes(dir, basePath = '') {
  const routes = []

  try {
    const entries = await fs.readdir(dir, { withFileTypes: true })

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name)
      const routePath = path.join(basePath, entry.name)

      if (entry.isDirectory()) {
        // Recurse into subdirectories
        const subRoutes = await findAPIRoutes(fullPath, routePath)
        routes.push(...subRoutes)
      } else if (entry.name === 'route.ts' || entry.name === 'route.js') {
        // Found an API route
        const apiPath = basePath.replace(/\\/g, '/').replace(/\[([^\]]+)\]/g, ':$1')
        routes.push(`/api/${apiPath}`)
      }
    }
  } catch (error) {
    // Directory doesn't exist or can't be read
  }

  return routes
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. COMPONENT AUDIT
// ═══════════════════════════════════════════════════════════════════════════

async function auditComponents() {
  console.log('\n' + '═'.repeat(80))
  console.log('COMPONENT AUDIT')
  console.log('═'.repeat(80))

  const componentsDir = path.join(projectRoot, 'src/components')
  const appDir = path.join(projectRoot, 'src/app')

  const components = await findComponents(componentsDir)
  const pages = await findPages(appDir)

  console.log(`\nFound ${components.length} components in /src/components`)
  console.log(`Found ${pages.length} pages in /src/app\n`)

  // Categorize components
  const categorized = {
    'Market/Pricing': [],
    'Portfolio/Inventory': [],
    'Product Display': [],
    'StockX Integration': [],
    'UI/Generic': [],
    'Other': []
  }

  components.forEach(comp => {
    const name = path.basename(comp, path.extname(comp))
    if (name.toLowerCase().includes('market') || name.toLowerCase().includes('price') ||
        name.toLowerCase().includes('chart')) {
      categorized['Market/Pricing'].push(comp)
    } else if (name.toLowerCase().includes('portfolio') || name.toLowerCase().includes('inventory')) {
      categorized['Portfolio/Inventory'].push(comp)
    } else if (name.toLowerCase().includes('product') || name.toLowerCase().includes('item')) {
      categorized['Product Display'].push(comp)
    } else if (name.toLowerCase().includes('stockx') || name.toLowerCase().includes('listing')) {
      categorized['StockX Integration'].push(comp)
    } else if (name.toLowerCase().includes('button') || name.toLowerCase().includes('modal') ||
               name.toLowerCase().includes('card') || name.toLowerCase().includes('badge')) {
      categorized['UI/Generic'].push(comp)
    } else {
      categorized['Other'].push(comp)
    }
  })

  console.log('Components by category:\n')
  for (const [category, comps] of Object.entries(categorized)) {
    if (comps.length > 0) {
      console.log(`${category} (${comps.length}):`)
      comps.slice(0, 10).forEach(comp => {
        const displayPath = comp.replace(projectRoot, '')
        console.log(`  ${displayPath}`)
      })
      if (comps.length > 10) {
        console.log(`  ... and ${comps.length - 10} more`)
      }
      console.log()
    }
  }

  return { components, pages }
}

async function findComponents(dir, basePath = '') {
  const components = []

  try {
    const entries = await fs.readdir(dir, { withFileTypes: true })

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name)

      if (entry.isDirectory()) {
        const subComps = await findComponents(fullPath, path.join(basePath, entry.name))
        components.push(...subComps)
      } else if (entry.name.endsWith('.tsx') || entry.name.endsWith('.jsx')) {
        components.push(fullPath)
      }
    }
  } catch (error) {
    // Directory doesn't exist
  }

  return components
}

async function findPages(dir, basePath = '') {
  const pages = []

  try {
    const entries = await fs.readdir(dir, { withFileTypes: true })

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name)

      if (entry.isDirectory() && !entry.name.startsWith('_') && !entry.name.startsWith('(')) {
        const subPages = await findPages(fullPath, path.join(basePath, entry.name))
        pages.push(...subPages)
      } else if (entry.name === 'page.tsx' || entry.name === 'page.js') {
        pages.push(basePath || '/')
      }
    }
  } catch (error) {
    // Directory doesn't exist
  }

  return pages
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. DATA FLOW ANALYSIS
// ═══════════════════════════════════════════════════════════════════════════

async function analyzeDataFlows() {
  console.log('\n' + '═'.repeat(80))
  console.log('DATA FLOW ANALYSIS')
  console.log('═'.repeat(80))

  console.log('\nAnalyzing how market data flows through the system...\n')

  // Check which tables are actually being queried
  console.log('Tables with recent data activity:\n')

  const marketTables = [
    'master_market_data',
    'stockx_market_latest',
    'alias_market_snapshots',
    'ebay_sold_transactions',
    'stockx_products',
    'alias_catalog_items'
  ]

  for (const table of marketTables) {
    const { count, error } = await supabase
      .from(table)
      .select('*', { count: 'exact', head: true })

    if (!error && count > 0) {
      // Get most recent record
      const { data: latest } = await supabase
        .from(table)
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .single()
        .catch(() => ({ data: null }))

      const latestDate = latest?.created_at || latest?.snapshot_at || latest?.updated_at || 'unknown'

      console.log(`  ${table.padEnd(30)} ${String(count).padStart(8)} rows  (latest: ${latestDate})`)
    } else if (!error) {
      console.log(`  ${table.padEnd(30)} ${String(0).padStart(8)} rows  (empty)`)
    }
  }

  // Check Inventory table dependencies
  console.log('\n' + '-'.repeat(80))
  console.log('INVENTORY TABLE DEPENDENCIES:\n')

  const { data: inventory } = await supabase
    .from('Inventory')
    .select('*')
    .limit(5)

  if (inventory && inventory.length > 0) {
    const sample = inventory[0]
    console.log('Sample inventory item columns:')
    Object.keys(sample).forEach(key => {
      const value = sample[key]
      const type = typeof value
      console.log(`  - ${key.padEnd(30)} ${type.padEnd(10)} ${value !== null ? '✓' : '∅'}`)
    })
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 5. MIGRATION SCRIPT AUDIT
// ═══════════════════════════════════════════════════════════════════════════

async function auditMigrations() {
  console.log('\n' + '═'.repeat(80))
  console.log('MIGRATION SCRIPTS AUDIT')
  console.log('═'.repeat(80))

  const migrationsDir = path.join(projectRoot, 'supabase/migrations')

  try {
    const files = await fs.readdir(migrationsDir)
    const sqlFiles = files.filter(f => f.endsWith('.sql')).sort()

    console.log(`\nFound ${sqlFiles.length} migration files:\n`)

    // Categorize migrations
    const categories = {
      'Market Data Schema': [],
      'Product Catalog': [],
      'User/Inventory': [],
      'Indexes/Performance': [],
      'Other': []
    }

    sqlFiles.forEach(file => {
      if (file.includes('market') || file.includes('stockx') ||
          file.includes('alias') || file.includes('ebay') ||
          file.includes('snapshot') || file.includes('price')) {
        categories['Market Data Schema'].push(file)
      } else if (file.includes('catalog') || file.includes('product')) {
        categories['Product Catalog'].push(file)
      } else if (file.includes('inventory') || file.includes('portfolio') || file.includes('user')) {
        categories['User/Inventory'].push(file)
      } else if (file.includes('index') || file.includes('performance')) {
        categories['Indexes/Performance'].push(file)
      } else {
        categories['Other'].push(file)
      }
    })

    for (const [category, files] of Object.entries(categories)) {
      if (files.length > 0) {
        console.log(`\n${category} (${files.length}):`)
        files.forEach(file => {
          console.log(`  ${file}`)
        })
      }
    }

    return sqlFiles
  } catch (error) {
    console.log('\nNo migrations directory found')
    return []
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 6. GENERATE AUDIT REPORT
// ═══════════════════════════════════════════════════════════════════════════

async function generateAuditReport(data) {
  console.log('\n' + '═'.repeat(80))
  console.log('GENERATING AUDIT REPORT')
  console.log('═'.repeat(80))

  const report = `# Codebase Audit Report
Generated: ${new Date().toISOString()}

## Executive Summary

### Database
- Total tables: ${data.tables.length}
- Market data tables: ${data.tables.filter(t => t.category === 'market').length}
- Product catalog tables: ${data.tables.filter(t => t.category === 'catalog').length}
- User data tables: ${data.tables.filter(t => t.category === 'user').length}

### API Routes
- Total routes: ${data.routes.length}
- Market data routes: ${data.routes.filter(r => r.includes('market')).length}
- Sync/cron routes: ${data.routes.filter(r => r.includes('cron') || r.includes('sync')).length}

### Components
- Total components: ${data.components.length}
- Total pages: ${data.pages.length}

### Migrations
- Total migration files: ${data.migrations.length}

## Detailed Findings

### 1. Database Schema
${data.tables.map(t => `- ${t.name}: ${t.rows} rows (${t.category})`).join('\n')}

### 2. API Routes
${data.routes.map(r => `- ${r}`).join('\n')}

### 3. Key Components
${data.components.slice(0, 20).map(c => `- ${c.replace(projectRoot, '')}`).join('\n')}

### 4. Migration History
${data.migrations.slice(-10).map(m => `- ${m}`).join('\n')}

## Recommendations

1. **Consolidate Market Data Tables**
   - Current: Multiple tables (master_market_data, stockx_market_latest, alias_market_snapshots)
   - Recommended: Single source of truth with materialized views

2. **Implement Job Queue**
   - Current: Direct cron jobs
   - Recommended: Queue-based sync system with retry logic

3. **Standardize API Routes**
   - Current: Mixed patterns
   - Recommended: RESTful API design with versioning

4. **Component Organization**
   - Current: Flat structure in some areas
   - Recommended: Feature-based organization

## Next Steps

1. Week 1: Database schema consolidation
2. Week 2: API route standardization
3. Week 3: Component refactoring
4. Week 4: Migration & testing
`

  const reportPath = path.join(projectRoot, 'AUDIT_REPORT.md')
  await fs.writeFile(reportPath, report)

  console.log(`\n✅ Audit report saved to: AUDIT_REPORT.md\n`)
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════════════════

async function main() {
  console.log('\n')
  console.log('╔════════════════════════════════════════════════════════════════════════════╗')
  console.log('║                    COMPREHENSIVE CODEBASE AUDIT                            ║')
  console.log('║                                                                            ║')
  console.log('║  This audit will analyze:                                                  ║')
  console.log('║  1. Database schema & data                                                 ║')
  console.log('║  2. API routes & endpoints                                                 ║')
  console.log('║  3. Components & pages                                                     ║')
  console.log('║  4. Data flow patterns                                                     ║')
  console.log('║  5. Migration history                                                      ║')
  console.log('║                                                                            ║')
  console.log('╚════════════════════════════════════════════════════════════════════════════╝')

  const auditData = {
    tables: [],
    routes: [],
    components: [],
    pages: [],
    migrations: []
  }

  // Run all audits
  auditData.tables = await auditDatabaseSchema()
  auditData.routes = await auditAPIRoutes()
  const { components, pages } = await auditComponents()
  auditData.components = components
  auditData.pages = pages
  await analyzeDataFlows()
  auditData.migrations = await auditMigrations()

  // Generate report
  await generateAuditReport(auditData)

  console.log('\n' + '═'.repeat(80))
  console.log('AUDIT COMPLETE')
  console.log('═'.repeat(80))
  console.log('\n✅ Review AUDIT_REPORT.md for detailed findings and recommendations\n')
}

main().catch(console.error)
