#!/usr/bin/env npx tsx
/**
 * Simple UK-only sync - One product at a time, 3 second gap
 */

import { createClient } from '@supabase/supabase-js'
import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

async function main() {
  console.log('Simple UK-Only StockX Sync')
  console.log('=' .repeat(50))
  console.log('')

  // Step 1: Delete ALL StockX rows
  console.log('Step 1: Deleting ALL StockX rows...')
  const { count: beforeCount, error: countError } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')

  if (countError) {
    console.error('Error counting rows:', countError)
  } else {
    console.log(`Found ${beforeCount || 0} StockX rows`)
  }

  const { error: deleteError } = await supabase
    .from('master_market_data')
    .delete()
    .eq('provider', 'stockx')

  if (deleteError) {
    console.error('❌ Failed to delete:', deleteError)
    process.exit(1)
  }

  console.log(`✅ Deleted all StockX rows\n`)

  // Step 2: Get all products
  const { data: products } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id')
    .order('style_id')

  if (!products) {
    console.error('❌ Failed to fetch products')
    process.exit(1)
  }

  console.log(`Step 2: Syncing ${products.length} products (UK only, 3s gap)\n`)
  console.log('=' .repeat(50))
  console.log('')

  let success = 0
  let failed = 0

  for (let i = 0; i < products.length; i++) {
    const product = products[i]
    const num = i + 1

    console.log(`[${num}/${products.length}] ${product.style_id}`)

    try {
      // Sync UK region only (syncSecondaryRegions = false)
      const result = await syncProductAllRegions(
        undefined,
        product.stockx_product_id,
        'UK',
        false  // UK only, no secondary regions
      )

      if (result.success) {
        success++
        console.log(`  ✅ Success`)
      } else {
        failed++
        console.log(`  ❌ Failed: ${result.primaryResult.error || 'Unknown'}`)
      }
    } catch (error: any) {
      failed++
      console.log(`  ❌ Error: ${error.message}`)
    }

    // 3 second gap
    if (i < products.length - 1) {
      await sleep(3000)
    }
  }

  console.log('')
  console.log('=' .repeat(50))
  console.log('FINAL RESULTS')
  console.log('=' .repeat(50))
  console.log(`Total: ${products.length}`)
  console.log(`Success: ${success}`)
  console.log(`Failed: ${failed}`)
  console.log(`Success rate: ${((success / products.length) * 100).toFixed(1)}%`)

  // Verify database
  const { count: finalCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')

  console.log(`\nDatabase rows: ${finalCount || 0}`)
}

main().catch(console.error)
