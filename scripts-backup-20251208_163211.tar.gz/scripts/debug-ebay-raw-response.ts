#!/usr/bin/env node

/**
 * Debug raw eBay API response to see actual field structure
 */

import 'dotenv/config'

const SKU = 'DZ4137-700'

async function main() {
  console.log('\n' + '═'.repeat(80))
  console.log('Raw eBay API Response Debug')
  console.log('═'.repeat(80) + '\n')

  // Get token
  const clientId = process.env.EBAY_CLIENT_ID
  const clientSecret = process.env.EBAY_CLIENT_SECRET

  if (!clientId || !clientSecret) {
    console.error('❌ Missing EBAY_CLIENT_ID or EBAY_CLIENT_SECRET')
    process.exit(1)
  }

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64')
  const baseUrl = 'https://api.ebay.com'

  // Get OAuth token
  console.log('🔐 Getting OAuth token...\n')
  const tokenResponse = await fetch(`${baseUrl}/identity/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: `Basic ${credentials}`,
    },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      scope: 'https://api.ebay.com/oauth/api_scope',
    }),
  })

  if (!tokenResponse.ok) {
    console.error('❌ Token request failed:', tokenResponse.status)
    process.exit(1)
  }

  const tokenData = await tokenResponse.json()
  const token = tokenData.access_token

  console.log('✅ Token obtained\n')

  // Search for items
  const filters = [
    'soldItemsOnly:true',
    'conditionIds:{1000|1500|1750}',
    'qualifiedPrograms:{AUTHENTICITY_GUARANTEE}',
    'deliveryCountry:GB',
    'deliveryPostalCode:SW1A1AA',
    'categoryIds:{15709|95672|155194}',
  ]

  const url = new URL(`${baseUrl}/buy/browse/v1/item_summary/search`)
  url.searchParams.set('q', SKU)
  url.searchParams.set('filter', filters.join(','))
  url.searchParams.set('limit', '5')

  console.log('📡 Fetching item summaries...')
  console.log('URL:', url.toString())
  console.log()

  const searchResponse = await fetch(url.toString(), {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      'X-EBAY-C-MARKETPLACE-ID': 'EBAY_GB',
    },
  })

  if (!searchResponse.ok) {
    console.error('❌ Search failed:', searchResponse.status)
    const error = await searchResponse.text()
    console.error(error)
    process.exit(1)
  }

  const searchData = await searchResponse.json()

  console.log('═'.repeat(80))
  console.log('ITEM SUMMARY RESPONSE (first item)')
  console.log('═'.repeat(80))
  console.log(JSON.stringify(searchData.itemSummaries?.[0], null, 2))
  console.log()

  // Get full details for first item
  if (searchData.itemSummaries?.[0]?.itemId) {
    const itemId = searchData.itemSummaries[0].itemId
    console.log('═'.repeat(80))
    console.log(`FULL ITEM DETAILS for ${itemId}`)
    console.log('═'.repeat(80))

    const detailsResponse = await fetch(`${baseUrl}/buy/browse/v1/item/${itemId}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        'X-EBAY-C-MARKETPLACE-ID': 'EBAY_GB',
      },
    })

    if (detailsResponse.ok) {
      const detailsData = await detailsResponse.json()
      console.log(JSON.stringify(detailsData, null, 2))
    } else {
      console.error('❌ Details fetch failed:', detailsResponse.status)
    }
  }

  console.log('\n' + '═'.repeat(80))
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message)
  console.error(err)
  process.exit(1)
})
