#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function check() {
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString()

  const { data, error } = await supabase
    .from('master_market_data')
    .select('region_code, is_consigned, size_key')
    .eq('provider', 'alias')
    .eq('sku', 'M2002RDB')
    .gte('snapshot_at', fiveMinutesAgo)
    .order('region_code')
    .order('is_consigned')

  if (error) {
    console.error('Error:', error.message)
    return
  }

  // Group by region and consigned flag
  const breakdown = data.reduce((acc, row) => {
    const key = `${row.region_code}_${row.is_consigned ? 'consigned' : 'non_consigned'}`
    acc[key] = (acc[key] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  console.log('='.repeat(80))
  console.log('ALIAS DATA BREAKDOWN (Consigned vs Non-Consigned)')
  console.log('='.repeat(80))
  console.log('Total records:', data.length)
  console.log('')
  console.log('By Region & Consignment Status:')
  Object.entries(breakdown)
    .sort()
    .forEach(([key, count]) => {
      const [region, type] = key.split('_')
      console.log(`  ${region.padEnd(3)} | ${type.padEnd(14)}: ${count} records`)
    })

  const totalConsigned = data.filter(r => r.is_consigned).length
  const totalNonConsigned = data.filter(r => !r.is_consigned).length

  console.log('')
  console.log('Overall Totals:')
  console.log(`  Consigned:     ${totalConsigned}`)
  console.log(`  Non-consigned: ${totalNonConsigned}`)
  console.log('='.repeat(80))
}

check()
