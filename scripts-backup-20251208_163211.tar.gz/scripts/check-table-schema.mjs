import { createClient } from '@supabase/supabase-js'
import 'dotenv/config'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

// Check stockx_variants schema
const { data, error } = await supabase
  .from('stockx_variants')
  .select('*')
  .limit(1)

if (error) console.error('Error:', error)
else console.log('stockx_variants columns:', Object.keys(data[0] || {}))

// Check stockx_market_snapshots schema  
const { data: snapData, error: snapError } = await supabase
  .from('stockx_market_snapshots')
  .select('*')
  .limit(1)

if (snapError) console.error('Error:', snapError)
else console.log('stockx_market_snapshots columns:', Object.keys(snapData[0] || {}))
