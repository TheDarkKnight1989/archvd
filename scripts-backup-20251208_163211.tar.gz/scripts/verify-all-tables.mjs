#!/usr/bin/env node

/**
 * Verify all Alias integration tables exist
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

async function checkTable(tableName) {
  const { data, error } = await supabase
    .from(tableName)
    .select('*')
    .limit(1)

  if (error) {
    if (error.code === '42P01') {
      return { exists: false, error: 'Table does not exist' }
    }
    return { exists: false, error: error.message }
  }

  return { exists: true }
}

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS INTEGRATION - TABLE VERIFICATION')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const tables = [
    { name: 'master_market_data', description: 'Unified market data from all providers' },
    { name: 'master_market_latest', description: 'Materialized view of latest prices' },
    { name: 'stockx_raw_snapshots', description: 'StockX API response audit trail' },
    { name: 'alias_raw_snapshots', description: 'Alias API response audit trail' },
    { name: 'alias_offer_histograms', description: 'Alias bid depth chart data' },
  ]

  let allExist = true

  for (const table of tables) {
    const result = await checkTable(table.name)
    const status = result.exists ? '✅' : '❌'
    console.log(`${status} ${table.name}`)
    console.log(`   ${table.description}`)

    if (!result.exists) {
      console.log(`   Error: ${result.error}`)
      allExist = false
    }
    console.log()
  }

  console.log('═══════════════════════════════════════════════════════════════════════════')
  if (allExist) {
    console.log('✅ ALL TABLES EXIST - Ready for Alias integration!')
    console.log()
    console.log('Next steps:')
    console.log('  1. Test histogram integration: npm run test:alias:histograms')
    console.log('  2. Test full sync: npm run test:alias:integration')
    console.log('  3. Run final audit on a random SKU')
  } else {
    console.log('❌ SOME TABLES MISSING - Review migration errors above')
  }
  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
