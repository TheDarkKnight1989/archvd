#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function checkStatus() {
  const { data: syncedData } = await supabase
    .from('master_market_data')
    .select('provider_product_id')
    .eq('provider', 'stockx')

  const syncedIds = new Set(syncedData?.map(r => r.provider_product_id).filter(Boolean))

  const { count: totalProducts } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true })

  console.log(`Synced: ${syncedIds.size}/${totalProducts}`)
  console.log(`Remaining: ${(totalProducts || 0) - syncedIds.size}`)
}

checkStatus()
