#!/usr/bin/env npx tsx
/**
 * StockX 3 End-to-End Sync Attempts
 * Test sync for 5 products, 3 times to identify patterns in failures
 */

import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function testStockXSync() {
  console.log('🧪 StockX 3 End-to-End Sync Attempts\n')

  // Get 5 test products with StockX mapping
  const { data: products, error } = await supabase
    .from('products')
    .select(`
      sku,
      model,
      product_variants!inner (
        stockx_product_id
      )
    `)
    .not('product_variants.stockx_product_id', 'is', null)
    .limit(5)

  if (error || !products || products.length === 0) {
    console.error('❌ Failed to fetch test products:', error?.message)
    return
  }

  console.log(`Testing ${products.length} products with 3 attempts each\n`)
  console.log('Products:', products.map(p => p.sku).join(', '))
  console.log('='.repeat(80) + '\n')

  const results: any[] = []

  for (let attempt = 1; attempt <= 3; attempt++) {
    console.log(`\n${'='.repeat(80)}`)
    console.log(`ATTEMPT ${attempt}/3`)
    console.log('='.repeat(80) + '\n')

    for (const product of products) {
      const variants = product.product_variants as any[]
      const stockxProductId = variants[0]?.stockx_product_id

      if (!stockxProductId) continue

      console.log(`\n[${attempt}] Testing: ${product.sku} (StockX ID: ${stockxProductId})`)

      try {
        const startTime = Date.now()
        const result = await syncProductAllRegions(
          undefined,
          stockxProductId,
          'UK',
          false // Don't sync secondary regions to save time
        )
        const duration = Date.now() - startTime

        if (result.success) {
          console.log(`  ✅ SUCCESS (${duration}ms)`)
          console.log(`     Snapshots: ${result.totalSnapshotsCreated}`)
          console.log(`     Primary Region: ${result.primaryRegion}`)

          results.push({
            attempt,
            sku: product.sku,
            stockxProductId,
            success: true,
            snapshots: result.totalSnapshotsCreated,
            duration,
          })
        } else {
          console.log(`  ❌ FAILED (${duration}ms)`)
          console.log(`     Error: ${result.error || 'Unknown'}`)

          results.push({
            attempt,
            sku: product.sku,
            stockxProductId,
            success: false,
            error: result.error || 'Unknown',
            duration,
          })
        }
      } catch (error: any) {
        console.log(`  ❌ EXCEPTION`)
        console.log(`     Error: ${error.message}`)
        console.log(`     Stack: ${error.stack?.split('\n')[1]?.trim()}`)

        results.push({
          attempt,
          sku: product.sku,
          stockxProductId,
          success: false,
          error: error.message,
          exception: true,
        })
      }

      // Small delay between products
      await new Promise(resolve => setTimeout(resolve, 1000))
    }

    // Delay between attempts
    if (attempt < 3) {
      console.log('\n⏳ Waiting 5 seconds before next attempt...')
      await new Promise(resolve => setTimeout(resolve, 5000))
    }
  }

  // Analysis
  console.log('\n\n' + '='.repeat(80))
  console.log('ANALYSIS')
  console.log('='.repeat(80) + '\n')

  const successCount = results.filter(r => r.success).length
  const failureCount = results.filter(r => !r.success).length
  const successRate = (successCount / results.length) * 100

  console.log(`Total Tests: ${results.length}`)
  console.log(`Successes: ${successCount} (${successRate.toFixed(1)}%)`)
  console.log(`Failures: ${failureCount} (${(100 - successRate).toFixed(1)}%)`)

  // Group failures by error type
  const errorsByType = results
    .filter(r => !r.success)
    .reduce((acc, r) => {
      const errorKey = r.error || 'Unknown'
      acc[errorKey] = (acc[errorKey] || 0) + 1
      return acc
    }, {} as Record<string, number>)

  if (Object.keys(errorsByType).length > 0) {
    console.log('\n📊 Errors by Type:')
    for (const [error, count] of Object.entries(errorsByType)) {
      console.log(`  ${count}x: ${error}`)
    }
  }

  // Check for consistent failures
  const failuresBySku = results
    .filter(r => !r.success)
    .reduce((acc, r) => {
      acc[r.sku] = (acc[r.sku] || 0) + 1
      return acc
    }, {} as Record<string, number>)

  const alwaysFailingSkus = Object.entries(failuresBySku)
    .filter(([_, count]) => count === 3)
    .map(([sku]) => sku)

  if (alwaysFailingSkus.length > 0) {
    console.log('\n❌ Products that ALWAYS fail (all 3 attempts):')
    alwaysFailingSkus.forEach(sku => console.log(`  - ${sku}`))
  }

  // Check for intermittent failures
  const intermittentSkus = Object.entries(failuresBySku)
    .filter(([_, count]) => count > 0 && count < 3)
    .map(([sku]) => sku)

  if (intermittentSkus.length > 0) {
    console.log('\n⚠️  Products with INTERMITTENT failures:')
    intermittentSkus.forEach(sku => {
      const failures = failuresBySku[sku]
      console.log(`  - ${sku} (${failures}/3 failed)`)
    })
  }

  // Performance analysis
  const successfulResults = results.filter(r => r.success && r.duration)
  if (successfulResults.length > 0) {
    const avgDuration = successfulResults.reduce((sum, r) => sum + r.duration, 0) / successfulResults.length
    const maxDuration = Math.max(...successfulResults.map(r => r.duration))
    const minDuration = Math.min(...successfulResults.map(r => r.duration))

    console.log('\n⏱️  Performance (successful syncs):')
    console.log(`  Average: ${avgDuration.toFixed(0)}ms`)
    console.log(`  Min: ${minDuration}ms`)
    console.log(`  Max: ${maxDuration}ms`)
  }

  console.log('\n' + '='.repeat(80))
}

testStockXSync().catch(console.error)
