/**
 * Test Alias histogram integration
 * Verifies histogram data is fetched and stored correctly
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { syncAliasToMasterMarketData } from '@/lib/services/alias/sync'
import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS HISTOGRAM INTEGRATION TEST')
  console.log('SKU:', SKU)
  console.log('Feature Flag:', process.env.ALIAS_HISTOGRAMS_ENABLED)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  if (process.env.ALIAS_HISTOGRAMS_ENABLED !== 'true') {
    console.log('❌ ALIAS_HISTOGRAMS_ENABLED is not set to "true"')
    console.log('   Please run: export ALIAS_HISTOGRAMS_ENABLED=true')
    process.exit(1)
  }

  const client = createAliasClient()
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  // Search for product
  console.log('Step 1: Searching for product...')
  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const product = searchResults.catalog_items[0]

  console.log(`Found: ${product.name}`)
  console.log(`Catalog ID: ${product.catalog_id}\n`)

  // Clear existing histogram data
  console.log('Step 2: Clearing existing histogram data...')
  const { error: clearError } = await supabase
    .from('alias_offer_histograms')
    .delete()
    .eq('sku', SKU)

  if (clearError && clearError.code !== 'PGRST116') { // PGRST116 = no rows deleted
    console.error('❌ Failed to clear existing data:', clearError)
    process.exit(1)
  }

  console.log('✅ Cleared\n')

  // Run sync with histograms enabled
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('Step 3: Running sync (with histograms enabled)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const syncResult = await syncAliasToMasterMarketData(client, product.catalog_id, {
    sku: SKU,
  })

  console.log('\nSync Result:')
  console.log(JSON.stringify(syncResult, null, 2))
  console.log()

  if (!syncResult.success) {
    console.error('❌ SYNC FAILED:', syncResult.error)
    process.exit(1)
  }

  // Verify histogram data in database
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('Step 4: Verifying histogram data in database')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const { data: histograms, error: queryError } = await supabase
    .from('alias_offer_histograms')
    .select('*')
    .eq('sku', SKU)
    .order('size_value')
    .order('price_cents', { ascending: false })

  if (queryError) {
    console.error('❌ Query failed:', queryError)
    process.exit(1)
  }

  if (!histograms || histograms.length === 0) {
    console.log('❌ NO HISTOGRAM DATA FOUND IN DATABASE!')
    process.exit(1)
  }

  console.log(`✅ Found ${histograms.length} histogram bins`)
  console.log()

  // Group by size
  const bySizeMap = new Map<number, any[]>()
  for (const bin of histograms) {
    const size = bin.size_value
    if (!bySizeMap.has(size)) {
      bySizeMap.set(size, [])
    }
    bySizeMap.get(size)!.push(bin)
  }

  console.log(`Histogram data for ${bySizeMap.size} sizes:\n`)

  // Show sample data for first 3 sizes
  let count = 0
  for (const [size, bins] of bySizeMap.entries()) {
    if (count >= 3) break

    console.log(`Size ${size}:`)
    console.log(`  Total bins: ${bins.length}`)
    console.log(`  Total offers: ${bins.reduce((sum, b) => sum + b.offer_count, 0)}`)
    console.log(`  Price range: $${bins[bins.length - 1].price_cents / 100} - $${bins[0].price_cents / 100}`)
    console.log(`  Top 3 price levels:`)
    bins.slice(0, 3).forEach(bin => {
      console.log(`    $${bin.price_cents / 100}: ${bin.offer_count} offers`)
    })
    console.log()

    count++
  }

  // Summary stats
  const totalBins = histograms.length
  const totalOffers = histograms.reduce((sum, bin) => sum + bin.offer_count, 0)
  const avgBinsPerSize = totalBins / bySizeMap.size

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('SUMMARY')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  console.log('✅ Histogram integration WORKING!')
  console.log(`   - ${bySizeMap.size} sizes have histogram data`)
  console.log(`   - ${totalBins} total price level bins`)
  console.log(`   - ${totalOffers} total offers tracked`)
  console.log(`   - Avg ${avgBinsPerSize.toFixed(1)} price levels per size`)
  console.log()
  console.log('✅ Ready for depth chart visualization!')
  console.log()
}

main().catch(console.error)
