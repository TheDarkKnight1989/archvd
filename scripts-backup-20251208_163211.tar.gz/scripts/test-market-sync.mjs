#!/usr/bin/env node
/**
 * Test market data sync for products with Alias catalog IDs
 */
import { createClient } from '@supabase/supabase-js'
import { createAliasClient } from '../src/lib/services/alias/client.ts'
import { listAvailabilitiesForCatalog } from '../src/lib/services/alias/pricing.ts'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('🧪 Testing market data sync...\n')

// Find products with Alias catalog IDs
const { data: products } = await supabase
  .from('products')
  .select(`
    id,
    sku,
    brand,
    model,
    product_variants (
      id,
      size_key,
      size_numeric,
      alias_catalog_id
    )
  `)
  .not('product_variants.alias_catalog_id', 'is', null)
  .limit(3)

if (!products || products.length === 0) {
  console.log('❌ No products with Alias catalog IDs found')
  process.exit(0)
}

console.log(`✅ Found ${products.length} products with Alias catalog IDs\n`)

for (const product of products) {
  const aliasVariant = product.product_variants.find(v => v.alias_catalog_id)
  
  if (!aliasVariant) continue
  
  console.log(`Testing: ${product.sku}`)
  console.log(`  Alias catalog ID: ${aliasVariant.alias_catalog_id}`)
  
  try {
    const aliasClient = createAliasClient()
    const availabilities = await listAvailabilitiesForCatalog(aliasClient, aliasVariant.alias_catalog_id)
    
    console.log(`  ✅ Found ${availabilities.length} availabilities from Alias`)
    
    if (availabilities.length > 0) {
      const sample = availabilities[0]
      console.log(`  Sample: Size ${sample.size} - Ask: $${(sample.lowestAskCents || 0) / 100}, Bid: $${(sample.highestBidCents || 0) / 100}`)
    }
    
  } catch (error) {
    console.log(`  ❌ Error: ${error.message}`)
  }
  
  console.log('')
}

console.log('✅ Test complete')
