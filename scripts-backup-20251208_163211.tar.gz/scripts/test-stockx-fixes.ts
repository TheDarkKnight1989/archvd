#!/usr/bin/env npx tsx
/**
 * Test StockX Fixes
 * Verifies:
 * 1. Price conversion bug fix (prices stored in cents, not dollars)
 * 2. Gender-based size filtering (only 3.5-16 for men's sneakers)
 */

import { createClient } from '@supabase/supabase-js';
import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function testStockXFixes() {
  console.log('🧪 TESTING STOCKX FIXES\n');
  console.log('='.repeat(80));

  // Test product: BQ6817-600 (Air Jordan 1 Retro High OG "Satin Black Toe")
  const testSKU = 'BQ6817-600';

  // ========================================================================
  // Step 1: Clean existing data for this SKU
  // ========================================================================

  console.log('\n📝 Step 1: Cleaning existing StockX data for', testSKU);

  const { error: deleteError } = await supabase
    .from('master_market_data')
    .delete()
    .eq('provider', 'stockx')
    .eq('sku', testSKU);

  if (deleteError) {
    console.error('❌ Failed to delete old data:', deleteError.message);
    return;
  }

  console.log('✅ Cleaned old data\n');

  // ========================================================================
  // Step 2: Get StockX product ID for this SKU
  // ========================================================================

  console.log('📝 Step 2: Looking up StockX product ID...');

  const { data: productData, error: productError } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id')
    .eq('style_id', testSKU)
    .single();

  if (productError || !productData) {
    console.error('❌ Product not found:', productError?.message);
    return;
  }

  const stockxProductId = productData.stockx_product_id;
  console.log('✅ Found product ID:', stockxProductId, '\n');

  // ========================================================================
  // Step 3: Check product metadata (for gender-based filtering)
  // ========================================================================

  console.log('📝 Step 3: Checking product metadata...');

  const { data: catalogData } = await supabase
    .from('product_catalog')
    .select('sku, gender, category')
    .eq('sku', testSKU)
    .single();

  if (catalogData) {
    console.log('Product metadata:');
    console.log('  SKU:', catalogData.sku);
    console.log('  Gender:', catalogData.gender || 'NULL');
    console.log('  Category:', catalogData.category || 'NULL');
  } else {
    console.log('⚠️  No product metadata found - will use defaults');
  }

  console.log('\n');

  // ========================================================================
  // Step 4: Sync UK region only (faster test)
  // ========================================================================

  console.log('📝 Step 4: Syncing UK region...\n');

  const result = await syncProductAllRegions(
    undefined, // No userId (use client credentials)
    stockxProductId,
    'UK',
    false // Don't sync other regions for faster test
  );

  if (!result.success) {
    console.error('❌ Sync failed:', result.primaryResult.error);
    return;
  }

  console.log('\n✅ Sync completed:', {
    variantsCached: result.primaryResult.variantsCached,
    snapshotsCreated: result.primaryResult.snapshotsCreated,
  });

  console.log('\n' + '='.repeat(80));

  // ========================================================================
  // Step 5: Verify the fixes
  // ========================================================================

  console.log('\n📝 Step 5: Verifying fixes...\n');

  const { data: syncedData, error: queryError } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')
    .eq('sku', testSKU)
    .eq('region_code', 'UK')
    .eq('is_flex', false) // Check standard pricing first
    .order('size_numeric');

  if (queryError || !syncedData || syncedData.length === 0) {
    console.error('❌ No data found after sync:', queryError?.message);
    return;
  }

  console.log(`Found ${syncedData.length} records\n`);

  // ========================================================================
  // FIX #1: Price Conversion Verification
  // ========================================================================

  console.log('🔍 FIX #1: Price Conversion (should be in CENTS)\n');

  const sampleRecord = syncedData[0];
  const lowestAsk = sampleRecord.lowest_ask;
  const highestBid = sampleRecord.highest_bid;

  console.log('Sample record (size', sampleRecord.size_key + '):');
  console.log('  Raw DB value (lowest_ask):', lowestAsk);
  console.log('  Display value:', `£${(lowestAsk / 100).toFixed(2)}`);
  console.log('  Raw DB value (highest_bid):', highestBid);
  console.log('  Display value:', `£${(highestBid / 100).toFixed(2)}`);

  // Check if prices are in reasonable range (cents, not dollars)
  const isPriceInCents = lowestAsk > 1000; // £10+ is reasonable for sneakers

  if (isPriceInCents) {
    console.log('\n✅ PASS: Prices are in cents (multiply by 100 working)');
  } else {
    console.log('\n❌ FAIL: Prices appear to be in dollars (bug not fixed)');
  }

  console.log('\n' + '-'.repeat(80) + '\n');

  // ========================================================================
  // FIX #2: Size Filtering Verification
  // ========================================================================

  console.log('🔍 FIX #2: Gender-Based Size Filtering\n');

  const sizes = syncedData.map(r => r.size_numeric).filter(Boolean).sort((a, b) => a - b);
  const uniqueSizes = [...new Set(sizes)];

  console.log('Size range:', Math.min(...uniqueSizes), 'to', Math.max(...uniqueSizes));
  console.log('Unique sizes:', uniqueSizes.length);
  console.log('All sizes:', uniqueSizes.join(', '));

  // Check for invalid sizes
  const invalidSizes = uniqueSizes.filter(size => size < 3.5 || size > 16);

  if (invalidSizes.length === 0) {
    console.log('\n✅ PASS: All sizes are in valid range (3.5-16)');
  } else {
    console.log('\n❌ FAIL: Found invalid sizes:', invalidSizes.join(', '));
  }

  console.log('\n' + '-'.repeat(80) + '\n');

  // ========================================================================
  // FIX #3: Pricing Coverage Verification
  // ========================================================================

  console.log('🔍 FIX #3: Pricing Coverage (should be 100%)\n');

  const recordsWithPricing = syncedData.filter(r => r.lowest_ask || r.highest_bid || r.last_sale_price);
  const coveragePercent = (recordsWithPricing.length / syncedData.length) * 100;

  console.log('Records with pricing:', recordsWithPricing.length, '/', syncedData.length);
  console.log('Coverage:', coveragePercent.toFixed(2) + '%');

  if (coveragePercent === 100) {
    console.log('\n✅ PASS: 100% pricing coverage');
  } else {
    console.log('\n⚠️  Warning: Some records missing pricing');
  }

  console.log('\n' + '-'.repeat(80) + '\n');

  // ========================================================================
  // Display sample records
  // ========================================================================

  console.log('📊 Sample Records:\n');
  console.log('Size | Lowest Ask  | Highest Bid | Last Sale');
  console.log('-----|-------------|-------------|----------');

  syncedData.slice(0, 10).forEach(r => {
    const ask = r.lowest_ask ? `£${(r.lowest_ask / 100).toFixed(2)}` : 'NULL';
    const bid = r.highest_bid ? `£${(r.highest_bid / 100).toFixed(2)}` : 'NULL';
    const sale = r.last_sale_price ? `£${(r.last_sale_price / 100).toFixed(2)}` : 'NULL';

    console.log(
      `${r.size_key.toString().padEnd(4)} | ${ask.padEnd(11)} | ${bid.padEnd(11)} | ${sale}`
    );
  });

  console.log('\n' + '='.repeat(80));

  // ========================================================================
  // Final Summary
  // ========================================================================

  const allTestsPassed = isPriceInCents && invalidSizes.length === 0 && coveragePercent === 100;

  console.log('\n🎯 FINAL RESULTS:\n');
  console.log(`  ${isPriceInCents ? '✅' : '❌'} Price conversion fix (multiply by 100)`);
  console.log(`  ${invalidSizes.length === 0 ? '✅' : '❌'} Size filtering fix (3.5-16)`);
  console.log(`  ${coveragePercent === 100 ? '✅' : '⚠️ '} Pricing coverage (${coveragePercent.toFixed(0)}%)`);

  if (allTestsPassed) {
    console.log('\n🎉 All fixes verified successfully!');
  } else {
    console.log('\n⚠️  Some issues detected - review above');
  }

  console.log('\n' + '='.repeat(80));
}

testStockXFixes();
