/**
 * Clean up test StockX data from master_market_data
 * Run this to remove test rows created during development
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('═══════════════════════════════════════════════════════════════════════════')
console.log('CLEANUP STOCKX TEST DATA')
console.log('═══════════════════════════════════════════════════════════════════════════\n')

// Count rows before deletion
const { count: beforeCount, error: countError } = await supabase
  .from('master_market_data')
  .select('*', { count: 'exact', head: true })
  .eq('provider', 'stockx')

if (countError) {
  console.error('❌ Error counting rows:', countError)
  process.exit(1)
}

console.log(`Rows to delete: ${beforeCount}`)

if (beforeCount === 0) {
  console.log('✅ No StockX rows to delete\n')
  process.exit(0)
}

// Delete all StockX rows
console.log('\n🗑️  Deleting StockX rows...')

const { error: deleteError } = await supabase
  .from('master_market_data')
  .delete()
  .eq('provider', 'stockx')

if (deleteError) {
  console.error('❌ Error deleting rows:', deleteError)
  process.exit(1)
}

// Verify deletion
const { count: afterCount, error: verifyError } = await supabase
  .from('master_market_data')
  .select('*', { count: 'exact', head: true })
  .eq('provider', 'stockx')

if (verifyError) {
  console.error('❌ Error verifying deletion:', verifyError)
  process.exit(1)
}

console.log('\n═══════════════════════════════════════════════════════════════════════════')
console.log('CLEANUP COMPLETE')
console.log('═══════════════════════════════════════════════════════════════════════════\n')

console.log(`Rows deleted: ${beforeCount}`)
console.log(`Rows remaining: ${afterCount}`)
console.log(`✅ Success!\n`)
