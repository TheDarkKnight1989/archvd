#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function checkWhichProducts() {
  // Get products synced in the last hour
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString()

  const { data: recentSyncs } = await supabase
    .from('master_market_data')
    .select('provider_product_id, sku')
    .eq('provider', 'stockx')
    .gte('created_at', oneHourAgo)
    .order('created_at', { ascending: false })

  const uniqueProductIds = [...new Set(recentSyncs?.map(r => r.provider_product_id))]
  const uniqueSKUs = [...new Set(recentSyncs?.map(r => r.sku).filter(Boolean))]

  console.log('\n📦 Products Synced in Last Hour\n')
  console.log('─'.repeat(75))
  console.log(`Unique StockX Product IDs: ${uniqueProductIds.length}`)
  console.log(`Unique SKUs:               ${uniqueSKUs.length}`)
  console.log('\n📋 SKU List:')
  uniqueSKUs.forEach((sku, i) => {
    console.log(`  ${(i + 1).toString().padStart(2)}. ${sku}`)
  })

  // Check total products in stockx_products table
  const { data: allStockXProducts } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id')
    .order('style_id')

  const syncedStockXIds = new Set(uniqueProductIds)
  const unsyncedProducts = allStockXProducts?.filter(p => !syncedStockXIds.has(p.stockx_product_id))

  console.log(`\n❌ Unsynced Products: ${unsyncedProducts?.length || 0}`)
  if (unsyncedProducts && unsyncedProducts.length > 0 && unsyncedProducts.length <= 20) {
    console.log('\n📋 Unsynced SKU Sample (first 20):')
    unsyncedProducts.slice(0, 20).forEach((p, i) => {
      console.log(`  ${(i + 1).toString().padStart(2)}. ${p.style_id}`)
    })
  }

  console.log('─'.repeat(75))
}

checkWhichProducts()
