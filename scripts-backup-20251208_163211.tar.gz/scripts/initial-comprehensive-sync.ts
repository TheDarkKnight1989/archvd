#!/usr/bin/env npx tsx
/**
 * Initial Comprehensive Sync - Populate ALL market data for 112 products
 *
 * Syncs BOTH Alias and StockX data for every product:
 * - Multi-region pricing
 * - Histograms
 * - Recent sales
 * - Flex pricing
 * - Pricing suggestions
 */

import { createClient } from '@supabase/supabase-js'
import { AliasClient } from '../src/lib/services/alias/client'
import { syncAliasProductMultiRegion } from '../src/lib/services/alias/sync'
import { syncProductAllRegions } from '../src/lib/services/stockx/market-refresh'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🚀 Initial Comprehensive Market Data Sync')
  console.log('='.repeat(80))
  console.log('Syncing ALL data from BOTH platforms for all 112 products')
  console.log('This will take approximately 10-15 minutes...\n')

  // Get all products with mappings
  const { data: products } = await supabase
    .from('products')
    .select(`
      id,
      sku,
      brand,
      model,
      product_variants (
        id,
        size_key,
        alias_catalog_id,
        stockx_product_id
      )
    `)
    .order('sku')

  console.log(`📦 Total products: ${products?.length || 0}\n`)

  // Initialize Alias client with PAT
  const aliasPat = process.env.ALIAS_PAT
  if (!aliasPat) {
    console.error('❌ ALIAS_PAT environment variable not set')
    return
  }
  const aliasClient = new AliasClient(aliasPat)

  let synced = 0
  let errors = 0
  let totalAliasVariants = 0
  let totalStockXSnapshots = 0
  let skipped = 0

  // Process in small batches to avoid overwhelming the APIs
  const BATCH_SIZE = 3
  const totalBatches = Math.ceil((products?.length || 0) / BATCH_SIZE)

  for (let batchIndex = 0; batchIndex < totalBatches; batchIndex++) {
    const start = batchIndex * BATCH_SIZE
    const end = start + BATCH_SIZE
    const batch = products?.slice(start, end) || []

    console.log(`\n${'='.repeat(80)}`)
    console.log(`Batch ${batchIndex + 1}/${totalBatches} (products ${start + 1}-${Math.min(end, products?.length || 0)})`)
    console.log('='.repeat(80))

    // Process batch in parallel
    await Promise.allSettled(
      batch.map(async (product) => {
        try {
          console.log(`\n🔄 ${product.sku} - ${product.brand} ${product.model}`)

          const aliasVariant = product.product_variants.find((v: any) => v.alias_catalog_id)
          const stockxVariant = product.product_variants.find((v: any) => v.stockx_product_id)

          let syncedThisProduct = false

          // Sync Alias data
          if (aliasVariant?.alias_catalog_id) {
            try {
              const result = await syncAliasProductMultiRegion(
                aliasClient,
                aliasVariant.alias_catalog_id,
                {
                  sku: product.sku,
                  userRegion: 'UK',
                  syncSecondaryRegions: true,
                }
              )

              if (result.success) {
                totalAliasVariants += result.totalVariantsIngested
                syncedThisProduct = true
                console.log(`  ✅ Alias: ${result.totalVariantsIngested} variants (${result.secondaryResults?.length || 0} secondary regions)`)
              } else {
                console.log(`  ⚠️  Alias: ${result.primaryResult.error}`)
              }
            } catch (error: any) {
              console.log(`  ❌ Alias error: ${error.message}`)
            }
          } else {
            console.log(`  ⏭️  Alias: No mapping`)
          }

          // Sync StockX data
          if (stockxVariant?.stockx_product_id) {
            try {
              const result = await syncProductAllRegions(
                undefined,
                stockxVariant.stockx_product_id,
                'UK',
                true
              )

              if (result.success) {
                totalStockXSnapshots += result.totalSnapshotsCreated
                syncedThisProduct = true
                console.log(`  ✅ StockX: ${result.totalSnapshotsCreated} snapshots (${result.secondaryResults?.length || 0} secondary regions)`)
              } else {
                console.log(`  ⚠️  StockX: ${result.primaryResult.error}`)
              }
            } catch (error: any) {
              console.log(`  ❌ StockX error: ${error.message}`)
            }
          } else {
            console.log(`  ⏭️  StockX: No mapping`)
          }

          if (syncedThisProduct) {
            synced++
          } else {
            skipped++
          }

        } catch (error: any) {
          console.log(`  ❌ Failed: ${error.message}`)
          errors++
        }
      })
    )

    // Delay between batches to respect rate limits
    if (batchIndex < totalBatches - 1) {
      console.log(`\n⏳ Waiting 3 seconds before next batch...`)
      await new Promise(resolve => setTimeout(resolve, 3000))
    }
  }

  // Update last_synced_at for all products
  await supabase
    .from('products')
    .update({ last_synced_at: new Date().toISOString() })
    .in('id', products?.map(p => p.id) || [])

  // Final summary
  console.log('\n' + '='.repeat(80))
  console.log('🎉 INITIAL COMPREHENSIVE SYNC COMPLETE')
  console.log('='.repeat(80))
  console.log(`✅ Products synced: ${synced}`)
  console.log(`⏭️  Products skipped: ${skipped}`)
  console.log(`❌ Errors: ${errors}`)
  console.log(`📊 Total Alias variants: ${totalAliasVariants}`)
  console.log(`📊 Total StockX snapshots: ${totalStockXSnapshots}`)
  console.log(`📦 Total products processed: ${products?.length || 0}`)

  // Check total data in database
  const { count: totalMarketData } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })

  const { count: aliasData } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'alias')

  const { count: stockxData } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')

  console.log('\n📊 Master Market Data Summary:')
  console.log(`  Total records: ${totalMarketData}`)
  console.log(`  Alias records: ${aliasData}`)
  console.log(`  StockX records: ${stockxData}`)

  console.log('\n✨ Your 112 products now have comprehensive market data from BOTH platforms!')
  console.log('')
}

main().catch(console.error)
