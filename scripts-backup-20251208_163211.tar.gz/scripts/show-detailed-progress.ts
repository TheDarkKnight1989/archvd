#!/usr/bin/env npx tsx
/**
 * Show detailed per-variant, per-SKU breakdown of synced data
 */
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function showDetailedProgress() {
  console.log('═══════════════════════════════════════════════════════════');
  console.log('DETAILED STOCKX SYNC PROGRESS - Per Variant Breakdown');
  console.log('═══════════════════════════════════════════════════════════\n');

  // Get all StockX data, ordered by most recent
  const { data: allData } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')
    .order('created_at', { ascending: false });

  if (!allData || allData.length === 0) {
    console.log('❌ NO STOCKX DATA YET\n');
    return;
  }

  // Group by SKU
  const bySku = new Map<string, any[]>();
  allData.forEach(row => {
    if (!bySku.has(row.sku)) {
      bySku.set(row.sku, []);
    }
    bySku.get(row.sku)!.push(row);
  });

  console.log(`Total SKUs synced: ${bySku.size}`);
  console.log(`Total data rows: ${allData.length}\n`);

  // Show each SKU with ALL variants
  let skuNum = 1;
  for (const [sku, rows] of Array.from(bySku.entries()).reverse()) {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`[${skuNum}/${bySku.size}] SKU: ${sku}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    // Get unique sizes
    const sizes = new Map<string, any[]>();
    rows.forEach(row => {
      if (!sizes.has(row.size_key)) {
        sizes.set(row.size_key, []);
      }
      sizes.get(row.size_key)!.push(row);
    });

    console.log(`Variants synced: ${sizes.size}`);
    console.log(`Total data points: ${rows.length}\n`);

    // Show EVERY variant with details
    for (const [size, sizeRows] of sizes) {
      console.log(`  Size: ${size}`);

      for (const row of sizeRows) {
        const lowestAsk = row.lowest_ask ? `$${(row.lowest_ask / 100).toFixed(2)}` : 'N/A';
        const highestBid = row.highest_bid ? `$${(row.highest_bid / 100).toFixed(2)}` : 'N/A';

        const flags = [];
        if (row.is_flex) flags.push('FLEX');
        if (row.is_consigned) flags.push('CONSIGNED');
        const flagStr = flags.length > 0 ? ` [${flags.join(', ')}]` : '';

        console.log(`    ${row.region_code} (${row.currency_code}): Ask=${lowestAsk} | Bid=${highestBid}${flagStr}`);

        if (row.last_sale_price) {
          const lastSale = `$${(row.last_sale_price / 100).toFixed(2)}`;
          console.log(`      Last Sale: ${lastSale}`);
        }

        if (row.number_of_asks !== null || row.number_of_bids !== null) {
          console.log(`      Asks: ${row.number_of_asks || 0} | Bids: ${row.number_of_bids || 0}`);
        }

        if (row.sales_last_72h !== null) {
          console.log(`      Sales (72h): ${row.sales_last_72h}`);
        }
      }
      console.log('');
    }

    console.log('');
    skuNum++;
  }

  console.log('═══════════════════════════════════════════════════════════');
}

showDetailedProgress();
