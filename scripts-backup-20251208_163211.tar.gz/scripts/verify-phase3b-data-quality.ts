#!/usr/bin/env npx tsx
/**
 * Comprehensive Data Quality Verification - Phase 3B
 *
 * Thoroughly validates that the synced StockX data is correct:
 * - Price conversion (all in cents, realistic values)
 * - Size filtering (all within 3.5-16 range)
 * - Regional coverage (US, UK, EU present)
 * - Data completeness (no nulls where unexpected)
 * - Deduplication (no duplicate records)
 */

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function verifyDataQuality() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║          COMPREHENSIVE DATA QUALITY VERIFICATION - Phase 3B           ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  const issues: string[] = [];
  const warnings: string[] = [];
  const passed: string[] = [];

  // =========================================================================
  // TEST 1: PRICE CONVERSION - All prices in cents (10,000+)
  // =========================================================================

  console.log('🔍 TEST 1: Price Conversion\n');
  console.log('─'.repeat(75));

  const { data: priceData } = await supabase
    .from('master_market_data')
    .select('sku, size_key, lowest_ask, highest_bid, region_code')
    .eq('provider', 'stockx')
    .not('lowest_ask', 'is', null)
    .order('lowest_ask', { ascending: true })
    .limit(100);

  console.log('Sample prices (lowest to highest):');
  priceData?.slice(0, 10).forEach((r, i) => {
    const price = r.lowest_ask / 100;
    const status = r.lowest_ask >= 1000 ? '✅' : '❌'; // Expect at least $10
    console.log(`  ${status} ${r.sku} size ${r.size_key} (${r.region_code}): $${price.toFixed(2)} (${r.lowest_ask} cents)`);
  });

  // Check for suspiciously low prices (< $10 = 1000 cents)
  const { count: lowPriceCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .not('lowest_ask', 'is', null)
    .lt('lowest_ask', 1000);

  // Check for suspiciously high prices (> $10,000 = 1,000,000 cents)
  const { count: highPriceCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .not('lowest_ask', 'is', null)
    .gt('lowest_ask', 1000000);

  console.log(`\nPrice Range Analysis:`);
  console.log(`  Low prices (<$10): ${lowPriceCount || 0}`);
  console.log(`  High prices (>$10k): ${highPriceCount || 0}`);

  if (lowPriceCount === 0 && highPriceCount === 0) {
    passed.push('✅ All prices in realistic range ($10-$10,000)');
  } else if ((lowPriceCount || 0) > 0) {
    warnings.push(`⚠️  ${lowPriceCount} prices below $10 - may indicate conversion issue`);
  }

  // Check average price
  const { data: avgPrice } = await supabase
    .from('master_market_data')
    .select('lowest_ask')
    .eq('provider', 'stockx')
    .not('lowest_ask', 'is', null);

  const avg = avgPrice?.reduce((sum, r) => sum + r.lowest_ask, 0)! / avgPrice?.length!;
  console.log(`  Average price: $${(avg / 100).toFixed(2)}`);

  if (avg >= 5000 && avg <= 50000) {
    passed.push('✅ Average price realistic ($50-$500)');
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // TEST 2: SIZE FILTERING - All sizes 3.5-16
  // =========================================================================

  console.log('🔍 TEST 2: Size Filtering\n');
  console.log('─'.repeat(75));

  const { data: sizeData } = await supabase
    .from('master_market_data')
    .select('size_numeric, size_key, sku')
    .eq('provider', 'stockx')
    .not('size_numeric', 'is', null);

  const sizes = sizeData?.map(r => r.size_numeric).filter(Boolean) || [];
  const minSize = Math.min(...sizes);
  const maxSize = Math.max(...sizes);

  console.log(`Size Range: ${minSize} - ${maxSize}`);

  // Check for invalid sizes
  const { count: invalidSizes } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .not('size_numeric', 'is', null)
    .or('size_numeric.lt.3.5,size_numeric.gt.16');

  console.log(`Invalid sizes (< 3.5 or > 16): ${invalidSizes || 0}`);

  if (invalidSizes === 0 && minSize >= 3.5 && maxSize <= 16) {
    passed.push('✅ All sizes within valid range (3.5-16)');
  } else {
    issues.push(`❌ Found ${invalidSizes} invalid sizes`);
  }

  // Size distribution
  const sizeCounts = sizeData?.reduce((acc, r) => {
    const bucket = Math.floor(r.size_numeric);
    acc[bucket] = (acc[bucket] || 0) + 1;
    return acc;
  }, {} as Record<number, number>) || {};

  console.log('\nSize Distribution:');
  Object.entries(sizeCounts)
    .sort((a, b) => parseInt(a[0]) - parseInt(b[0]))
    .forEach(([size, count]) => {
      const bar = '█'.repeat(Math.min(50, Math.floor(count / 100)));
      console.log(`  Size ${size}: ${count.toLocaleString().padStart(5)} ${bar}`);
    });

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // TEST 3: REGIONAL COVERAGE - US, UK, EU
  // =========================================================================

  console.log('🔍 TEST 3: Regional Coverage\n');
  console.log('─'.repeat(75));

  const { data: regionData } = await supabase
    .from('master_market_data')
    .select('region_code')
    .eq('provider', 'stockx');

  const regionCounts = regionData?.reduce((acc, r) => {
    acc[r.region_code || 'NULL'] = (acc[r.region_code || 'NULL'] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  console.log('Records by Region:');
  ['US', 'UK', 'EU'].forEach(region => {
    const count = regionCounts[region] || 0;
    const status = count > 0 ? '✅' : '❌';
    console.log(`  ${status} ${region}: ${count.toLocaleString().padStart(5)} records`);
  });

  const hasUS = (regionCounts['US'] || 0) > 0;
  const hasUK = (regionCounts['UK'] || 0) > 0;
  const hasEU = (regionCounts['EU'] || 0) > 0;

  if (hasUS && hasUK && hasEU) {
    passed.push('✅ All 3 regions present (US, UK, EU)');

    // Check balance
    const total = (regionCounts['US'] || 0) + (regionCounts['UK'] || 0) + (regionCounts['EU'] || 0);
    const usPercent = ((regionCounts['US'] || 0) / total) * 100;
    const ukPercent = ((regionCounts['UK'] || 0) / total) * 100;
    const euPercent = ((regionCounts['EU'] || 0) / total) * 100;

    console.log(`\nRegional Balance:`);
    console.log(`  US: ${usPercent.toFixed(1)}%`);
    console.log(`  UK: ${ukPercent.toFixed(1)}%`);
    console.log(`  EU: ${euPercent.toFixed(1)}%`);

    if (Math.abs(usPercent - 33.3) < 5 && Math.abs(ukPercent - 33.3) < 5 && Math.abs(euPercent - 33.3) < 5) {
      passed.push('✅ Regional distribution balanced (~33% each)');
    }
  } else {
    issues.push('❌ Missing one or more regions');
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // TEST 4: DATA COMPLETENESS - No unexpected nulls
  // =========================================================================

  console.log('🔍 TEST 4: Data Completeness\n');
  console.log('─'.repeat(75));

  // Check for null critical fields
  const { count: nullSKU } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .is('sku', null);

  const { count: nullSize } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .is('size_key', null);

  const { count: nullRegion } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .is('region_code', null);

  console.log('Null Field Check:');
  console.log(`  ${nullSKU === 0 ? '✅' : '❌'} NULL SKUs: ${nullSKU || 0}`);
  console.log(`  ${nullSize === 0 ? '✅' : '❌'} NULL sizes: ${nullSize || 0}`);
  console.log(`  ${nullRegion === 0 ? '✅' : '❌'} NULL regions: ${nullRegion || 0}`);

  if (nullSKU === 0 && nullSize === 0 && nullRegion === 0) {
    passed.push('✅ No null values in critical fields');
  } else {
    warnings.push(`⚠️  Found nulls: SKU=${nullSKU}, Size=${nullSize}, Region=${nullRegion}`);
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // TEST 5: DEDUPLICATION - No duplicate records
  // =========================================================================

  console.log('🔍 TEST 5: Deduplication\n');
  console.log('─'.repeat(75));

  // Manual duplicate check
  const { data: allRecords } = await supabase
    .from('master_market_data')
    .select('sku, size_key, region_code, pricing_mode')
    .eq('provider', 'stockx');

  const keys = new Set();
  let duplicateCount = 0;

  allRecords?.forEach(r => {
    const key = `${r.sku}|${r.size_key}|${r.region_code}|${r.pricing_mode}`;
    if (keys.has(key)) {
      duplicateCount++;
    }
    keys.add(key);
  });

  console.log(`Duplicate Check:`);
  console.log(`  ${duplicateCount === 0 ? '✅' : '❌'} Duplicate records: ${duplicateCount}`);

  if (duplicateCount === 0) {
    passed.push('✅ No duplicate records');
  } else {
    warnings.push(`⚠️  Found ${duplicateCount} duplicate records`);
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // TEST 6: PRODUCT COVERAGE - All 125 products synced
  // =========================================================================

  console.log('🔍 TEST 6: Product Coverage\n');
  console.log('─'.repeat(75));

  const { data: skus } = await supabase
    .from('master_market_data')
    .select('sku')
    .eq('provider', 'stockx');

  const uniqueSKUs = new Set(skus?.map(r => r.sku).filter(Boolean));

  console.log(`Unique SKUs in master_market_data: ${uniqueSKUs.size}`);

  // Compare with stockx_products
  const { count: stockxProductCount } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true });

  console.log(`Products in stockx_products: ${stockxProductCount || 0}`);

  if (uniqueSKUs.size === stockxProductCount) {
    passed.push('✅ All stockx_products synced to master_market_data');
  } else {
    warnings.push(`⚠️  SKU mismatch: ${uniqueSKUs.size} in master vs ${stockxProductCount} in stockx_products`);
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // TEST 7: SAMPLE DATA INSPECTION - Spot check 5 random products
  // =========================================================================

  console.log('🔍 TEST 7: Sample Data Inspection\n');
  console.log('─'.repeat(75));

  const { data: samples } = await supabase
    .from('master_market_data')
    .select('sku, size_key, lowest_ask, highest_bid, region_code, pricing_mode, size_numeric')
    .eq('provider', 'stockx')
    .not('lowest_ask', 'is', null)
    .limit(5);

  console.log('Random Sample Data:\n');
  samples?.forEach((r, i) => {
    const price = r.lowest_ask / 100;
    const bid = r.highest_bid ? (r.highest_bid / 100).toFixed(2) : 'N/A';
    console.log(`  ${i + 1}. ${r.sku} | Size ${r.size_key} (${r.size_numeric}) | ${r.region_code} | ${r.pricing_mode}`);
    console.log(`     Ask: $${price.toFixed(2)} | Bid: $${bid}`);
    console.log('');
  });

  console.log('─'.repeat(75) + '\n');

  // =========================================================================
  // FINAL SUMMARY
  // =========================================================================

  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║                        VERIFICATION SUMMARY                           ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  if (issues.length > 0) {
    console.log('🚨 CRITICAL ISSUES:\n');
    issues.forEach((issue, i) => {
      console.log(`  ${i + 1}. ${issue}`);
    });
    console.log('');
  }

  if (warnings.length > 0) {
    console.log('⚠️  WARNINGS:\n');
    warnings.forEach((warning, i) => {
      console.log(`  ${i + 1}. ${warning}`);
    });
    console.log('');
  }

  if (passed.length > 0) {
    console.log('✅ PASSED CHECKS:\n');
    passed.forEach((item, i) => {
      console.log(`  ${i + 1}. ${item}`);
    });
    console.log('');
  }

  console.log('─'.repeat(75));

  const totalChecks = issues.length + warnings.length + passed.length;
  const passedChecks = passed.length;
  const passRate = (passedChecks / totalChecks) * 100;

  console.log(`\nOverall Quality Score: ${passRate.toFixed(1)}% (${passedChecks}/${totalChecks} checks passed)`);

  if (issues.length === 0 && warnings.length === 0) {
    console.log('\n🎉 EXCELLENT: All data quality checks passed!');
    console.log('The StockX data is clean, correct, and ready for production.\n');
  } else if (issues.length === 0) {
    console.log('\n✅ GOOD: No critical issues, only minor warnings.');
    console.log('The StockX data is acceptable for production.\n');
  } else {
    console.log('\n❌ NEEDS ATTENTION: Critical issues found that should be resolved.\n');
  }

  console.log('─'.repeat(75));
}

verifyDataQuality().catch(console.error);
