/**
 * Test size mapping across different product categories
 * - GS (Grade School / Kids)
 * - WMNS (Women's)
 * - Clothing
 */

import { createClient } from '@supabase/supabase-js'
import { refreshStockxMarketData } from '@/lib/services/stockx/market-refresh'

const TEST_SKUS = [
  { sku: 'CW1590-103', category: 'GS (Grade School)', description: 'Kids sneaker' },
  { sku: 'DD1503-124', category: 'WMNS (Women\'s)', description: 'Women\'s sneaker' },
  { sku: 'IF2941-731', category: 'Clothing', description: 'Apparel item' },
]

async function main() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  console.log('===============================================================================')
  console.log('Category Size Test')
  console.log('===============================================================================\n')
  console.log('Testing size mapping across different product categories:\n')

  for (const test of TEST_SKUS) {
    console.log(`  • ${test.sku} - ${test.category}`)
  }
  console.log()

  for (const test of TEST_SKUS) {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log(`Testing: ${test.sku} (${test.category})`)
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    // Step 1: Look up product in catalog
    const { data: catalogEntry, error: catalogError } = await supabase
      .from('product_catalog')
      .select('id, sku, stockx_product_id')
      .eq('sku', test.sku)
      .single()

    if (catalogError || !catalogEntry) {
      console.log(`❌ Product not found in catalog: ${test.sku}`)
      console.log(`   Error: ${catalogError?.message || 'Not found'}`)
      console.log(`   💡 This SKU may not exist in your product_catalog table\n`)
      continue
    }

    if (!catalogEntry.stockx_product_id) {
      console.log(`❌ No StockX product ID for ${test.sku}`)
      console.log(`   💡 This product needs to be mapped to StockX\n`)
      continue
    }

    console.log('✅ Found in catalog:')
    console.log(`   SKU: ${catalogEntry.sku}`)
    console.log(`   StockX Product ID: ${catalogEntry.stockx_product_id}`)
    console.log()

    // Step 2: Check if variants are cached
    const { data: existingVariants, count: variantCount } = await supabase
      .from('stockx_variants')
      .select('*', { count: 'exact', head: true })
      .eq('stockx_product_id', catalogEntry.stockx_product_id)

    console.log('📦 Cached variants:', variantCount || 0)

    if (variantCount && variantCount > 0) {
      // Show sample of cached sizes
      const { data: sampleVariants } = await supabase
        .from('stockx_variants')
        .select('variant_value, size_display')
        .eq('stockx_product_id', catalogEntry.stockx_product_id)
        .limit(5)

      if (sampleVariants && sampleVariants.length > 0) {
        console.log('   Sample sizes:', sampleVariants.map(v => v.variant_value || 'Unknown').join(', '))
      }
    }
    console.log()

    // Step 3: Sync market data (GBP/UK)
    console.log('🔄 Syncing market data (GBP, UK)...')
    const syncResult = await refreshStockxMarketData(
      undefined,
      catalogEntry.stockx_product_id,
      'GBP'
    )

    if (!syncResult.success) {
      console.log(`❌ Sync failed: ${syncResult.error}`)
      console.log()
      continue
    }

    console.log('✅ Sync complete!')
    console.log()

    // Step 4: Query the ingested data
    console.log('📊 Querying master_market_data...')
    const { data: marketRows, error: queryError } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('sku', test.sku)
      .eq('provider', 'stockx')
      .eq('currency_code', 'GBP')
      .order('created_at', { ascending: false })
      .limit(100)

    if (queryError) {
      console.log(`❌ Query error: ${queryError.message}`)
      console.log()
      continue
    }

    if (!marketRows || marketRows.length === 0) {
      console.log('❌ No data found in master_market_data')
      console.log()
      continue
    }

    // Get only latest sync data
    const latestTimestamp = marketRows[0].created_at
    const latestRows = marketRows.filter(r => r.created_at === latestTimestamp)

    console.log(`✅ Found ${latestRows.length} rows from latest sync\n`)

    // Analyze size information
    const uniqueSizes = new Set(latestRows.map(r => r.size_key))
    const sizeSystems = new Set(latestRows.map(r => r.size_system))
    const withNumeric = latestRows.filter(r => r.size_numeric !== null).length
    const withoutNumeric = latestRows.length - withNumeric
    const unknownSizes = latestRows.filter(r => r.size_key === 'Unknown').length

    console.log('📏 Size Analysis:')
    console.log(`   Total rows: ${latestRows.length}`)
    console.log(`   Unique sizes: ${uniqueSizes.size}`)
    console.log(`   Size systems: ${Array.from(sizeSystems).join(', ')}`)
    console.log(`   With size_numeric: ${withNumeric}`)
    console.log(`   Without size_numeric: ${withoutNumeric}`)
    if (unknownSizes > 0) {
      console.log(`   ⚠️  "Unknown" sizes: ${unknownSizes}`)
    }
    console.log()

    // Show sample sizes
    const sortedSizes = Array.from(uniqueSizes).sort((a, b) => {
      const numA = parseFloat(a) || 999
      const numB = parseFloat(b) || 999
      return numA - numB
    })

    console.log('📦 Sample Sizes (first 10):')
    for (const size of sortedSizes.slice(0, 10)) {
      const rows = latestRows.filter(r => r.size_key === size)
      const sampleRow = rows[0]
      const numericStr = sampleRow.size_numeric !== null ? sampleRow.size_numeric.toString() : 'null'
      console.log(`   ${size.padEnd(8)} → size_numeric: ${numericStr.padEnd(6)} | system: ${sampleRow.size_system}`)
    }
    console.log()

    // Assessment
    console.log('✅ ASSESSMENT:')
    if (unknownSizes === 0 && withNumeric > 0) {
      console.log('   ✅ Size mapping working correctly!')
    } else if (unknownSizes === 0 && withoutNumeric === latestRows.length) {
      console.log('   ⚠️  Sizes populated but no numeric values (expected for clothing)')
    } else if (unknownSizes > 0) {
      console.log('   ❌ Some sizes showing as "Unknown"')
    }

    if (sizeSystems.size === 1 && sizeSystems.has('US')) {
      console.log('   ⚠️  Size system hardcoded to "US" (may be inaccurate for this category)')
    }
    console.log()
  }

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('OVERALL SUMMARY')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
  console.log('The size fix will:')
  console.log('  ✅ Populate size_key from stockx_variants for all categories')
  console.log('  ✅ Extract size_numeric for numeric sizes (sneakers)')
  console.log('  ⚠️  Leave size_numeric as null for non-numeric sizes (clothing)')
  console.log('  ⚠️  Always set size_system to "US" (may be inaccurate)')
  console.log()
}

main().catch(console.error)
