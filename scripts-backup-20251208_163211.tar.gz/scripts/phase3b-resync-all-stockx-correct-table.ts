#!/usr/bin/env npx tsx
/**
 * PHASE 3B: Systematic Re-sync - All StockX Products (CORRECTED)
 *
 * Re-syncs all StockX products across all regions (US, UK, EU)
 * with corrected price conversion and gender-based size filtering.
 *
 * FIXED: Now queries stockx_products table directly instead of product_catalog
 * This ensures we sync all 125+ products, not just the 8 that are mapped.
 */

import { createClient } from '@supabase/supabase-js';
import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

interface SyncResult {
  sku: string;
  stockxProductId: string;
  brand: string;
  success: boolean;
  totalSnapshots: number;
  regionResults: {
    US: { success: boolean; snapshots: number; error?: string };
    UK: { success: boolean; snapshots: number; error?: string };
    EU: { success: boolean; snapshots: number; error?: string };
  };
  error?: string;
}

async function resyncAllStockXProducts() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║         PHASE 3B: Systematic Re-sync - All StockX Products           ║');
  console.log('║                    (Using Correct Table)                              ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  const overallStartTime = Date.now();

  // =========================================================================
  // STEP 1: FETCH ALL STOCKX PRODUCTS FROM CORRECT TABLE
  // =========================================================================

  console.log('📋 STEP 1: Fetching StockX Products from stockx_products table\n');
  console.log('─'.repeat(75));

  const { data: products, error: fetchError } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, brand')
    .order('style_id');

  if (fetchError || !products || products.length === 0) {
    console.error('❌ Failed to fetch products:', fetchError?.message || 'No products found');
    process.exit(1);
  }

  console.log(`Found ${products.length} products in stockx_products table:\n`);

  // Show first 20 as sample
  const sample = products.slice(0, 20);
  sample.forEach((p, i) => {
    console.log(`  ${(i + 1).toString().padStart(2)}. ${p.style_id.padEnd(15)} | ${(p.brand || 'Unknown').padEnd(15)}`);
  });

  if (products.length > 20) {
    console.log(`  ... and ${products.length - 20} more\n`);
  }

  console.log('\n' + '─'.repeat(75) + '\\n');

  // =========================================================================
  // STEP 2: SYNC EACH PRODUCT ACROSS ALL REGIONS
  // =========================================================================

  console.log('🔄 STEP 2: Syncing Products Across All Regions\n');
  console.log('─'.repeat(75));

  const results: SyncResult[] = [];
  let totalSynced = 0;
  let totalFailed = 0;
  let totalSnapshots = 0;

  for (let i = 0; i < products.length; i++) {
    const product = products[i];
    const progress = `[${i + 1}/${products.length}]`;

    console.log(`\n${progress} Syncing ${product.style_id} (${product.brand || 'Unknown'})...`);
    console.log('─'.repeat(75));

    const result: SyncResult = {
      sku: product.style_id,
      stockxProductId: product.stockx_product_id,
      brand: product.brand || 'Unknown',
      success: false,
      totalSnapshots: 0,
      regionResults: {
        US: { success: false, snapshots: 0 },
        UK: { success: false, snapshots: 0 },
        EU: { success: false, snapshots: 0 },
      },
    };

    try {
      // Sync US region
      console.log('  🇺🇸 Syncing US region...');
      const startUS = Date.now();
      const usResult = await syncProductAllRegions(
        undefined,
        product.stockx_product_id,
        'US',
        false // Don't auto-sync other regions
      );
      const durationUS = ((Date.now() - startUS) / 1000).toFixed(1);

      result.regionResults.US.success = usResult.success;
      result.regionResults.US.snapshots = usResult.primaryResult.snapshotsCreated;
      console.log(`     ${usResult.success ? '✅' : '❌'} ${usResult.primaryResult.snapshotsCreated} snapshots in ${durationUS}s`);
      if (!usResult.success) {
        result.regionResults.US.error = usResult.primaryResult.error;
      }

      // Small delay between regions
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Sync UK region
      console.log('  🇬🇧 Syncing UK region...');
      const startUK = Date.now();
      const ukResult = await syncProductAllRegions(
        undefined,
        product.stockx_product_id,
        'UK',
        false
      );
      const durationUK = ((Date.now() - startUK) / 1000).toFixed(1);

      result.regionResults.UK.success = ukResult.success;
      result.regionResults.UK.snapshots = ukResult.primaryResult.snapshotsCreated;
      console.log(`     ${ukResult.success ? '✅' : '❌'} ${ukResult.primaryResult.snapshotsCreated} snapshots in ${durationUK}s`);
      if (!ukResult.success) {
        result.regionResults.UK.error = ukResult.primaryResult.error;
      }

      await new Promise(resolve => setTimeout(resolve, 1000));

      // Sync EU region
      console.log('  🇪🇺 Syncing EU region...');
      const startEU = Date.now();
      const euResult = await syncProductAllRegions(
        undefined,
        product.stockx_product_id,
        'EU',
        false
      );
      const durationEU = ((Date.now() - startEU) / 1000).toFixed(1);

      result.regionResults.EU.success = euResult.success;
      result.regionResults.EU.snapshots = euResult.primaryResult.snapshotsCreated;
      console.log(`     ${euResult.success ? '✅' : '❌'} ${euResult.primaryResult.snapshotsCreated} snapshots in ${durationEU}s`);
      if (!euResult.success) {
        result.regionResults.EU.error = euResult.primaryResult.error;
      }

      // Calculate totals
      result.totalSnapshots =
        result.regionResults.US.snapshots +
        result.regionResults.UK.snapshots +
        result.regionResults.EU.snapshots;

      result.success =
        result.regionResults.US.success ||
        result.regionResults.UK.success ||
        result.regionResults.EU.success;

      if (result.success) {
        totalSynced++;
        totalSnapshots += result.totalSnapshots;
        console.log(`\n  ✅ ${product.style_id}: ${result.totalSnapshots} total snapshots across all regions`);
      } else {
        totalFailed++;
        console.log(`\n  ❌ ${product.style_id}: All regions failed`);
      }

    } catch (error: any) {
      result.error = error.message;
      totalFailed++;
      console.log(`\n  ❌ ${product.style_id}: Error - ${error.message}`);
    }

    results.push(result);

    // Delay between products to avoid rate limiting
    if (i < products.length - 1) {
      console.log('\n  ⏳ Waiting 2s before next product...');
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }

  const totalDuration = ((Date.now() - overallStartTime) / 1000 / 60).toFixed(1);

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // STEP 3: POST-SYNC VERIFICATION
  // =========================================================================

  console.log('✓ STEP 3: Post-Sync Verification\n');
  console.log('─'.repeat(75));

  // Count total records
  const { count: totalRecords } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx');

  console.log(`Total StockX records: ${totalRecords?.toLocaleString() || 0}\n`);

  // Count records by region
  const { data: regionData } = await supabase
    .from('master_market_data')
    .select('region_code')
    .eq('provider', 'stockx');

  const regionCounts = regionData?.reduce((acc, r) => {
    acc[r.region_code || 'NULL'] = (acc[r.region_code || 'NULL'] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  console.log('Records by Region:');
  ['US', 'UK', 'EU'].forEach(region => {
    const count = regionCounts[region] || 0;
    console.log(`  ${region}: ${count.toLocaleString()} records`);
  });

  // Verify price conversion
  const { data: priceCheck } = await supabase
    .from('master_market_data')
    .select('lowest_ask, size_key, sku')
    .eq('provider', 'stockx')
    .not('lowest_ask', 'is', null)
    .limit(5);

  console.log('\nSample Price Check (should be in cents):');
  priceCheck?.forEach(r => {
    const price = r.lowest_ask / 100;
    const status = price >= 10 ? '✅' : '❌';
    console.log(`  ${status} ${r.sku} size ${r.size_key}: $${price.toFixed(2)} (${r.lowest_ask} cents)`);
  });

  // Verify size range
  const { data: sizeCheck } = await supabase
    .from('master_market_data')
    .select('size_numeric')
    .eq('provider', 'stockx')
    .not('size_numeric', 'is', null);

  const sizes = sizeCheck?.map(r => r.size_numeric).filter(Boolean) || [];
  const minSize = Math.min(...sizes);
  const maxSize = Math.max(...sizes);
  const inValidRange = minSize >= 3.5 && maxSize <= 16;

  console.log('\nSize Range Check:');
  console.log(`  Min: ${minSize}, Max: ${maxSize}`);
  console.log(`  ${inValidRange ? '✅' : '❌'} All sizes in valid range (3.5-16): ${inValidRange}`);

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // STEP 4: DETAILED RESULTS
  // =========================================================================

  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║                           SYNC SUMMARY                                ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  console.log('Overall Results:');
  console.log(`  Products synced: ${totalSynced}/${products.length}`);
  console.log(`  Products failed: ${totalFailed}/${products.length}`);
  console.log(`  Total snapshots: ${totalSnapshots.toLocaleString()}`);
  console.log(`  Duration: ${totalDuration} minutes`);

  // Calculate success rate
  const successRate = ((totalSynced / products.length) * 100).toFixed(1);
  console.log(`  Success rate: ${successRate}%`);

  console.log('\nPer-Product Results (first 20):\n');
  console.log('SKU             | US  | UK  | EU  | Total  | Status');
  console.log('─'.repeat(75));

  results.slice(0, 20).forEach(r => {
    const usStatus = r.regionResults.US.success ? '✅' : '❌';
    const ukStatus = r.regionResults.UK.success ? '✅' : '❌';
    const euStatus = r.regionResults.EU.success ? '✅' : '❌';
    const status = r.success ? 'SUCCESS' : 'FAILED';

    console.log(
      `${r.sku.padEnd(15)} | ${usStatus}  | ${ukStatus}  | ${euStatus}  | ${r.totalSnapshots.toString().padStart(6)} | ${status}`
    );
  });

  if (results.length > 20) {
    console.log(`\n... and ${results.length - 20} more products`);
  }

  console.log('\n' + '─'.repeat(75));

  // Show any errors
  const failedResults = results.filter(r => !r.success);
  if (failedResults.length > 0) {
    console.log('\n❌ Failed Syncs:\n');
    failedResults.slice(0, 10).forEach(r => {
      console.log(`  ${r.sku}:`);
      if (r.regionResults.US.error) console.log(`    US: ${r.regionResults.US.error}`);
      if (r.regionResults.UK.error) console.log(`    UK: ${r.regionResults.UK.error}`);
      if (r.regionResults.EU.error) console.log(`    EU: ${r.regionResults.EU.error}`);
      if (r.error) console.log(`    Error: ${r.error}`);
    });
    if (failedResults.length > 10) {
      console.log(`\n... and ${failedResults.length - 10} more failures`);
    }
  }

  console.log('\n' + '─'.repeat(75));
  console.log('\n✅ Phase 3B Complete - All StockX Products Synced from Correct Table\n');
}

resyncAllStockXProducts().catch(console.error);
