-- Delete the test listing that was created
DELETE FROM stockx_listings WHERE id = 'bdc6b8c4-5ecf-4613-9449-4311838490eb';
