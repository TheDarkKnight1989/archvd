/**
 * Show only the LATEST sync data to verify sizes are working
 */

import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010'

async function main() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  console.log('===============================================================================')
  console.log('Latest Sync Data Only')
  console.log('===============================================================================\n')

  // Get the latest created_at timestamp
  const { data: latestRow } = await supabase
    .from('master_market_data')
    .select('created_at')
    .eq('sku', SKU)
    .eq('provider', 'stockx')
    .order('created_at', { ascending: false })
    .limit(1)
    .single()

  if (!latestRow) {
    console.log('❌ No data found')
    return
  }

  const latestTimestamp = latestRow.created_at
  console.log('Latest sync timestamp:', latestTimestamp)
  console.log()

  // Query all rows from the latest sync
  const { data, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('sku', SKU)
    .eq('provider', 'stockx')
    .eq('created_at', latestTimestamp)
    .order('size_numeric', { ascending: true })

  if (error) {
    console.error('❌ Error:', error.message)
    return
  }

  if (!data || data.length === 0) {
    console.log('❌ No data found')
    return
  }

  console.log(`✅ Found ${data.length} rows from latest sync\n`)

  // Check for Unknown sizes
  const unknownCount = data.filter(r => r.size_key === 'Unknown').length
  const knownCount = data.length - unknownCount

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('SIZE INFORMATION STATUS')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
  console.log(`Total rows: ${data.length}`)
  console.log(`With proper sizes: ${knownCount} (${(knownCount / data.length * 100).toFixed(1)}%)`)
  console.log(`With "Unknown" size: ${unknownCount} (${(unknownCount / data.length * 100).toFixed(1)}%)`)
  console.log()

  if (unknownCount === 0) {
    console.log('✅ SUCCESS! All rows from latest sync have proper size information!')
  } else {
    console.log('⚠️  Some rows still missing size information')
  }

  console.log()
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('SAMPLE DATA (First 5 Sizes)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  // Group by size
  const sizeGroups = new Map<string, any[]>()
  for (const row of data) {
    const size = row.size_key
    if (!sizeGroups.has(size)) {
      sizeGroups.set(size, [])
    }
    sizeGroups.get(size)!.push(row)
  }

  // Sort by numeric size
  const sortedSizes = Array.from(sizeGroups.entries()).sort((a, b) => {
    const numA = parseFloat(a[0]) || 999
    const numB = parseFloat(b[0]) || 999
    return numA - numB
  })

  for (const [size, rows] of sortedSizes.slice(0, 5)) {
    console.log(`📦 SIZE ${size} US`)

    const standard = rows.find(r => r.provider_source === 'stockx_market_data')
    const flex = rows.find(r => r.provider_source === 'stockx_market_data_flex')

    if (standard) {
      console.log(`   📊 Standard: Ask £${standard.lowest_ask}, Bid £${standard.highest_bid}`)
    }

    if (flex) {
      console.log(`   🚀 Flex: Ask £${flex.lowest_ask}, Bid £${flex.highest_bid}`)
    }

    console.log()
  }

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('ALL SIZES IN LATEST SYNC')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const allSizes = Array.from(sizeGroups.keys()).sort((a, b) => {
    const numA = parseFloat(a) || 999
    const numB = parseFloat(b) || 999
    return numA - numB
  })

  console.log('Sizes:', allSizes.join(', '))
  console.log()
}

main().catch(console.error)
