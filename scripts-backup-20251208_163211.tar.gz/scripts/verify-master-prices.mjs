#!/usr/bin/env node

/**
 * Verify master_market_latest has correct price format
 */

import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

async function verifyMasterPrices() {
  console.log('\n🔍 VERIFYING MASTER_MARKET_LATEST PRICES')
  console.log('='.repeat(80))

  // Get same product from both tables
  const { data: snapshot, error: snapErr } = await supabase
    .from('stockx_market_snapshots')
    .select('*')
    .not('lowest_ask', 'is', null)
    .limit(1)
    .single()

  if (snapErr || !snapshot) {
    console.error('❌ No snapshot data found')
    return
  }

  console.log('\n📊 STOCKX_MARKET_SNAPSHOTS (raw source):')
  console.log('  variant_id:', snapshot.stockx_variant_id)
  console.log('  currency:', snapshot.currency_code)
  console.log('  lowest_ask:', snapshot.lowest_ask, '(PENNIES)')
  console.log('  highest_bid:', snapshot.highest_bid || 'null', '(PENNIES)')
  console.log('  Expected in £:', (snapshot.lowest_ask / 100).toFixed(2))

  // Try to find corresponding master record
  const { data: master, error: masterErr } = await supabase
    .from('master_market_latest')
    .select('*')
    .eq('provider', 'stockx')
    .eq('provider_variant_id', snapshot.stockx_variant_id)
    .eq('currency_code', snapshot.currency_code)
    .single()

  if (masterErr || !master) {
    console.log('\n❌ NO CORRESPONDING MASTER RECORD FOUND')
    console.log('   This means master_market_latest is NOT being populated from stockx!')
    console.log('   Need to check ingestion pipeline')
  } else {
    console.log('\n📊 MASTER_MARKET_LATEST (unified table):')
    console.log('  variant_id:', master.provider_variant_id)
    console.log('  currency:', master.currency_code)
    console.log('  lowest_ask:', master.lowest_ask, '(should be MAJOR UNITS)')
    console.log('  highest_bid:', master.highest_bid || 'null')

    // Compare
    const expectedMajor = snapshot.lowest_ask / 100
    const masterValue = parseFloat(master.lowest_ask)

    console.log('\n🔍 COMPARISON:')
    console.log('  Snapshot (pennies):', snapshot.lowest_ask)
    console.log('  Snapshot / 100:', expectedMajor.toFixed(2), '(expected in master)')
    console.log('  Master actual:', masterValue.toFixed(2))

    if (Math.abs(masterValue - expectedMajor) < 0.01) {
      console.log('  ✅ CORRECT: Master has major units (divided by 100)')
    } else if (Math.abs(masterValue - snapshot.lowest_ask) < 1) {
      console.log('  ❌ WRONG: Master has pennies (NOT divided)')
    } else {
      console.log('  ⚠️  UNKNOWN: Values don\'t match either pattern')
    }
  }

  console.log('\n' + '='.repeat(80))
}

verifyMasterPrices().catch(console.error)
