#!/usr/bin/env npx tsx
/**
 * PHASE 3C: Retry Failed Products
 *
 * Identifies products that failed to sync in Phase 3B and retries them
 * with improved error handling, longer timeouts, and diagnostic logging.
 */

import { createClient } from '@supabase/supabase-js';
import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

interface RetryResult {
  sku: string;
  stockxProductId: string;
  brand: string;
  success: boolean;
  totalSnapshots: number;
  errors: string[];
  timeouts: string[];
  regionResults: {
    US: { success: boolean; snapshots: number; error?: string; timeout?: boolean };
    UK: { success: boolean; snapshots: number; error?: string; timeout?: boolean };
    EU: { success: boolean; snapshots: number; error?: string; timeout?: boolean };
  };
}

async function retryFailedProducts() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║              PHASE 3C: Retry Failed Products                          ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  const startTime = Date.now();

  // =========================================================================
  // STEP 1: IDENTIFY FAILED PRODUCTS
  // =========================================================================

  console.log('📋 STEP 1: Identifying Failed Products\n');
  console.log('─'.repeat(75));

  // Get all stockx_products
  const { data: allProducts } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, brand')
    .order('style_id');

  console.log(`Total products in stockx_products: ${allProducts?.length || 0}`);

  // Get successfully synced products
  const { data: syncedData } = await supabase
    .from('master_market_data')
    .select('provider_product_id')
    .eq('provider', 'stockx');

  const syncedProductIds = new Set(syncedData?.map(r => r.provider_product_id).filter(Boolean));
  console.log(`Successfully synced products: ${syncedProductIds.size}`);

  // Find failed products
  const failedProducts = allProducts?.filter(p => !syncedProductIds.has(p.stockx_product_id)) || [];
  console.log(`Failed products to retry: ${failedProducts.length}\n`);

  if (failedProducts.length === 0) {
    console.log('✅ No failed products to retry!\n');
    return;
  }

  console.log('Failed products:');
  failedProducts.slice(0, 20).forEach((p, i) => {
    console.log(`  ${(i + 1).toString().padStart(2)}. ${p.style_id.padEnd(15)} | ${p.brand || 'Unknown'}`);
  });
  if (failedProducts.length > 20) {
    console.log(`  ... and ${failedProducts.length - 20} more`);
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // STEP 2: RETRY WITH IMPROVED ERROR HANDLING
  // =========================================================================

  console.log('🔄 STEP 2: Retrying Failed Products\n');
  console.log('─'.repeat(75));
  console.log('Improvements:');
  console.log('  - Longer delays between requests (5s instead of 2s)');
  console.log('  - Better timeout detection');
  console.log('  - Detailed error logging\n');
  console.log('─'.repeat(75));

  const results: RetryResult[] = [];
  let totalSynced = 0;
  let totalFailed = 0;
  let totalSnapshots = 0;
  let timeoutCount = 0;

  for (let i = 0; i < failedProducts.length; i++) {
    const product = failedProducts[i];
    const progress = `[${i + 1}/${failedProducts.length}]`;

    console.log(`\n${progress} Retrying ${product.style_id} (${product.brand || 'Unknown'})...`);
    console.log('─'.repeat(75));

    const result: RetryResult = {
      sku: product.style_id,
      stockxProductId: product.stockx_product_id,
      brand: product.brand || 'Unknown',
      success: false,
      totalSnapshots: 0,
      errors: [],
      timeouts: [],
      regionResults: {
        US: { success: false, snapshots: 0 },
        UK: { success: false, snapshots: 0 },
        EU: { success: false, snapshots: 0 },
      },
    };

    try {
      // Try US region
      console.log('  🇺🇸 Syncing US region...');
      const startUS = Date.now();
      try {
        const usResult = await syncProductAllRegions(
          undefined,
          product.stockx_product_id,
          'US',
          false
        );
        const durationUS = ((Date.now() - startUS) / 1000).toFixed(1);

        result.regionResults.US.success = usResult.success;
        result.regionResults.US.snapshots = usResult.primaryResult.snapshotsCreated;
        console.log(`     ${usResult.success ? '✅' : '❌'} ${usResult.primaryResult.snapshotsCreated} snapshots in ${durationUS}s`);

        if (!usResult.success && usResult.primaryResult.error) {
          result.regionResults.US.error = usResult.primaryResult.error;
          if (usResult.primaryResult.error.includes('504') || usResult.primaryResult.error.includes('timeout')) {
            result.regionResults.US.timeout = true;
            result.timeouts.push('US');
            timeoutCount++;
          } else {
            result.errors.push(`US: ${usResult.primaryResult.error}`);
          }
        }
      } catch (error: any) {
        const durationUS = ((Date.now() - startUS) / 1000).toFixed(1);
        console.log(`     ❌ Error in ${durationUS}s: ${error.message}`);
        result.regionResults.US.error = error.message;
        if (error.message.includes('504') || error.message.includes('timeout')) {
          result.regionResults.US.timeout = true;
          result.timeouts.push('US');
          timeoutCount++;
        } else {
          result.errors.push(`US: ${error.message}`);
        }
      }

      await new Promise(resolve => setTimeout(resolve, 2000));

      // Try UK region
      console.log('  🇬🇧 Syncing UK region...');
      const startUK = Date.now();
      try {
        const ukResult = await syncProductAllRegions(
          undefined,
          product.stockx_product_id,
          'UK',
          false
        );
        const durationUK = ((Date.now() - startUK) / 1000).toFixed(1);

        result.regionResults.UK.success = ukResult.success;
        result.regionResults.UK.snapshots = ukResult.primaryResult.snapshotsCreated;
        console.log(`     ${ukResult.success ? '✅' : '❌'} ${ukResult.primaryResult.snapshotsCreated} snapshots in ${durationUK}s`);

        if (!ukResult.success && ukResult.primaryResult.error) {
          result.regionResults.UK.error = ukResult.primaryResult.error;
          if (ukResult.primaryResult.error.includes('504') || ukResult.primaryResult.error.includes('timeout')) {
            result.regionResults.UK.timeout = true;
            result.timeouts.push('UK');
            timeoutCount++;
          } else {
            result.errors.push(`UK: ${ukResult.primaryResult.error}`);
          }
        }
      } catch (error: any) {
        const durationUK = ((Date.now() - startUK) / 1000).toFixed(1);
        console.log(`     ❌ Error in ${durationUK}s: ${error.message}`);
        result.regionResults.UK.error = error.message;
        if (error.message.includes('504') || error.message.includes('timeout')) {
          result.regionResults.UK.timeout = true;
          result.timeouts.push('UK');
          timeoutCount++;
        } else {
          result.errors.push(`UK: ${error.message}`);
        }
      }

      await new Promise(resolve => setTimeout(resolve, 2000));

      // Try EU region
      console.log('  🇪🇺 Syncing EU region...');
      const startEU = Date.now();
      try {
        const euResult = await syncProductAllRegions(
          undefined,
          product.stockx_product_id,
          'EU',
          false
        );
        const durationEU = ((Date.now() - startEU) / 1000).toFixed(1);

        result.regionResults.EU.success = euResult.success;
        result.regionResults.EU.snapshots = euResult.primaryResult.snapshotsCreated;
        console.log(`     ${euResult.success ? '✅' : '❌'} ${euResult.primaryResult.snapshotsCreated} snapshots in ${durationEU}s`);

        if (!euResult.success && euResult.primaryResult.error) {
          result.regionResults.EU.error = euResult.primaryResult.error;
          if (euResult.primaryResult.error.includes('504') || euResult.primaryResult.error.includes('timeout')) {
            result.regionResults.EU.timeout = true;
            result.timeouts.push('EU');
            timeoutCount++;
          } else {
            result.errors.push(`EU: ${euResult.primaryResult.error}`);
          }
        }
      } catch (error: any) {
        const durationEU = ((Date.now() - startEU) / 1000).toFixed(1);
        console.log(`     ❌ Error in ${durationEU}s: ${error.message}`);
        result.regionResults.EU.error = error.message;
        if (error.message.includes('504') || error.message.includes('timeout')) {
          result.regionResults.EU.timeout = true;
          result.timeouts.push('EU');
          timeoutCount++;
        } else {
          result.errors.push(`EU: ${error.message}`);
        }
      }

      // Calculate totals
      result.totalSnapshots =
        result.regionResults.US.snapshots +
        result.regionResults.UK.snapshots +
        result.regionResults.EU.snapshots;

      result.success =
        result.regionResults.US.success ||
        result.regionResults.UK.success ||
        result.regionResults.EU.success;

      if (result.success) {
        totalSynced++;
        totalSnapshots += result.totalSnapshots;
        console.log(`\n  ✅ ${product.style_id}: ${result.totalSnapshots} total snapshots`);
      } else {
        totalFailed++;
        if (result.timeouts.length === 3) {
          console.log(`\n  ⏱️  ${product.style_id}: All regions timed out`);
        } else if (result.timeouts.length > 0) {
          console.log(`\n  ⚠️  ${product.style_id}: ${result.timeouts.join(', ')} timed out`);
        } else {
          console.log(`\n  ❌ ${product.style_id}: All regions failed`);
        }
      }

    } catch (error: any) {
      totalFailed++;
      result.errors.push(error.message);
      console.log(`\n  ❌ ${product.style_id}: Unexpected error - ${error.message}`);
    }

    results.push(result);

    // Longer delay to avoid rate limiting (5s instead of 2s)
    if (i < failedProducts.length - 1) {
      console.log('\n  ⏳ Waiting 5s before next product...');
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }

  const totalDuration = ((Date.now() - startTime) / 1000 / 60).toFixed(1);

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // STEP 3: ANALYSIS & DIAGNOSTICS
  // =========================================================================

  console.log('🔍 STEP 3: Error Analysis\n');
  console.log('─'.repeat(75));

  // Categorize failures
  const timeoutProducts = results.filter(r => r.timeouts.length === 3);
  const partialTimeoutProducts = results.filter(r => r.timeouts.length > 0 && r.timeouts.length < 3);
  const errorProducts = results.filter(r => r.errors.length > 0 && r.timeouts.length === 0);
  const successProducts = results.filter(r => r.success);

  console.log('Results Breakdown:');
  console.log(`  ✅ Fully successful:     ${successProducts.length}`);
  console.log(`  ⏱️  All regions timeout:  ${timeoutProducts.length}`);
  console.log(`  ⚠️  Partial timeouts:     ${partialTimeoutProducts.length}`);
  console.log(`  ❌ Other errors:          ${errorProducts.length}`);

  console.log(`\nTimeout Statistics:`);
  console.log(`  Total timeout occurrences: ${timeoutCount}`);
  console.log(`  Products with all timeouts: ${timeoutProducts.length}`);

  if (timeoutProducts.length > 0) {
    console.log(`\n  Sample products that timed out completely:`);
    timeoutProducts.slice(0, 5).forEach((r, i) => {
      console.log(`    ${i + 1}. ${r.sku} (${r.brand})`);
    });
  }

  if (errorProducts.length > 0) {
    console.log(`\n  Non-timeout errors:`);
    const uniqueErrors = new Set(errorProducts.flatMap(r => r.errors));
    uniqueErrors.forEach(err => {
      const count = errorProducts.filter(r => r.errors.some(e => e === err)).length;
      console.log(`    - ${err} (${count} occurrences)`);
    });
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // FINAL SUMMARY
  // =========================================================================

  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║                           RETRY SUMMARY                               ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  console.log('Retry Results:');
  console.log(`  Products attempted:  ${failedProducts.length}`);
  console.log(`  Products succeeded:  ${totalSynced}`);
  console.log(`  Products failed:     ${totalFailed}`);
  console.log(`  Total snapshots:     ${totalSnapshots.toLocaleString()}`);
  console.log(`  Duration:            ${totalDuration} minutes`);
  console.log(`  Success rate:        ${((totalSynced / failedProducts.length) * 100).toFixed(1)}%`);

  console.log('\n' + '─'.repeat(75));

  if (timeoutProducts.length > 0) {
    console.log('\n⚠️  TIMEOUT ANALYSIS:\n');
    console.log(`StockX API returned 504 Gateway Timeouts for ${timeoutProducts.length} products.`);
    console.log('Possible causes:');
    console.log('  1. StockX API is experiencing high load or instability');
    console.log('  2. These specific products have large datasets (many sizes/regions)');
    console.log('  3. Rate limiting is being triggered despite delays');
    console.log('  4. Products may not exist or be unavailable in StockX system');
    console.log('\nRecommendation: Retry these products later when StockX API is more stable.');
  }

  // Check final coverage
  const { data: finalSyncedData } = await supabase
    .from('master_market_data')
    .select('provider_product_id')
    .eq('provider', 'stockx');

  const finalSyncedIds = new Set(finalSyncedData?.map(r => r.provider_product_id).filter(Boolean));

  console.log(`\nFinal Coverage:`);
  console.log(`  Total products:      ${allProducts?.length || 0}`);
  console.log(`  Successfully synced: ${finalSyncedIds.size}`);
  console.log(`  Still missing:       ${(allProducts?.length || 0) - finalSyncedIds.size}`);
  console.log(`  Coverage:            ${((finalSyncedIds.size / (allProducts?.length || 1)) * 100).toFixed(1)}%`);

  console.log('\n' + '─'.repeat(75));
  console.log('\n✅ Phase 3C Complete\n');
}

retryFailedProducts().catch(console.error);
