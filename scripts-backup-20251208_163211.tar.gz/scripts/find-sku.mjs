#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// Search for IF4491-100
const { data: exact } = await supabase
  .from('product_catalog')
  .select('sku, stockx_product_id')
  .eq('sku', 'IF4491-100');

console.log('Searching for IF4491-100:', exact ? `Found ${exact.length} matches` : 'Not found');

// Search for SKUs starting with IF
const { data } = await supabase
  .from('product_catalog')
  .select('sku, stockx_product_id')
  .like('sku', 'IF%')
  .limit(10);

if (data && data.length > 0) {
  console.log('\nSKUs starting with IF:');
  data.forEach(p => console.log('  -', p.sku, '(StockX ID:', p.stockx_product_id || 'N/A', ')'));
} else {
  console.log('\nNo SKUs starting with IF found');
}

// Find any products with StockX ID
const { data: anyProduct } = await supabase
  .from('product_catalog')
  .select('sku, stockx_product_id')
  .not('stockx_product_id', 'is', null)
  .limit(10);

if (anyProduct && anyProduct.length > 0) {
  console.log('\nAvailable products with StockX ID:');
  anyProduct.forEach(p => console.log('  -', p.sku));
}
