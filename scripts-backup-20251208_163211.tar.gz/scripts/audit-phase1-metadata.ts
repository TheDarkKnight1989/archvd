#!/usr/bin/env npx tsx
/**
 * PHASE 1 AUDIT: Product Catalog Metadata Assessment
 *
 * Analyzes product_catalog metadata coverage to identify:
 * - Products with missing gender/category data
 * - StockX product coverage
 * - Metadata completeness for size filtering
 * - Opportunities for enrichment
 */

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function auditProductMetadata() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║              PHASE 1: Product Catalog Metadata Audit                  ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  // =========================================================================
  // 1. OVERALL PRODUCT COVERAGE
  // =========================================================================

  console.log('📦 SECTION 1: Product Coverage\n');
  console.log('─'.repeat(75));

  const { count: totalProducts } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true });

  console.log(`Total products in catalog: ${totalProducts?.toLocaleString() || 0}`);

  // Products with StockX IDs
  const { count: stockxProductCount } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('stockx_product_id', 'is', null);

  console.log(`Products with StockX ID: ${stockxProductCount?.toLocaleString() || 0}`);

  // Products with Alias IDs
  const { count: aliasProductCount } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('alias_catalog_id', 'is', null);

  console.log(`Products with Alias ID: ${aliasProductCount?.toLocaleString() || 0}`);

  // Dual-mapped products (both StockX and Alias)
  const { count: dualMappedCount } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('stockx_product_id', 'is', null)
    .not('alias_catalog_id', 'is', null);

  console.log(`Dual-mapped products: ${dualMappedCount?.toLocaleString() || 0}`);

  const stockxCoverage = ((stockxProductCount || 0) / (totalProducts || 1)) * 100;
  const aliasCoverage = ((aliasProductCount || 0) / (totalProducts || 1)) * 100;
  const dualCoverage = ((dualMappedCount || 0) / (totalProducts || 1)) * 100;

  console.log(`\nCoverage:`);
  console.log(`  StockX:      ${stockxCoverage.toFixed(1)}%`);
  console.log(`  Alias:       ${aliasCoverage.toFixed(1)}%`);
  console.log(`  Dual-mapped: ${dualCoverage.toFixed(1)}%`);

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 2. GENDER METADATA COVERAGE (Critical for Size Filtering)
  // =========================================================================

  console.log('🚻 SECTION 2: Gender Metadata Coverage\n');
  console.log('─'.repeat(75));

  const { count: productsWithGender } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('gender', 'is', null);

  const { count: productsWithoutGender } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .is('gender', null);

  console.log(`Products WITH gender data: ${productsWithGender?.toLocaleString() || 0}`);
  console.log(`Products WITHOUT gender data: ${productsWithoutGender?.toLocaleString() || 0}`);

  const genderCoverage = ((productsWithGender || 0) / (totalProducts || 1)) * 100;
  console.log(`Gender coverage: ${genderCoverage.toFixed(1)}%`);

  // Gender distribution
  const { data: genderData } = await supabase
    .from('product_catalog')
    .select('gender')
    .not('gender', 'is', null);

  const genderCounts = genderData?.reduce((acc, r) => {
    acc[r.gender] = (acc[r.gender] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  console.log('\nGender Distribution:');
  Object.entries(genderCounts)
    .sort((a, b) => b[1] - a[1])
    .forEach(([gender, count]) => {
      const percent = ((count / (productsWithGender || 1)) * 100).toFixed(1);
      console.log(`  ${gender.padEnd(10)}: ${count.toLocaleString().padStart(5)} (${percent}%)`);
    });

  // StockX products without gender
  const { count: stockxWithoutGender } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('stockx_product_id', 'is', null)
    .is('gender', null);

  console.log(`\n🚨 StockX products missing gender: ${stockxWithoutGender?.toLocaleString() || 0}`);
  if (stockxWithoutGender && stockxWithoutGender > 0) {
    console.log('   ⚠️  These will fall back to unisex size range (3.5-16)');
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 3. CATEGORY METADATA COVERAGE
  // =========================================================================

  console.log('🏷️  SECTION 3: Category Metadata Coverage\n');
  console.log('─'.repeat(75));

  const { count: productsWithCategory } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('category', 'is', null);

  const { count: productsWithoutCategory } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .is('category', null);

  console.log(`Products WITH category data: ${productsWithCategory?.toLocaleString() || 0}`);
  console.log(`Products WITHOUT category data: ${productsWithoutCategory?.toLocaleString() || 0}`);

  const categoryCoverage = ((productsWithCategory || 0) / (totalProducts || 1)) * 100;
  console.log(`Category coverage: ${categoryCoverage.toFixed(1)}%`);

  // Category distribution
  const { data: categoryData } = await supabase
    .from('product_catalog')
    .select('category')
    .not('category', 'is', null);

  const categoryCounts = categoryData?.reduce((acc, r) => {
    acc[r.category] = (acc[r.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  console.log('\nCategory Distribution:');
  Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .forEach(([category, count]) => {
      const percent = ((count / (productsWithCategory || 1)) * 100).toFixed(1);
      console.log(`  ${category.padEnd(15)}: ${count.toLocaleString().padStart(5)} (${percent}%)`);
    });

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 4. CRITICAL: StockX Products Ready for Sync
  // =========================================================================

  console.log('✅ SECTION 4: StockX Products Ready for Sync\n');
  console.log('─'.repeat(75));

  // Products with StockX ID AND gender (ideal for size filtering)
  const { count: stockxWithGender } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('stockx_product_id', 'is', null)
    .not('gender', 'is', null);

  // Products with StockX ID AND category
  const { count: stockxWithCategory } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('stockx_product_id', 'is', null)
    .not('category', 'is', null);

  // Products with StockX ID AND both gender AND category (perfect)
  const { count: stockxWithBoth } = await supabase
    .from('product_catalog')
    .select('*', { count: 'exact', head: true })
    .not('stockx_product_id', 'is', null)
    .not('gender', 'is', null)
    .not('category', 'is', null);

  console.log('StockX Product Metadata Readiness:');
  console.log(`  With Gender only:         ${(stockxWithGender || 0).toLocaleString()}`);
  console.log(`  With Category only:       ${(stockxWithCategory || 0).toLocaleString()}`);
  console.log(`  With BOTH (optimal):      ${(stockxWithBoth || 0).toLocaleString()}`);
  console.log(`  Missing metadata:         ${(stockxWithoutGender || 0).toLocaleString()}`);

  const readinessPercent = ((stockxWithBoth || 0) / (stockxProductCount || 1)) * 100;
  console.log(`\nReadiness: ${readinessPercent.toFixed(1)}% of StockX products have complete metadata`);

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 5. ENRICHMENT OPPORTUNITIES
  // =========================================================================

  console.log('🔧 SECTION 5: Enrichment Opportunities\n');
  console.log('─'.repeat(75));

  // Sample products missing metadata
  const { data: missingMetadata } = await supabase
    .from('product_catalog')
    .select('sku, brand, stockx_product_id, gender, category')
    .not('stockx_product_id', 'is', null)
    .is('gender', null)
    .limit(10);

  if (missingMetadata && missingMetadata.length > 0) {
    console.log('Sample products needing enrichment (missing gender):');
    console.log('SKU          | Brand           | StockX ID                            | Gender | Category');
    console.log('─'.repeat(100));
    missingMetadata.forEach(p => {
      console.log(
        `${p.sku.padEnd(12)} | ${(p.brand || 'NULL').padEnd(15)} | ${p.stockx_product_id.substring(0, 36)} | ${p.gender || 'NULL'.padEnd(6)} | ${p.category || 'NULL'}`
      );
    });

    console.log(`\n💡 Recommendation: Use StockX enrichment API to populate missing gender/category`);
    console.log(`   We can fetch this data from StockX product details endpoint`);
  } else {
    console.log('✅ All StockX products have gender metadata!');
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 6. BRAND DISTRIBUTION
  // =========================================================================

  console.log('👟 SECTION 6: Brand Distribution\n');
  console.log('─'.repeat(75));

  const { data: brandData } = await supabase
    .from('product_catalog')
    .select('brand')
    .not('stockx_product_id', 'is', null)
    .not('brand', 'is', null);

  const brandCounts = brandData?.reduce((acc, r) => {
    acc[r.brand] = (acc[r.brand] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  console.log('Top brands (with StockX IDs):');
  Object.entries(brandCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .forEach(([brand, count], i) => {
      console.log(`  ${(i + 1).toString().padStart(2)}. ${brand.padEnd(20)}: ${count.toLocaleString().padStart(4)} products`);
    });

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // SUMMARY & RECOMMENDATIONS
  // =========================================================================

  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║                         METADATA AUDIT SUMMARY                        ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  const issues: string[] = [];
  const warnings: string[] = [];
  const passed: string[] = [];

  // Critical issues
  if (genderCoverage < 50) {
    issues.push(`Low gender coverage (${genderCoverage.toFixed(1)}%) - size filtering will be limited`);
  } else if (genderCoverage < 80) {
    warnings.push(`Gender coverage (${genderCoverage.toFixed(1)}%) could be improved`);
  } else {
    passed.push(`Good gender coverage (${genderCoverage.toFixed(1)}%)`);
  }

  if (stockxWithoutGender && stockxWithoutGender > 0) {
    warnings.push(`${stockxWithoutGender} StockX products missing gender - will use unisex fallback`);
  }

  if (readinessPercent >= 80) {
    passed.push(`${readinessPercent.toFixed(1)}% of StockX products ready for optimal sync`);
  } else {
    warnings.push(`Only ${readinessPercent.toFixed(1)}% of StockX products have complete metadata`);
  }

  if (issues.length > 0) {
    console.log('🚨 CRITICAL ISSUES:\n');
    issues.forEach((issue, i) => {
      console.log(`  ${i + 1}. ${issue}`);
    });
    console.log('');
  }

  if (warnings.length > 0) {
    console.log('⚠️  WARNINGS:\n');
    warnings.forEach((warning, i) => {
      console.log(`  ${i + 1}. ${warning}`);
    });
    console.log('');
  }

  if (passed.length > 0) {
    console.log('✅ PASSED:\n');
    passed.forEach((item, i) => {
      console.log(`  ${i + 1}. ${item}`);
    });
    console.log('');
  }

  console.log('─'.repeat(75));
  console.log('\n📋 RECOMMENDED ACTIONS:\n');

  if (stockxWithoutGender && stockxWithoutGender > 0) {
    console.log(`  1. Run enrichment for ${stockxWithoutGender} products missing gender`);
    console.log('     - Use StockX product details API');
    console.log('     - Populate gender, category, colorway, retail price');
  }

  if (issues.length === 0 && warnings.length === 0) {
    console.log('  ✅ Metadata quality is good - ready for sync!');
  }

  console.log('\n' + '─'.repeat(75));
  console.log('\n✅ Phase 1 Metadata Audit Complete\n');
}

auditProductMetadata().catch(console.error);
