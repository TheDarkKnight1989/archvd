/**
 * Final eBay Integration Audit
 * Tests complete end-to-end integration across multiple SKUs
 * Goal: Verify eBay data is being ingested into master_market_data
 */

import 'dotenv/config'
import { syncEbaySneakersForQuery } from '@/lib/services/ebay/sync'
import { createClient } from '@supabase/supabase-js'
import { ebayConfig } from '@/lib/services/ebay/config'

const TEST_SKUS = ['II1493-600', 'IM3906-100', 'DZ4137-700']

interface EbayAuditResult {
  sku: string
  tests: {
    ebaySync: boolean
    databaseStorage: boolean
    dataQuality: boolean
  }
  metrics: {
    itemsFetched: number
    sizesInDatabase: number
    avgPrice: number | null
  }
  issues: string[]
  passed: boolean
}

async function auditSKU(sku: string, supabase: ReturnType<typeof createClient>): Promise<EbayAuditResult> {
  const result: EbayAuditResult = {
    sku,
    tests: {
      ebaySync: false,
      databaseStorage: false,
      dataQuality: false,
    },
    metrics: {
      itemsFetched: 0,
      sizesInDatabase: 0,
      avgPrice: null,
    },
    issues: [],
    passed: false,
  }

  console.log(`\n${'═'.repeat(79)}`)
  console.log(`TESTING SKU: ${sku}`)
  console.log('═'.repeat(79))

  // TEST 1: eBay Sync
  console.log('\n[1/3] Testing eBay sync...')
  try {
    const syncResult = await syncEbaySneakersForQuery(sku, {
      currency: 'GBP',
      limit: 100,
      soldItemsOnly: true,
    })

    if (!syncResult.success) {
      result.issues.push(`Sync failed: ${syncResult.error}`)
      console.log(`❌ Sync failed: ${syncResult.error}`)
      return result
    }

    result.metrics.itemsFetched = syncResult.itemsCount
    console.log(`✅ Sync completed`)
    console.log(`   Items fetched: ${syncResult.itemsCount}`)
    console.log(`   SKU-size combos: ${syncResult.uniqueSkuSizeCount || 0}`)

    if (result.metrics.itemsFetched > 0) {
      result.tests.ebaySync = true
    } else {
      result.issues.push('No items fetched from eBay')
      console.log('⚠️  No items found (may be expected for niche products)')
    }
  } catch (error: any) {
    result.issues.push(`Sync error: ${error.message}`)
    console.log(`❌ Sync error: ${error.message}`)
    return result
  }

  // TEST 2: Verify data in master_market_data
  console.log('\n[2/3] Testing database storage (master_market_data)...')
  try {
    const { data: ebayData, error } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('provider', 'ebay')
      .ilike('sku', `%${sku}%`) // Use LIKE since eBay SKU extraction might vary

    if (error) {
      result.issues.push(`Database query failed: ${error.message}`)
      console.log(`❌ Database query failed: ${error.message}`)
      return result
    }

    if (!ebayData || ebayData.length === 0) {
      // Check if we fetched items but didn't store them
      if (result.metrics.itemsFetched > 0) {
        result.issues.push('Items fetched but not stored in database (SKU extraction may have failed)')
        console.log('⚠️  Items fetched but not in database')
        console.log('   This could mean:')
        console.log('   - SKU extraction from eBay titles failed')
        console.log('   - Items didnt match filters')
        console.log('   - Ingestion mapper encountered errors')
      } else {
        console.log('⚠️  No data in database (no items fetched)')
      }
      return result
    }

    result.metrics.sizesInDatabase = new Set(ebayData.map(row => row.size_key)).size
    result.tests.databaseStorage = true

    console.log(`✅ Found ${ebayData.length} rows in database`)
    console.log(`   Unique sizes: ${result.metrics.sizesInDatabase}`)
  } catch (error: any) {
    result.issues.push(`Database verification failed: ${error.message}`)
    console.log(`❌ Database verification failed: ${error.message}`)
    return result
  }

  // TEST 3: Data quality checks
  console.log('\n[3/3] Testing data quality...')
  try {
    const { data: ebayData } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('provider', 'ebay')
      .ilike('sku', `%${sku}%`)

    if (!ebayData || ebayData.length === 0) {
      result.issues.push('No data for quality check')
      console.log('❌ No data for quality check')
      return result
    }

    // Check for required fields
    const hasPricing = ebayData.filter(row => row.last_sale_price !== null || row.lowest_ask !== null)

    console.log('   Data completeness:')
    console.log(`   - Has pricing: ${hasPricing.length}/${ebayData.length} (${((hasPricing.length / ebayData.length) * 100).toFixed(1)}%)`)

    // Calculate averages
    const validPrices = hasPricing
      .map(r => r.last_sale_price || r.lowest_ask)
      .filter((v): v is number => v !== null)

    if (validPrices.length > 0) {
      result.metrics.avgPrice = validPrices.reduce((sum, v) => sum + v, 0) / validPrices.length
    }

    // Data quality threshold
    const pricingCoverage = hasPricing.length / ebayData.length

    if (pricingCoverage >= 0.5) {
      result.tests.dataQuality = true
      console.log('✅ Data quality passed (>50% coverage)')
    } else {
      result.issues.push(`Low data coverage: ${(pricingCoverage * 100).toFixed(1)}%`)
      console.log(`⚠️  Data quality warning: low coverage`)
    }

    if (result.metrics.avgPrice !== null) {
      console.log(`   Avg price: £${result.metrics.avgPrice.toFixed(2)}`)
    }
  } catch (error: any) {
    result.issues.push(`Data quality check failed: ${error.message}`)
    console.log(`❌ Data quality check failed: ${error.message}`)
  }

  // Final pass/fail determination
  const criticalTests = [
    result.tests.ebaySync,
    result.tests.databaseStorage,
  ]

  result.passed = criticalTests.every(t => t === true) && result.issues.length === 0

  console.log('\n' + '─'.repeat(79))
  console.log('TEST SUMMARY:')
  console.log(`  eBay Sync: ${result.tests.ebaySync ? '✅' : '❌'}`)
  console.log(`  Database Storage: ${result.tests.databaseStorage ? '✅' : '❌'}`)
  console.log(`  Data Quality: ${result.tests.dataQuality ? '✅' : '⚠️ '}`)
  console.log(`  OVERALL: ${result.passed ? '✅ PASSED' : '❌ FAILED'}`)

  if (result.issues.length > 0) {
    console.log(`\n  Issues (${result.issues.length}):`)
    result.issues.forEach(issue => console.log(`    - ${issue}`))
  }

  return result
}

async function main() {
  console.log('═'.repeat(79))
  console.log('EBAY INTEGRATION - FINAL AUDIT')
  console.log('═'.repeat(79))
  console.log(`Testing ${TEST_SKUS.length} SKUs: ${TEST_SKUS.join(', ')}`)
  console.log(`Environment: ${ebayConfig.environment}`)
  console.log(`Market Data Enabled: ${ebayConfig.marketDataEnabled}`)
  console.log(`Currency: GBP (UK marketplace)`)
  console.log('═'.repeat(79))

  if (!ebayConfig.marketDataEnabled) {
    console.log('\n❌ ERROR: EBAY_MARKET_DATA_ENABLED is not true')
    console.log('   Please set: EBAY_MARKET_DATA_ENABLED=true in .env.local')
    process.exit(1)
  }

  if (ebayConfig.environment === 'SANDBOX') {
    console.log('\n⚠️  WARNING: Using SANDBOX environment')
    console.log('   SANDBOX has very limited test data')
    console.log('   For real market data, set: EBAY_ENV=PRODUCTION')
    console.log()
  }

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const results: EbayAuditResult[] = []

  for (const sku of TEST_SKUS) {
    const result = await auditSKU(sku, supabase)
    results.push(result)
  }

  // Final summary
  console.log('\n\n' + '═'.repeat(79))
  console.log('FINAL AUDIT REPORT')
  console.log('═'.repeat(79))

  const passCount = results.filter(r => r.passed).length
  const failCount = results.filter(r => !r.passed).length
  const passRate = (passCount / results.length) * 100

  console.log(`\nTested SKUs: ${results.length}`)
  console.log(`Passed: ${passCount} ✅`)
  console.log(`Failed: ${failCount} ${failCount > 0 ? '❌' : ''}`)
  console.log(`Pass Rate: ${passRate.toFixed(1)}%`)

  console.log('\n' + '─'.repeat(79))
  console.log('DETAILED RESULTS:\n')

  results.forEach((result, index) => {
    console.log(`${index + 1}. ${result.sku}`)
    console.log(`   Status: ${result.passed ? '✅ PASSED' : '❌ FAILED'}`)
    console.log(`   Items fetched: ${result.metrics.itemsFetched}`)
    console.log(`   Database sizes: ${result.metrics.sizesInDatabase}`)
    if (result.metrics.avgPrice) {
      console.log(`   Avg price: £${result.metrics.avgPrice.toFixed(2)}`)
    }
    if (result.issues.length > 0) {
      console.log(`   Issues: ${result.issues.join(', ')}`)
    }
    console.log()
  })

  console.log('═'.repeat(79))
  if (passRate === 100) {
    console.log('🎉 100% PASS RATE - eBay INTEGRATION WORKING! 🎉')
    console.log('✅ eBay market data is flowing into master_market_data')
  } else if (passRate >= 50) {
    console.log(`⚠️  ${passRate.toFixed(1)}% pass rate - Partial success`)
    console.log('   Some products may not be available on eBay')
    console.log('   Or SANDBOX environment has limited data')
  } else {
    console.log(`⚠️  ${passRate.toFixed(1)}% pass rate - Review failures above`)
    console.log('   Check SANDBOX vs PRODUCTION environment')
  }
  console.log('═'.repeat(79))

  process.exit(passRate >= 50 ? 0 : 1)
}

main().catch((error) => {
  console.error('\n❌ FATAL ERROR:', error)
  process.exit(1)
})
