#!/usr/bin/env node
/**
 * Audit existing master_market_data schema
 * Check if we can use it instead of creating new tables
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

async function main() {
  console.log('🔍 AUDITING EXISTING SCHEMA\n')
  console.log('=' .repeat(80))

  // Check master_market_data
  console.log('\n📊 MASTER_MARKET_DATA TABLE')
  console.log('-'.repeat(80))

  const { count } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })

  console.log(`Total rows: ${count}`)

  // Get sample data to see schema
  const { data: sample } = await supabase
    .from('master_market_data')
    .select('*')
    .limit(3)

  if (sample && sample.length > 0) {
    console.log('\nSample row columns:')
    Object.keys(sample[0]).forEach(key => {
      const value = sample[0][key]
      const type = typeof value
      const hasData = value !== null
      console.log(`  ${key.padEnd(30)} ${type.padEnd(10)} ${hasData ? '✓' : '∅'}`)
    })

    console.log('\nSample data:')
    sample.forEach((row, i) => {
      console.log(`\nRow ${i + 1}:`)
      console.log(`  SKU: ${row.sku}`)
      console.log(`  Provider: ${row.provider}`)
      console.log(`  Size: ${row.size_key}`)
      console.log(`  Lowest Ask: ${row.lowest_ask} ${row.currency_code}`)
      console.log(`  Snapshot: ${row.snapshot_at}`)
    })
  }

  // Check if products catalog exists
  console.log('\n' + '='.repeat(80))
  console.log('📊 PRODUCT CATALOG TABLES')
  console.log('-'.repeat(80))

  const { count: aliasCount } = await supabase
    .from('alias_catalog_items')
    .select('*', { count: 'exact', head: true })

  const { count: stockxCount } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true })

  console.log(`\nalias_catalog_items: ${aliasCount} rows`)
  console.log(`stockx_products: ${stockxCount} rows`)

  // Check if unified products table exists
  const { data: productsCheck, error: productsError } = await supabase
    .from('products')
    .select('*', { count: 'exact', head: true })
    .limit(1)

  if (!productsError) {
    console.log(`products (unified): EXISTS (${productsCheck?.length || 0} rows)`)
  } else {
    console.log(`products (unified): DOES NOT EXIST`)
  }

  // Check materialized views
  console.log('\n' + '='.repeat(80))
  console.log('📊 MATERIALIZED VIEWS')
  console.log('-'.repeat(80))

  const { count: stockxLatestCount } = await supabase
    .from('stockx_market_latest')
    .select('*', { count: 'exact', head: true })

  const { count: aliasSnapshotCount } = await supabase
    .from('alias_market_snapshots')
    .select('*', { count: 'exact', head: true })

  console.log(`\nstockx_market_latest: ${stockxLatestCount} rows`)
  console.log(`alias_market_snapshots: ${aliasSnapshotCount} rows`)

  // Check if market_latest view exists
  const { data: marketLatestCheck, error: marketLatestError } = await supabase
    .from('market_latest')
    .select('*', { count: 'exact', head: true })
    .limit(1)

  if (!marketLatestError) {
    console.log(`market_latest (new): EXISTS`)
  } else {
    console.log(`market_latest (new): DOES NOT EXIST`)
  }

  // Summary
  console.log('\n' + '='.repeat(80))
  console.log('📋 ASSESSMENT')
  console.log('='.repeat(80))

  console.log('\nEXISTING INFRASTRUCTURE:')
  console.log(`  ✓ master_market_data: ${count} rows`)
  console.log(`  ✓ alias_catalog_items: ${aliasCount} rows`)
  console.log(`  ✓ stockx_products: ${stockxCount} rows`)
  console.log(`  ✓ stockx_market_latest: ${stockxLatestCount} rows`)
  console.log(`  ✓ alias_market_snapshots: ${aliasSnapshotCount} rows`)

  console.log('\nQUESTION: Can we use existing master_market_data?')

  if (count > 1000) {
    console.log('  ✅ YES - Has significant data')
    console.log('  ✅ Recommendation: FIX existing tables, don\'t rebuild')
    console.log('\nNEXT STEPS:')
    console.log('  1. Add missing indexes to master_market_data')
    console.log('  2. Create materialized view if missing')
    console.log('  3. Fix inventory table queries to use master_market_data')
    console.log('  4. Build sync jobs to populate master_market_data')
  } else {
    console.log('  ⚠️  MAYBE - Has some data but sparse')
    console.log('  ⚠️  Recommendation: Evaluate schema quality')
    console.log('\nNEED TO CHECK:')
    console.log('  1. Does schema have all needed fields?')
    console.log('  2. Is it properly indexed?')
    console.log('  3. Is data quality good?')
  }

  console.log('\n')
}

main().catch(console.error)
