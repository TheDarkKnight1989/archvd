#!/usr/bin/env npx tsx
/**
 * Test Alias Sync for Single Product (End-to-End)
 * Verifies the full sync pipeline with hardcoded regions
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { getAliasRegions } from '@/lib/services/alias/regions'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🧪 Testing Alias End-to-End Sync\n')

  const catalogId = '2002r-protection-pack-phantom-m2002rdb'
  const testSku = 'M2002RDB'

  const aliasClient = createAliasClient()

  // Step 1: Get regions (using new hardcoded approach)
  console.log('1. Getting Alias regions...')
  const regions = await getAliasRegions()
  console.log(`   ✅ Found ${regions.length} regions:`, regions.map(r => `${r.name} (${r.id})`).join(', '))

  // Step 2: Fetch pricing for all regions
  console.log('\n2. Fetching pricing for all regions...')
  let totalSnapshots = 0

  for (const region of regions) {
    try {
      const pricingResponse = await aliasClient.listPricingInsights(catalogId, region.id)
      const variantCount = pricingResponse.variants?.length || 0
      console.log(`   ✅ ${region.name}: ${variantCount} variants`)

      // Insert into database
      for (const variant of pricingResponse.variants || []) {
        if (!variant.availability) continue

        const snapshot = {
          provider: 'alias',
          provider_source: 'alias_pricing_insights',
          provider_product_id: catalogId,
          sku: testSku,
          size_numeric: variant.size,
          size_system: variant.size_unit || 'US',
          currency_code: 'USD',
          region_code: region.id,
          lowest_ask: variant.availability.lowest_listing_price_cents
            ? parseInt(variant.availability.lowest_listing_price_cents) / 100
            : null,
          highest_bid: variant.availability.highest_offer_price_cents
            ? parseInt(variant.availability.highest_offer_price_cents) / 100
            : null,
          last_sale_price: variant.availability.last_sold_listing_price_cents
            ? parseInt(variant.availability.last_sold_listing_price_cents) / 100
            : null,
          global_indicator_price: variant.availability.global_indicator_price_cents
            ? parseInt(variant.availability.global_indicator_price_cents) / 100
            : null,
          ask_count: variant.availability.number_of_listings,
          bid_count: variant.availability.number_of_offers,
          snapshot_at: new Date().toISOString(),
          is_flex: false,
          is_consigned: variant.consigned || false,
        }

        const { error: insertError } = await supabase
          .from('master_market_data')
          .insert(snapshot)

        if (!insertError) {
          totalSnapshots++
        } else if (!insertError.message.includes('duplicate')) {
          console.error(`     ⚠️ Insert error: ${insertError.message}`)
        }
      }
    } catch (error: any) {
      console.log(`   ❌ ${region.name}: ${error.message}`)
    }
  }

  // Step 3: Verify data in database
  console.log(`\n3. Verifying database...`)
  const { data: dbSnapshots, error: dbError } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'alias')
    .eq('sku', testSku)
    .gte('snapshot_at', new Date(Date.now() - 60000).toISOString()) // Last minute

  if (dbError) {
    console.error(`   ❌ Database query failed: ${dbError.message}`)
    return
  }

  const uniqueRegions = new Set(dbSnapshots?.map(s => s.region_code) || [])
  const uniqueSizes = new Set(dbSnapshots?.map(s => s.size_numeric) || [])

  console.log(`   ✅ Database contains ${dbSnapshots?.length || 0} snapshots`)
  console.log(`   ✅ Regions: ${uniqueRegions.size} (${[...uniqueRegions].join(', ')})`)
  console.log(`   ✅ Unique sizes: ${uniqueSizes.size}`)

  // Step 4: Sample data quality
  if (dbSnapshots && dbSnapshots.length > 0) {
    const sample = dbSnapshots[0]
    console.log(`\n4. Sample data:`)
    console.log(`   SKU: ${sample.sku}`)
    console.log(`   Size: ${sample.size_numeric} ${sample.size_system}`)
    console.log(`   Region: ${sample.region_code}`)
    console.log(`   Lowest Ask: $${sample.lowest_ask || 'N/A'}`)
    console.log(`   Highest Bid: $${sample.highest_bid || 'N/A'}`)
    console.log(`   Last Sale: $${sample.last_sale_price || 'N/A'}`)
  }

  console.log(`\n✅ ALIAS SYNC WORKING END-TO-END!`)
  console.log(`   Total snapshots synced: ${totalSnapshots}`)
}

main().catch(console.error)
