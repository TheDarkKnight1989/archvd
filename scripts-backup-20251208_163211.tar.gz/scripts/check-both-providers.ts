#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function check() {
  // Count StockX SKUs
  const { data: stockxData } = await supabase
    .from('master_market_data')
    .select('sku')
    .eq('provider', 'stockx');

  const stockxSkus = new Set(stockxData?.map(r => r.sku) || []);

  // Count Alias SKUs
  const { data: aliasData } = await supabase
    .from('master_market_data')
    .select('sku')
    .eq('provider', 'alias');

  const aliasSkus = new Set(aliasData?.map(r => r.sku) || []);

  console.log('StockX SKUs:', stockxSkus.size);
  console.log('Alias SKUs:', aliasSkus.size);
  console.log('');

  const answer = (stockxSkus.size >= 125 && aliasSkus.size >= 125) ? 'YES' : 'NO';
  console.log('Answer:', answer);
}

check();
