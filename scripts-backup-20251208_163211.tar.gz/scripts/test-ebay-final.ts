#!/usr/bin/env node

/**
 * Final eBay test with env loading
 */

import { config } from 'dotenv'
import { resolve } from 'path'

// Load .env.local FIRST
config({ path: resolve(process.cwd(), '.env.local') })

import { EbayClient } from '../src/lib/services/ebay/client'
import { enrichEbaySoldItem } from '../src/lib/services/ebay/extractors'

const SKU = process.argv[2] || 'DZ4137-700'

async function main() {
  console.log('\n' + '='.repeat(80))
  console.log('eBay Live Test - ' + SKU)
  console.log('='.repeat(80) + '\n')

  console.log('Env check:')
  console.log('  EBAY_MARKET_DATA_ENABLED:', process.env.EBAY_MARKET_DATA_ENABLED)
  console.log('  EBAY_ENV:', process.env.EBAY_ENV)
  console.log()

  const client = new EbayClient()

  console.log('Fetching with TWO-STEP API (fetchFullDetails: true)...\n')

  const result = await client.searchSold({
    query: SKU,
    limit: 50,
    conditionIds: [1000], // Only NEW condition
    qualifiedPrograms: ['AUTHENTICITY_GUARANTEE'],
    categoryIds: ['15709', '95672', '155194'],
    soldItemsOnly: true,
    fetchFullDetails: true,
  })

  console.log(`✅ Fetched ${result.items.length} items`)
  console.log(`   Full details: ${result.fullDetailsFetched}\n`)

  if (result.items.length === 0) {
    console.log('No items found')
    return
  }

  // Enrich all
  result.items.forEach((item) => {
    enrichEbaySoldItem(item)
  })

  console.log('='.repeat(80))
  console.log('EVERY SALE - LINE BY LINE')
  console.log('='.repeat(80) + '\n')

  result.items.forEach((item, i) => {
    console.log(`${i + 1}. ${item.title}`)
    console.log(`   Price: ${item.currency} ${item.price}`)
    console.log(`   Condition: ${item.conditionId}`)
    console.log(`   AG: ${item.authenticityVerification ? 'YES' : 'NO'}`)

    if (item.variations && item.variations.length > 0) {
      console.log(`   Variations: ${item.variations.length}`)
      if (item.variations[0].localizedAspects) {
        item.variations[0].localizedAspects.slice(0, 3).forEach((a) => {
          console.log(`     ${a.name}: ${a.value}`)
        })
      }
    } else {
      console.log(`   Variations: NONE (will use title)`)
    }

    if (item.sizeInfo) {
      console.log(`   EXTRACTED: ${item.sizeInfo.normalizedKey}`)
      console.log(`   System: ${item.sizeInfo.system}`)
      console.log(`   Confidence: ${item.sizeInfo.confidence}`)

      const included =
        item.conditionId === 1000 &&
        item.authenticityVerification &&
        item.sizeInfo.system !== 'UNKNOWN' &&
        item.sizeInfo.confidence === 'HIGH'

      console.log(`   INCLUDED: ${included ? 'YES ✅' : 'NO ❌'}`)

      if (!included) {
        let reason = ''
        if (item.conditionId !== 1000) reason = `not_new_condition (${item.conditionId})`
        else if (!item.authenticityVerification) reason = 'no_authenticity_guarantee'
        else if (item.sizeInfo.system === 'UNKNOWN') reason = 'size_system_unknown'
        else if (item.sizeInfo.confidence !== 'HIGH')
          reason = `size_not_from_variations (${item.sizeInfo.confidence})`
        if (reason) console.log(`   Reason: ${reason}`)
      }
    } else {
      console.log(`   EXTRACTED: No size`)
      console.log(`   INCLUDED: NO ❌`)
      console.log(`   Reason: missing_size`)
    }
    console.log()
  })

  // Summary
  const included = result.items.filter(
    (item) =>
      item.conditionId === 1000 &&
      item.authenticityVerification &&
      item.sizeInfo &&
      item.sizeInfo.system !== 'UNKNOWN' &&
      item.sizeInfo.confidence === 'HIGH'
  )

  console.log('='.repeat(80))
  console.log('SUMMARY')
  console.log('='.repeat(80) + '\n')
  console.log(`Total fetched: ${result.items.length}`)
  console.log(`INCLUDED (HIGH confidence): ${included.length}`)
  console.log(`EXCLUDED: ${result.items.length - included.length}\n`)

  // By size system
  const bySystem = included.reduce((acc, item) => {
    const sys = item.sizeInfo!.system
    if (!acc[sys]) acc[sys] = []
    acc[sys].push(item)
    return acc
  }, {} as Record<string, typeof included>)

  console.log('INCLUDED items by size system:\n')
  Object.entries(bySystem).forEach(([sys, items]) => {
    console.log(`${sys}: ${items.length} items`)
    items.forEach((item) => {
      console.log(`  ${item.sizeInfo!.normalizedKey}: ${item.currency} ${item.price}`)
    })
    console.log()
  })

  console.log('='.repeat(80) + '\n')
}

main().catch((err) => {
  console.error('\nError:', err.message)
  console.error(err)
  process.exit(1)
})
