#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('📊 Checking seeded data...\n')

// Count products
const { count: productCount } = await supabase
  .from('products')
  .select('*', { count: 'exact', head: true })

console.log(`✅ Products: ${productCount}`)

// Count variants
const { count: variantCount } = await supabase
  .from('product_variants')
  .select('*', { count: 'exact', head: true })

console.log(`✅ Variants: ${variantCount}`)

// Sample products
const { data: sampleProducts } = await supabase
  .from('products')
  .select('sku, brand, model, tier, popularity_score')
  .limit(5)

console.log('\n📋 Sample products:')
sampleProducts.forEach(p => {
  console.log(`  ${p.sku} - ${p.brand} ${p.model} (tier: ${p.tier}, score: ${p.popularity_score})`)
})

// Check products needing sync (all should need sync now)
const { data: needsSync } = await supabase
  .from('products')
  .select('sku')
  .is('last_synced_at', null)
  .limit(5)

console.log(`\n🔄 Products needing initial sync: ${needsSync?.length || 0} shown (all ${productCount} need sync)`)

console.log('\n✅ Database seeded successfully!')
console.log('\nNext: Run market data sync to populate pricing')
