#!/usr/bin/env node

/**
 * Test that prices are displaying correctly after the /100 fix
 */

import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

async function testPriceFix() {
  console.log('\n🧪 TESTING PRICE FIX')
  console.log('='.repeat(80))

  // Get a snapshot with price data
  const { data: snapshot, error: snapErr } = await supabase
    .from('stockx_market_snapshots')
    .select('*')
    .not('lowest_ask', 'is', null)
    .limit(1)
    .single()

  if (snapErr || !snapshot) {
    console.error('❌ No snapshot data found')
    return
  }

  console.log('\n📊 RAW DATA (stockx_market_snapshots):')
  console.log('  Variant ID:', snapshot.stockx_variant_id)
  console.log('  Currency:', snapshot.currency_code)
  console.log('  Lowest Ask (pennies):', snapshot.lowest_ask)
  console.log('  Highest Bid (pennies):', snapshot.highest_bid || 'null')

  // Calculate what UI should display
  const expectedLowestAsk = snapshot.lowest_ask / 100
  const expectedHighestBid = snapshot.highest_bid ? snapshot.highest_bid / 100 : null

  console.log('\n💰 EXPECTED DISPLAY (after /100):')
  console.log('  Lowest Ask:', `${snapshot.currency_code} ${expectedLowestAsk.toFixed(2)}`)
  if (expectedHighestBid) {
    console.log('  Highest Bid:', `${snapshot.currency_code} ${expectedHighestBid.toFixed(2)}`)
  }

  // Get from stockx_market_latest (what the hook fetches)
  const { data: latest, error: latestErr } = await supabase
    .from('stockx_market_latest')
    .select('*')
    .eq('stockx_variant_id', snapshot.stockx_variant_id)
    .eq('currency_code', snapshot.currency_code)
    .single()

  if (latestErr || !latest) {
    console.error('❌ No latest data found')
    return
  }

  console.log('\n📈 HOOK DATA (stockx_market_latest):')
  console.log('  Lowest Ask (raw):', latest.lowest_ask)
  console.log('  Highest Bid (raw):', latest.highest_bid || 'null')

  // Simulate what the hook does NOW (after fix)
  const hookLowestAsk = latest.lowest_ask ? latest.lowest_ask / 100 : null
  const hookHighestBid = latest.highest_bid ? latest.highest_bid / 100 : null

  console.log('\n✅ HOOK PROCESSING (with /100 fix):')
  console.log('  Lowest Ask:', hookLowestAsk ? `${latest.currency_code} ${hookLowestAsk.toFixed(2)}` : 'null')
  console.log('  Highest Bid:', hookHighestBid ? `${latest.currency_code} ${hookHighestBid.toFixed(2)}` : 'null')

  // Verify
  const askMatch = Math.abs((hookLowestAsk || 0) - expectedLowestAsk) < 0.01
  const bidMatch = expectedHighestBid === null || Math.abs((hookHighestBid || 0) - expectedHighestBid) < 0.01

  console.log('\n' + '='.repeat(80))
  if (askMatch && bidMatch) {
    console.log('✅ PRICES CORRECT - Fix is working!')
    console.log(`   Example: £${snapshot.lowest_ask} pennies → £${expectedLowestAsk.toFixed(2)} display`)
  } else {
    console.log('❌ PRICES STILL WRONG')
    console.log('   Expected:', expectedLowestAsk)
    console.log('   Got:', hookLowestAsk)
  }
  console.log('='.repeat(80) + '\n')
}

testPriceFix().catch(console.error)
