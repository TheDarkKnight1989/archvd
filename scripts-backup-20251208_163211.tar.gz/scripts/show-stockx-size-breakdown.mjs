#!/usr/bin/env node
/**
 * StockX Size-by-Size Price Breakdown
 *
 * Shows all pricing data organized by size with clear labels
 */

import { createClient } from '@supabase/supabase-js';

const SKU = 'DD1391100';
const CURRENCY = 'GBP';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function showSizeBreakdown() {
  console.log('================================================================================');
  console.log('STOCKX SIZE-BY-SIZE PRICE BREAKDOWN');
  console.log('================================================================================');
  console.log('SKU:', SKU);
  console.log('Currency:', CURRENCY);
  console.log('================================================================================\n');

  // ========================================================================
  // Step 1: Look up StockX Product ID
  // ========================================================================

  const { data: product } = await supabase
    .from('product_catalog')
    .select('id, sku, stockx_product_id')
    .eq('sku', SKU)
    .single();

  if (!product?.stockx_product_id) {
    console.error('❌ Product not found');
    process.exit(1);
  }

  const stockxProductId = product.stockx_product_id;

  // ========================================================================
  // Step 2: Fetch Variants (to get size labels)
  // ========================================================================

  console.log('🔄 Fetching variants for size labels...\n');

  const { StockxCatalogService } = await import('../src/lib/services/stockx/catalog.ts');
  const catalogService = new StockxCatalogService(undefined);

  let variants;
  try {
    variants = await catalogService.getProductVariants(stockxProductId);
  } catch (error) {
    console.error('❌ Failed to fetch variants:', error.message);
    process.exit(1);
  }

  // Create a map: variantId -> size info
  const sizeMap = {};
  variants.forEach(v => {
    sizeMap[v.variantId] = {
      size: v.variantName,      // e.g., "UK 7"
      value: v.variantValue,    // e.g., "7"
    };
  });

  console.log(`✅ Found ${variants.length} sizes\n`);

  // ========================================================================
  // Step 3: Fetch Market Data
  // ========================================================================

  console.log('🔄 Fetching market data...\n');

  const client = catalogService.client;
  let marketData;
  try {
    marketData = await client.request(
      `/v2/catalog/products/${stockxProductId}/market-data?currencyCode=${CURRENCY}`
    );
  } catch (error) {
    console.error('❌ Failed to fetch market data:', error.message);
    process.exit(1);
  }

  const marketVariants = Array.isArray(marketData) ? marketData : marketData?.variants || [];

  console.log(`✅ Found market data for ${marketVariants.length} sizes\n`);
  console.log('================================================================================');
  console.log('SIZE-BY-SIZE BREAKDOWN');
  console.log('================================================================================\n');

  // ========================================================================
  // Step 4: Display Size-by-Size Breakdown
  // ========================================================================

  // Sort by variant value (numeric size)
  const sortedData = marketVariants
    .map(v => ({
      ...v,
      sizeInfo: sizeMap[v.variantId] || { size: 'Unknown', value: '0' },
    }))
    .sort((a, b) => {
      const aVal = parseFloat(a.sizeInfo.value) || 0;
      const bVal = parseFloat(b.sizeInfo.value) || 0;
      return aVal - bVal;
    });

  for (const variant of sortedData) {
    const size = variant.sizeInfo.size;

    console.log(`📏 SIZE: ${size}`);
    console.log('─'.repeat(80));

    // Top-level pricing
    console.log('\n  💰 PRIMARY PRICING:');
    console.log(`     Lowest Ask:          £${variant.lowestAskAmount || 'N/A'}`);
    console.log(`     Highest Bid:         £${variant.highestBidAmount || 'N/A'}`);
    console.log(`     Flex Lowest Ask:     ${variant.flexLowestAskAmount ? '£' + variant.flexLowestAskAmount : 'NOT AVAILABLE'}`);
    console.log(`     Sell Faster:         £${variant.sellFasterAmount || 'N/A'}`);
    console.log(`     Earn More:           £${variant.earnMoreAmount || 'N/A'}`);

    // Standard market data
    if (variant.standardMarketData) {
      console.log('\n  📊 STANDARD MARKET DATA:');
      console.log(`     Lowest Ask:          £${variant.standardMarketData.lowestAsk || 'N/A'}`);
      console.log(`     Highest Bid:         £${variant.standardMarketData.highestBidAmount || 'N/A'}`);
      console.log(`     Sell Faster:         £${variant.standardMarketData.sellFaster || 'N/A'}`);
      console.log(`     Earn More:           £${variant.standardMarketData.earnMore || 'N/A'}`);
      console.log(`     Beat US:             ${variant.standardMarketData.beatUS ? '£' + variant.standardMarketData.beatUS : 'N/A'}`);
    }

    // Flex market data
    if (variant.flexMarketData) {
      console.log('\n  ⚡ FLEX MARKET DATA:');
      console.log(`     Lowest Ask:          ${variant.flexMarketData.lowestAsk ? '£' + variant.flexMarketData.lowestAsk : 'NOT AVAILABLE'}`);
      console.log(`     Highest Bid:         £${variant.flexMarketData.highestBidAmount || 'N/A'}`);
      console.log(`     Sell Faster:         £${variant.flexMarketData.sellFaster || 'N/A'}`);
      console.log(`     Earn More:           £${variant.flexMarketData.earnMore || 'N/A'}`);
      console.log(`     Beat US:             ${variant.flexMarketData.beatUS ? '£' + variant.flexMarketData.beatUS : 'N/A'}`);
    }

    // Direct market data (consignment)
    if (variant.directMarketData) {
      console.log('\n  🎯 DIRECT MARKET DATA (Consignment):');
      console.log(`     Lowest Ask:          ${variant.directMarketData.lowestAsk ? '£' + variant.directMarketData.lowestAsk : 'NOT AVAILABLE'}`);
      console.log(`     Highest Bid:         £${variant.directMarketData.highestBidAmount || 'N/A'}`);
      console.log(`     Sell Faster:         £${variant.directMarketData.sellFaster || 'N/A'}`);
      console.log(`     Earn More:           £${variant.directMarketData.earnMore || 'N/A'}`);
      console.log(`     Beat US:             ${variant.directMarketData.beatUS ? '£' + variant.directMarketData.beatUS : 'N/A'}`);
    }

    console.log('\n' + '='.repeat(80) + '\n');
  }

  // ========================================================================
  // Summary
  // ========================================================================

  console.log('\n📊 SUMMARY:');
  console.log('─'.repeat(80));
  console.log(`Total sizes: ${sortedData.length}`);

  const withFlex = sortedData.filter(v => v.flexLowestAskAmount !== null).length;
  const withoutFlex = sortedData.length - withFlex;

  console.log(`Sizes with Flex pricing: ${withFlex}`);
  console.log(`Sizes without Flex pricing: ${withoutFlex}`);

  const avgAsk = sortedData.reduce((sum, v) => sum + parseFloat(v.lowestAskAmount || 0), 0) / sortedData.length;
  const avgBid = sortedData.reduce((sum, v) => sum + parseFloat(v.highestBidAmount || 0), 0) / sortedData.length;

  console.log(`Average Lowest Ask: £${avgAsk.toFixed(2)}`);
  console.log(`Average Highest Bid: £${avgBid.toFixed(2)}`);
  console.log(`Average Spread: £${(avgAsk - avgBid).toFixed(2)}`);

  console.log('\n' + '='.repeat(80));
}

showSizeBreakdown().catch(err => {
  console.error('\n❌ FATAL ERROR:', err.message);
  console.error(err.stack);
  process.exit(1);
});
