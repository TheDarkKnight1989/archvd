#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function showUsableData() {
  console.log('═══════════════════════════════════════════════════════════');
  console.log('ACTUAL USABLE DATA - What you can show users');
  console.log('═══════════════════════════════════════════════════════════\n');

  // Get actual market data rows
  const { data: allData } = await supabase
    .from('master_market_data')
    .select('provider, sku, size_key, region_code, currency_code, lowest_ask, is_flex, is_consigned')
    .order('created_at', { ascending: false })
    .limit(50);

  if (!allData || allData.length === 0) {
    console.log('❌ NO DATA - Table is empty\n');
    return;
  }

  // Group by SKU
  const bySku = new Map<string, any[]>();
  allData.forEach(row => {
    if (!bySku.has(row.sku)) {
      bySku.set(row.sku, []);
    }
    bySku.get(row.sku)!.push(row);
  });

  console.log(`Total SKUs: ${bySku.size}\n`);

  // Show each SKU with sample data
  let skuNum = 1;
  for (const [sku, rows] of bySku) {
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`${skuNum}. SKU: ${sku}`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

    const provider = rows[0].provider;
    const regions = new Set(rows.map(r => r.region_code));
    const sizes = new Set(rows.map(r => r.size_key));

    console.log(`Provider: ${provider.toUpperCase()}`);
    console.log(`Regions: ${Array.from(regions).join(', ')} (${regions.size} regions)`);
    console.log(`Sizes: ${sizes.size} sizes available`);
    console.log(`Total price points: ${rows.length}`);

    // Show sample prices for first 3 sizes
    console.log('\nSample prices:');
    const sampleSizes = Array.from(sizes).slice(0, 3);
    sampleSizes.forEach(size => {
      const sizeRows = rows.filter(r => r.size_key === size);
      console.log(`\n  Size ${size}:`);
      sizeRows.forEach(r => {
        const price = r.lowest_ask ? `$${(r.lowest_ask / 100).toFixed(2)}` : 'N/A';
        const flags = [];
        if (r.is_flex) flags.push('FLEX');
        if (r.is_consigned) flags.push('CONSIGNED');
        const flagStr = flags.length > 0 ? ` [${flags.join(', ')}]` : '';
        console.log(`    ${r.region_code} (${r.currency_code}): ${price}${flagStr}`);
      });
    });

    console.log('');
    skuNum++;
  }

  console.log('═══════════════════════════════════════════════════════════');
  console.log('WHAT THIS MEANS');
  console.log('═══════════════════════════════════════════════════════════');
  console.log('Each row above is a price point you can show to users.');
  console.log('If you see prices in dollars (like $150.00), the data is correct.');
  console.log('If you see NO prices or prices seem wrong, the sync failed.');
  console.log('');
}

showUsableData();
