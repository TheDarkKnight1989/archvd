#!/usr/bin/env npx tsx
/**
 * Conservative StockX Sync
 *
 * Slower but reliable approach to avoid rate limiting:
 * - 3 products at a time (not 10)
 * - 5s delay between batches
 * - 3s delay between regions
 * - Better error capture
 */

import { createClient } from '@supabase/supabase-js'
import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const CONCURRENCY = 3 // Conservative: only 3 products at a time
const BATCH_DELAY = 5000 // 5 seconds between batches
const REGION_DELAY = 3000 // 3 seconds between regions

interface SyncResult {
  sku: string
  stockxProductId: string
  brand: string
  success: boolean
  totalSnapshots: number
  regionResults: {
    US: { success: boolean; snapshots: number; error?: string }
    UK: { success: boolean; snapshots: number; error?: string }
    EU: { success: boolean; snapshots: number; error?: string }
  }
}

async function syncProductConservative(
  stockxProductId: string,
  sku: string,
  brand: string
): Promise<SyncResult> {
  console.log(`[${sku}] Starting conservative sync...`)

  const result: SyncResult = {
    sku,
    stockxProductId,
    brand,
    success: false,
    totalSnapshots: 0,
    regionResults: {
      US: { success: false, snapshots: 0 },
      UK: { success: false, snapshots: 0 },
      EU: { success: false, snapshots: 0 },
    },
  }

  // Sync all 3 regions SEQUENTIALLY with delays
  // Priority order: UK → EU → US
  const regions: Array<{ code: 'US' | 'UK' | 'EU', name: string }> = [
    { code: 'UK', name: '🇬🇧 UK' },
    { code: 'EU', name: '🇪🇺 EU' },
    { code: 'US', name: '🇺🇸 US' },
  ]

  for (const region of regions) {
    try {
      console.log(`[${sku}] ${region.name} - Syncing...`)

      const regionResult = await syncProductAllRegions(
        undefined,
        stockxProductId,
        region.code,
        false
      )

      result.regionResults[region.code].success = regionResult.success
      result.regionResults[region.code].snapshots = regionResult.primaryResult.snapshotsCreated

      if (!regionResult.success && regionResult.primaryResult.error) {
        result.regionResults[region.code].error = regionResult.primaryResult.error
      }

      if (regionResult.success) {
        console.log(`[${sku}] ${region.name} ✅ ${regionResult.primaryResult.snapshotsCreated} snapshots`)
      } else {
        console.log(`[${sku}] ${region.name} ❌ ${regionResult.primaryResult.error?.substring(0, 80)}`)
      }
    } catch (error: any) {
      result.regionResults[region.code].error = error.message
      console.log(`[${sku}] ${region.name} ❌ Exception: ${error.message?.substring(0, 80)}`)
    }

    // Delay between regions (even on same product)
    if (region.code !== 'US') { // No delay after last region (US is last now)
      console.log(`[${sku}] Waiting ${REGION_DELAY / 1000}s before next region...`)
      await new Promise((resolve) => setTimeout(resolve, REGION_DELAY))
    }
  }

  // Calculate totals
  result.totalSnapshots =
    result.regionResults.US.snapshots +
    result.regionResults.UK.snapshots +
    result.regionResults.EU.snapshots

  result.success =
    result.regionResults.US.success ||
    result.regionResults.UK.success ||
    result.regionResults.EU.success

  const status = result.success ? '✅' : '❌'
  console.log(`[${sku}] ${status} Complete: ${result.totalSnapshots} total snapshots\n`)

  return result
}

async function conservativeSync() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗')
  console.log('║         Conservative StockX Sync (3 concurrent, slow & steady)       ║')
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n')

  const startTime = Date.now()

  // Fetch all products
  const { data: products, error } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, brand')
    .order('style_id')

  if (error || !products) {
    console.error('❌ Failed to fetch products:', error?.message)
    process.exit(1)
  }

  console.log(`📦 Total products: ${products.length}`)

  // Check which are already synced
  const { data: syncedData } = await supabase
    .from('master_market_data')
    .select('provider_product_id')
    .eq('provider', 'stockx')

  const syncedIds = new Set(syncedData?.map((r) => r.provider_product_id).filter(Boolean))
  const productsToSync = products.filter((p) => !syncedIds.has(p.stockx_product_id))

  console.log(`✅ Already synced: ${syncedIds.size}`)
  console.log(`🔄 To sync: ${productsToSync.length}`)
  console.log(`⚡ Concurrency: ${CONCURRENCY} products at a time`)
  console.log(`⏱️  Batch delay: ${BATCH_DELAY / 1000}s`)
  console.log(`⏱️  Region delay: ${REGION_DELAY / 1000}s\n`)
  console.log('─'.repeat(75) + '\n')

  // Process in batches of CONCURRENCY
  const results: SyncResult[] = []
  let totalSynced = 0
  let totalFailed = 0
  let totalSnapshots = 0

  for (let i = 0; i < productsToSync.length; i += CONCURRENCY) {
    const batch = productsToSync.slice(i, i + CONCURRENCY)
    const batchNum = Math.floor(i / CONCURRENCY) + 1
    const totalBatches = Math.ceil(productsToSync.length / CONCURRENCY)

    console.log(`\n🚀 BATCH ${batchNum}/${totalBatches} (${batch.length} products)`)
    console.log('─'.repeat(75))

    // Sync all products in this batch in parallel
    const batchResults = await Promise.all(
      batch.map((product) =>
        syncProductConservative(
          product.stockx_product_id,
          product.style_id,
          product.brand || 'Unknown'
        )
      )
    )

    results.push(...batchResults)

    // Update counts
    batchResults.forEach((r) => {
      if (r.success) {
        totalSynced++
        totalSnapshots += r.totalSnapshots
      } else {
        totalFailed++
      }
    })

    console.log('─'.repeat(75))
    console.log(
      `Batch ${batchNum} complete: ${batchResults.filter((r) => r.success).length}/${batch.length} successful`
    )
    console.log(`Running total: ${totalSynced} synced, ${totalFailed} failed, ${totalSnapshots.toLocaleString()} snapshots`)
    console.log('─'.repeat(75))

    // Delay before next batch
    if (i + CONCURRENCY < productsToSync.length) {
      console.log(`\n⏳ Waiting ${BATCH_DELAY / 1000}s before next batch...\n`)
      await new Promise((resolve) => setTimeout(resolve, BATCH_DELAY))
    }
  }

  const totalDuration = ((Date.now() - startTime) / 1000 / 60).toFixed(1)

  // Final summary
  console.log('\n' + '═'.repeat(75))
  console.log('╔═══════════════════════════════════════════════════════════════════════╗')
  console.log('║                           SYNC SUMMARY                                ║')
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n')

  console.log(`Products attempted:  ${productsToSync.length}`)
  console.log(`Products succeeded:  ${totalSynced}`)
  console.log(`Products failed:     ${totalFailed}`)
  console.log(`Total snapshots:     ${totalSnapshots.toLocaleString()}`)
  console.log(`Duration:            ${totalDuration} minutes`)
  console.log(`Success rate:        ${((totalSynced / productsToSync.length) * 100).toFixed(1)}%`)

  // Check final coverage
  const { data: finalSyncedData } = await supabase
    .from('master_market_data')
    .select('provider_product_id')
    .eq('provider', 'stockx')

  const finalSyncedIds = new Set(finalSyncedData?.map((r) => r.provider_product_id).filter(Boolean))

  console.log(`\nFinal Coverage:`)
  console.log(`  Total products:      ${products.length}`)
  console.log(`  Successfully synced: ${finalSyncedIds.size}`)
  console.log(`  Still missing:       ${products.length - finalSyncedIds.size}`)
  console.log(`  Coverage:            ${((finalSyncedIds.size / products.length) * 100).toFixed(1)}%`)

  console.log('\n' + '═'.repeat(75))
  console.log('\n✅ Conservative Sync Complete\n')
}

conservativeSync().catch(console.error)
