#!/usr/bin/env npx tsx
/**
 * Comprehensive Cleanup and Fresh Sync
 *
 * PHASE 1: Clean slate - Delete ALL StockX data with 6x duplication bug
 * PHASE 2: Fresh sync with FIXED deduplication code
 * PHASE 3: Real-time data quality verification
 *
 * Goal: 100% success rate with perfect data quality
 */

import { createClient } from '@supabase/supabase-js'
import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const DELAY_BETWEEN_PRODUCTS = 15000 // 15 seconds
const DELAY_BETWEEN_REGIONS = 5000 // 5 seconds
const MAX_RETRIES = 5
const RETRY_DELAY_BASE = 10000

interface ProductSync {
  stockxProductId: string
  sku: string
  brand: string
}

interface SyncResult {
  sku: string
  success: boolean
  retries: number
  dataQuality: {
    totalRows: number
    uniqueSizes: number
    regionsComplete: string[]
    hasDuplicates: boolean
    pricesInCents: boolean
  }
}

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

async function verifyProductData(stockxProductId: string, sku: string): Promise<SyncResult['dataQuality']> {
  const { data } = await supabase
    .from('master_market_data')
    .select('id, size_key, region_code, currency_code, lowest_ask, is_flex, is_consigned, provider_source')
    .eq('provider', 'stockx')
    .eq('provider_product_id', stockxProductId)

  const regions = new Set(data?.map(r => r.region_code).filter(Boolean))
  const uniqueSizes = new Set(data?.map(r => r.size_key).filter(Boolean))

  // Check for duplicates by counting unique combinations
  const uniqueCombinations = new Set(
    data?.map(r => `${r.region_code}|${r.size_key}|${r.is_flex}|${r.is_consigned}|${r.provider_source}`)
  )

  const hasDuplicates = uniqueCombinations.size !== (data?.length || 0)

  // Check prices are in cents (≥1000)
  const pricesInCents = data?.every(r => !r.lowest_ask || r.lowest_ask >= 1000) || false

  return {
    totalRows: data?.length || 0,
    uniqueSizes: uniqueSizes.size,
    regionsComplete: Array.from(regions),
    hasDuplicates,
    pricesInCents,
  }
}

async function syncSingleProduct(
  product: ProductSync,
  attempt: number = 1
): Promise<SyncResult> {
  const result: SyncResult = {
    sku: product.sku,
    success: false,
    retries: attempt - 1,
    dataQuality: {
      totalRows: 0,
      uniqueSizes: 0,
      regionsComplete: [],
      hasDuplicates: false,
      pricesInCents: true,
    },
  }

  console.log(`\n[${product.sku}] Attempt ${attempt}/${MAX_RETRIES}`)

  // Sync all 3 regions sequentially: UK → EU → US
  const regions: Array<{ code: 'US' | 'UK' | 'EU'; name: string }> = [
    { code: 'UK', name: '🇬🇧 UK' },
    { code: 'EU', name: '🇪🇺 EU' },
    { code: 'US', name: '🇺🇸 US' },
  ]

  let allRegionsSucceeded = true

  for (const region of regions) {
    try {
      console.log(`  ${region.name} - Syncing...`)

      const regionResult = await syncProductAllRegions(
        undefined,
        product.stockxProductId,
        region.code,
        false
      )

      if (!regionResult.success) {
        allRegionsSucceeded = false
        const error = regionResult.primaryResult.error || 'Unknown error'
        console.log(`  ${region.name} ❌ ${error.substring(0, 100)}`)
      } else {
        console.log(`  ${region.name} ✅ ${regionResult.primaryResult.snapshotsCreated} snapshots`)
      }
    } catch (error: any) {
      allRegionsSucceeded = false
      console.log(`  ${region.name} ❌ Exception: ${error.message?.substring(0, 100)}`)
    }

    // Delay between regions
    if (region.code !== 'US') {
      await sleep(DELAY_BETWEEN_REGIONS)
    }
  }

  // Verify data quality in database
  const dataQuality = await verifyProductData(product.stockxProductId, product.sku)
  result.dataQuality = dataQuality

  // Check if data is good
  const hasAllRegions = dataQuality.regionsComplete.length === 3
  const noDuplicates = !dataQuality.hasDuplicates
  const goodPrices = dataQuality.pricesInCents

  if (hasAllRegions && noDuplicates && goodPrices && allRegionsSucceeded) {
    result.success = true
    console.log(`[${product.sku}] ✅ PERFECT - All regions, no duplicates, prices in cents`)
  } else if (dataQuality.totalRows > 0) {
    // Data exists but has quality issues
    console.log(`[${product.sku}] ⚠️ DATA QUALITY ISSUES:`)
    if (!hasAllRegions) console.log(`   - Missing regions: ${3 - dataQuality.regionsComplete.length}`)
    if (dataQuality.hasDuplicates) console.log(`   - HAS DUPLICATES! (BUG!)`)
    if (!goodPrices) console.log(`   - Prices in dollars not cents! (BUG!)`)

    // Retry if quality issues found
    if (attempt < MAX_RETRIES) {
      const retryDelay = RETRY_DELAY_BASE * Math.pow(2, attempt - 1)
      console.log(`[${product.sku}] Waiting ${retryDelay / 1000}s before retry ${attempt + 1}...`)
      await sleep(retryDelay)
      return syncSingleProduct(product, attempt + 1)
    }
  } else {
    console.log(`[${product.sku}] ❌ NO DATA in database - Will retry`)

    if (attempt < MAX_RETRIES) {
      const retryDelay = RETRY_DELAY_BASE * Math.pow(2, attempt - 1)
      console.log(`[${product.sku}] Waiting ${retryDelay / 1000}s before retry ${attempt + 1}...`)
      await sleep(retryDelay)
      return syncSingleProduct(product, attempt + 1)
    } else {
      console.log(`[${product.sku}] ❌ MAX RETRIES REACHED - FAILED`)
    }
  }

  return result
}

async function main() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗')
  console.log('║     Comprehensive Cleanup and Fresh Sync - 100% Quality Guaranteed   ║')
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n')

  const startTime = Date.now()

  // ============================================================================
  // PHASE 1: CLEANUP - Delete ALL StockX data with 6x duplication bug
  // ============================================================================

  console.log('═'.repeat(75))
  console.log('PHASE 1: CLEANUP - Deleting all StockX data with duplication bug\n')

  const { count: beforeCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')

  console.log(`📊 Current database state:`)
  console.log(`   Total StockX rows: ${beforeCount}`)
  console.log(`   Expected after cleanup: 0`)
  console.log(`\n⚠️  DELETING ALL StockX data to start fresh...\n`)

  const { error: deleteError } = await supabase
    .from('master_market_data')
    .delete()
    .eq('provider', 'stockx')

  if (deleteError) {
    console.error('❌ Failed to delete StockX data:', deleteError)
    process.exit(1)
  }

  const { count: afterCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')

  console.log(`✅ Cleanup complete: ${beforeCount} → ${afterCount} rows\n`)
  console.log('═'.repeat(75) + '\n')

  // ============================================================================
  // PHASE 2: FRESH SYNC with FIXED deduplication code
  // ============================================================================

  console.log('═'.repeat(75))
  console.log('PHASE 2: FRESH SYNC - Using fixed deduplication code\n')

  // Fetch all products
  const { data: allProducts, error: productsError } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, brand')
    .order('style_id')

  if (productsError || !allProducts) {
    console.error('❌ Failed to fetch products:', productsError?.message)
    process.exit(1)
  }

  console.log(`📦 Total products in catalog: ${allProducts.length}`)

  const productsToSync: ProductSync[] = allProducts.map((p) => ({
    stockxProductId: p.stockx_product_id,
    sku: p.style_id,
    brand: p.brand || 'Unknown',
  }))

  console.log(`🔄 Products to sync: ${productsToSync.length}`)
  console.log(`⏱️  Delay between products: ${DELAY_BETWEEN_PRODUCTS / 1000}s`)
  console.log(`⏱️  Delay between regions: ${DELAY_BETWEEN_REGIONS / 1000}s`)
  console.log(`🔄 Max retries per product: ${MAX_RETRIES}`)
  console.log(`⏱️  Estimated time: ${Math.ceil((productsToSync.length * (DELAY_BETWEEN_PRODUCTS + 30000)) / 60000)} minutes\n`)
  console.log('═'.repeat(75) + '\n')

  const results: SyncResult[] = []
  let perfectCount = 0
  let qualityIssuesCount = 0
  let failureCount = 0

  // Sync ONE product at a time
  for (let i = 0; i < productsToSync.length; i++) {
    const product = productsToSync[i]
    const progress = `${i + 1}/${productsToSync.length}`

    console.log(`\n${'─'.repeat(75)}`)
    console.log(`🚀 Product ${progress}: ${product.sku}`)
    console.log('─'.repeat(75))

    const result = await syncSingleProduct(product)
    results.push(result)

    if (result.success && !result.dataQuality.hasDuplicates && result.dataQuality.pricesInCents) {
      perfectCount++
      console.log(`\n✅ Progress: ${perfectCount} perfect, ${qualityIssuesCount} quality issues, ${failureCount} failed`)
    } else if (result.dataQuality.totalRows > 0) {
      qualityIssuesCount++
      console.log(`\n⚠️ Progress: ${perfectCount} perfect, ${qualityIssuesCount} quality issues, ${failureCount} failed`)
    } else {
      failureCount++
      console.log(`\n❌ Progress: ${perfectCount} perfect, ${qualityIssuesCount} quality issues, ${failureCount} failed`)
    }

    // Checkpoint at 10, 25, 50, 75, 100 products
    if ([10, 25, 50, 75, 100].includes(i + 1)) {
      console.log('\n' + '═'.repeat(75))
      console.log(`📊 CHECKPOINT: ${i + 1} PRODUCTS SYNCED`)
      console.log('═'.repeat(75))

      const { data: checkpointData } = await supabase
        .from('master_market_data')
        .select('provider_product_id, size_key, region_code, lowest_ask')
        .eq('provider', 'stockx')

      const uniqueProducts = new Set(checkpointData?.map(r => r.provider_product_id))
      const totalRows = checkpointData?.length || 0

      console.log(`   Total rows: ${totalRows}`)
      console.log(`   Unique products: ${uniqueProducts.size}`)
      console.log(`   Success rate: ${((perfectCount / (i + 1)) * 100).toFixed(1)}%`)
      console.log('═'.repeat(75) + '\n')
    }

    // Delay before next product (except for last one)
    if (i < productsToSync.length - 1) {
      console.log(`\n⏳ Waiting ${DELAY_BETWEEN_PRODUCTS / 1000}s before next product...\n`)
      await sleep(DELAY_BETWEEN_PRODUCTS)
    }
  }

  const totalDuration = ((Date.now() - startTime) / 1000 / 60).toFixed(1)

  // ============================================================================
  // PHASE 3: FINAL VERIFICATION
  // ============================================================================

  console.log('\n' + '═'.repeat(75))
  console.log('PHASE 3: FINAL COMPREHENSIVE VERIFICATION\n')

  const { data: finalData } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')

  const uniqueProducts = new Set(finalData?.map(r => r.provider_product_id))
  const totalRows = finalData?.length || 0

  console.log(`📊 Database State:`)
  console.log(`   Total products: ${allProducts.length}`)
  console.log(`   Successfully synced: ${uniqueProducts.size}`)
  console.log(`   Coverage: ${((uniqueProducts.size / allProducts.length) * 100).toFixed(1)}%`)
  console.log(`   Total rows: ${totalRows}`)
  console.log(`   Expected rows: ~${uniqueProducts.size * 50} (assuming ~50 rows per product)`)

  // Check for duplicates across entire database
  const uniqueCombinations = new Set(
    finalData?.map(r => `${r.provider_product_id}|${r.region_code}|${r.size_key}|${r.is_flex}|${r.is_consigned}|${r.provider_source}`)
  )

  const hasDuplicates = uniqueCombinations.size !== totalRows

  console.log(`\n🔍 Data Quality Checks:`)
  console.log(`   Unique combinations: ${uniqueCombinations.size}`)
  console.log(`   Total rows: ${totalRows}`)
  console.log(`   Has duplicates: ${hasDuplicates ? '❌ YES (BUG!)' : '✅ NO'}`)

  // Check prices
  const pricesInCents = finalData?.filter(r => r.lowest_ask && r.lowest_ask >= 1000).length || 0
  const pricesInDollars = finalData?.filter(r => r.lowest_ask && r.lowest_ask < 1000 && r.lowest_ask > 0).length || 0

  console.log(`   Prices in cents (≥1000): ${pricesInCents} rows`)
  console.log(`   Prices in dollars (<1000): ${pricesInDollars} rows ${pricesInDollars > 0 ? '❌ (BUG!)' : '✅'}`)

  console.log(`\n📋 Sync Results:`)
  console.log(`   Perfect: ${perfectCount}`)
  console.log(`   Quality issues: ${qualityIssuesCount}`)
  console.log(`   Failed: ${failureCount}`)
  console.log(`   Duration: ${totalDuration} minutes`)
  console.log(`   Success rate: ${((perfectCount / productsToSync.length) * 100).toFixed(1)}%`)

  if (failureCount > 0) {
    console.log(`\n❌ Failed Products:`)
    results
      .filter((r) => !r.success)
      .forEach((r, i) => {
        console.log(`  ${i + 1}. ${r.sku} (${r.retries} retries)`)
        console.log(`     Rows: ${r.dataQuality.totalRows}, Regions: ${r.dataQuality.regionsComplete.join(',')}`)
      })
  }

  if (qualityIssuesCount > 0) {
    console.log(`\n⚠️ Products with Quality Issues:`)
    results
      .filter((r) => r.dataQuality.totalRows > 0 && (r.dataQuality.hasDuplicates || !r.dataQuality.pricesInCents))
      .forEach((r, i) => {
        console.log(`  ${i + 1}. ${r.sku}`)
        if (r.dataQuality.hasDuplicates) console.log(`     - Has duplicates`)
        if (!r.dataQuality.pricesInCents) console.log(`     - Prices in dollars`)
      })
  }

  console.log('\n' + '═'.repeat(75))

  if (perfectCount === productsToSync.length && !hasDuplicates && pricesInDollars === 0) {
    console.log('\n✅ 100% SUCCESS - PERFECT DATA QUALITY ACHIEVED!\n')
  } else {
    console.log(`\n⚠️ ${failureCount + qualityIssuesCount} products with issues\n`)
  }
}

main().catch(console.error)
