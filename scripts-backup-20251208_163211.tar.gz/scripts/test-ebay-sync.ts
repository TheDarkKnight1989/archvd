/**
 * Manual test script for eBay market data sync
 *
 * Usage:
 *   npx tsx scripts/test-ebay-sync.ts
 *
 * Prerequisites:
 *   1. Set EBAY_MARKET_DATA_ENABLED=true in .env.local
 *   2. Set EBAY_CLIENT_ID and EBAY_CLIENT_SECRET
 *   3. Optionally set EBAY_ENV=PRODUCTION (defaults to SANDBOX)
 */

import { syncEbayMarketDataForSku } from '@/lib/services/ebay/sync'
import { ebayConfig } from '@/lib/services/ebay/config'

async function main() {
  console.log('='.repeat(80))
  console.log('eBay Market Data Sync - Test Script')
  console.log('='.repeat(80))

  console.log('\nConfig:')
  console.log('  Environment:', ebayConfig.env)
  console.log('  Client ID:', ebayConfig.clientId ? `${ebayConfig.clientId.slice(0, 10)}...` : 'NOT SET')
  console.log('  Client Secret:', ebayConfig.clientSecret ? 'SET' : 'NOT SET')
  console.log('  Market Data Enabled:', ebayConfig.marketDataEnabled)

  if (!ebayConfig.marketDataEnabled) {
    console.error('\n❌ EBAY_MARKET_DATA_ENABLED is not true')
    console.error('   Please set EBAY_MARKET_DATA_ENABLED=true in .env.local')
    process.exit(1)
  }

  if (!ebayConfig.clientId || !ebayConfig.clientSecret) {
    console.error('\n❌ Missing eBay credentials')
    console.error('   Please set EBAY_CLIENT_ID and EBAY_CLIENT_SECRET in .env.local')
    process.exit(1)
  }

  // Test SKUs - replace with real product SKUs
  const testCases = [
    { sku: 'DD1391-100', currency: 'GBP', description: 'Jordan 4 Black Cat' },
    // Add more test cases as needed
  ]

  console.log('\n' + '='.repeat(80))
  console.log(`Testing ${testCases.length} SKU(s)`)
  console.log('='.repeat(80))

  for (const testCase of testCases) {
    console.log(`\n📦 Testing: ${testCase.description}`)
    console.log(`   SKU: ${testCase.sku}`)
    console.log(`   Currency: ${testCase.currency}`)

    try {
      const result = await syncEbayMarketDataForSku(testCase.sku, {
        currency: testCase.currency,
        limit: 50,
      })

      if (result.success) {
        console.log(`   ✅ Success! Found ${result.itemsCount} sold items`)
      } else {
        console.log(`   ❌ Failed: ${result.error}`)
      }
    } catch (error) {
      console.error(`   ❌ Error:`, error)
    }

    // Small delay between requests to be respectful to eBay API
    await new Promise((resolve) => setTimeout(resolve, 1000))
  }

  console.log('\n' + '='.repeat(80))
  console.log('Test completed!')
  console.log('='.repeat(80))
  console.log('\nNext steps:')
  console.log('1. Check master_market_data table for provider = "ebay"')
  console.log('2. Verify the data looks reasonable')
  console.log('3. If successful, proceed to Phase 2 (size parsing, raw snapshots, etc.)')
}

main().catch((error) => {
  console.error('Fatal error:', error)
  process.exit(1)
})
