#!/usr/bin/env npx tsx
/**
 * Test Gender-Based Size Filtering on Real Sync
 * Compare data quality before/after filtering
 */

import { createAliasClient } from '@/lib/services/alias/client';
import { syncAliasToMasterMarketData } from '@/lib/services/alias/sync';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function main() {
  console.log('🧪 Testing Gender-Based Size Filtering Impact\n');

  const testCatalogId = '2002r-protection-pack-phantom-m2002rdb';
  const testSku = 'M2002RDB';

  // ========================================================================
  // Step 1: Check product metadata
  // ========================================================================

  console.log('1️⃣  Checking product metadata...');
  const { data: productData } = await supabase
    .from('product_catalog')
    .select('gender, category, brand')
    .eq('alias_catalog_id', testCatalogId)
    .single();

  if (productData) {
    console.log(`   Product: ${productData.brand || 'Unknown'}`);
    console.log(`   Category: ${productData.category || 'NULL'}`);
    console.log(`   Gender: ${productData.gender || 'NULL (will use unisex fallback)'}`);
  } else {
    console.log('   ⚠️  Product not found in catalog');
  }

  // ========================================================================
  // Step 2: Clear previous data
  // ========================================================================

  console.log('\n2️⃣  Clearing previous test data...');
  const { error: deleteError } = await supabase
    .from('master_market_data')
    .delete()
    .eq('provider', 'alias')
    .eq('sku', testSku)
    .gte('snapshot_at', new Date(Date.now() - 60 * 60 * 1000).toISOString());

  if (deleteError) {
    console.warn(`   ⚠️  Delete warning: ${deleteError.message}`);
  } else {
    console.log('   ✅ Previous data cleared');
  }

  // ========================================================================
  // Step 3: Run sync with gender-based filtering
  // ========================================================================

  console.log('\n3️⃣  Running UK region sync (with gender filtering)...');
  const aliasClient = createAliasClient();

  const startTime = Date.now();
  const result = await syncAliasToMasterMarketData(aliasClient, testCatalogId, {
    sku: testSku,
    regionId: '3', // UK
  });
  const duration = Date.now() - startTime;

  console.log(`\n   Sync completed in ${duration}ms`);
  if (result.success) {
    console.log(`   ✅ SUCCESS`);
    console.log(`   Variants Ingested: ${result.variantsIngested}`);
  } else {
    console.log(`   ❌ FAILED: ${result.error}`);
    return;
  }

  // Wait for writes to complete
  await new Promise(resolve => setTimeout(resolve, 2000));

  // ========================================================================
  // Step 4: Analyze data quality
  // ========================================================================

  console.log('\n4️⃣  Analyzing data quality...\n');

  const { data: dbData, error: dbError } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'alias')
    .eq('sku', testSku)
    .eq('region_code', 'UK')
    .gte('snapshot_at', new Date(Date.now() - 60 * 1000).toISOString())
    .order('size_key');

  if (dbError) {
    console.error(`   ❌ Database query failed: ${dbError.message}`);
    return;
  }

  // Analyze by consigned flag
  const consigned = dbData.filter(r => r.is_consigned);
  const nonConsigned = dbData.filter(r => !r.is_consigned);

  // Get unique sizes
  const allSizes = Array.from(new Set(dbData.map(r => parseFloat(r.size_key))))
    .sort((a, b) => a - b);

  console.log('📊 Data Breakdown:');
  console.log(`   Total snapshots: ${dbData.length}`);
  console.log(`   Consigned: ${consigned.length}`);
  console.log(`   Non-consigned: ${nonConsigned.length}`);
  console.log(`   Unique sizes: ${allSizes.length}`);
  console.log(`   Size range: ${allSizes[0]} - ${allSizes[allSizes.length - 1]}`);

  // Check pricing data quality
  const withPricing = dbData.filter(r =>
    r.lowest_ask !== null || r.highest_bid !== null || r.last_sale_price !== null
  );
  const withoutPricing = dbData.length - withPricing.length;

  console.log(`\n💰 Pricing Data Quality:`);
  console.log(`   With pricing: ${withPricing.length}/${dbData.length} (${Math.round(withPricing.length / dbData.length * 100)}%)`);
  console.log(`   Without pricing: ${withoutPricing.length}/${dbData.length} (${Math.round(withoutPricing.length / dbData.length * 100)}%)`);

  // Show size distribution
  console.log(`\n📏 Size Distribution:`);
  allSizes.forEach(size => {
    const count = dbData.filter(r => parseFloat(r.size_key) === size).length;
    const withPrice = dbData.filter(r =>
      parseFloat(r.size_key) === size &&
      (r.lowest_ask || r.highest_bid || r.last_sale_price)
    ).length;
    const status = withPrice > 0 ? '✅' : '❌';
    console.log(`   ${status} Size ${size.toString().padEnd(4)}: ${count} records (${withPrice} with pricing)`);
  });

  // ========================================================================
  // Step 5: Compare with expected ranges
  // ========================================================================

  console.log('\n5️⃣  Filtering Analysis:\n');

  const expectedGender = productData?.gender || 'unisex';
  let expectedMin: number;
  let expectedMax: number;

  switch (expectedGender) {
    case 'men':
      expectedMin = 3.5;
      expectedMax = 16;
      break;
    case 'women':
      expectedMin = 5;
      expectedMax = 16;
      break;
    default:
      expectedMin = 3.5;
      expectedMax = 16;
  }

  const invalidSizes = allSizes.filter(s => s < expectedMin || s > expectedMax);
  const validSizes = allSizes.filter(s => s >= expectedMin && s <= expectedMax);

  console.log(`   Expected range for ${expectedGender}: ${expectedMin} - ${expectedMax}`);
  console.log(`   Valid sizes in range: ${validSizes.length}`);
  console.log(`   Invalid sizes filtered: ${invalidSizes.length}`);

  if (invalidSizes.length > 0) {
    console.log(`   ⚠️  Found invalid sizes: ${invalidSizes.join(', ')}`);
    console.log(`   (These should have been filtered out)`);
  } else {
    console.log(`   ✅ All sizes are within valid range!`);
  }

  // Final verdict
  console.log('\n' + '='.repeat(80));
  if (invalidSizes.length === 0 && withPricing.length > dbData.length * 0.7) {
    console.log('✅ EXCELLENT: Gender filtering working correctly!');
    console.log(`   - No invalid sizes stored`);
    console.log(`   - ${Math.round(withPricing.length / dbData.length * 100)}% of records have pricing data`);
  } else if (invalidSizes.length === 0) {
    console.log('✅ GOOD: Gender filtering working, but some sizes lack pricing');
    console.log(`   - No invalid sizes stored`);
    console.log(`   - ${withoutPricing.length} sizes without pricing (expected for rare sizes)`);
  } else {
    console.log('⚠️  NEEDS ATTENTION: Found invalid sizes that should be filtered');
  }
  console.log('='.repeat(80));
}

main().catch(console.error);
