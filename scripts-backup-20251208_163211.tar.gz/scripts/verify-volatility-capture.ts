/**
 * Verify we're capturing volatility and Flex fields
 */

import { StockxCatalogService } from '@/lib/services/stockx/catalog'

const SKU = 'U992AC1'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('Verifying Market Data Field Capture')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const catalogService = new StockxCatalogService(undefined)

  // Search for product
  const products = await catalogService.searchProducts(SKU, { limit: 5 })
  const product = products.find(p => p.styleId?.toUpperCase() === SKU.toUpperCase()) || products[0]

  console.log(`Product: ${product.productName}`)
  console.log(`Product ID: ${product.productId}\n`)

  // Fetch market data
  const client = (catalogService as any).client
  const rawMarketData = await client.request(
    `/v2/catalog/products/${product.productId}/market-data?currencyCode=GBP`
  )

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('CHECKING FIRST VARIANT')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const firstVariant = rawMarketData[0]

  console.log('📊 Standard Market Data Fields:')
  console.log(`   averagePrice: ${firstVariant.averagePrice ?? 'NULL'}`)
  console.log(`   volatility: ${firstVariant.volatility ?? 'NULL'}`)
  console.log(`   pricePremium: ${firstVariant.pricePremium ?? 'NULL'}`)
  console.log()

  console.log('🚀 Flex Market Data Fields:')
  if (firstVariant.flexMarketData) {
    console.log(`   lowestAsk: ${firstVariant.flexMarketData.lowestAsk ?? 'NULL'}`)
    console.log(`   highestBid: ${firstVariant.flexMarketData.highestBid ?? 'NULL'}`)
    console.log(`   sellFaster: ${firstVariant.flexMarketData.sellFaster ?? 'NULL'}`)
    console.log(`   earnMore: ${firstVariant.flexMarketData.earnMore ?? 'NULL'}`)
    console.log(`   beatUS: ${firstVariant.flexMarketData.beatUS ?? 'NULL'}`)
  } else {
    console.log('   ❌ No flexMarketData available')
  }
  console.log()

  console.log('📦 standardMarketData:')
  if (firstVariant.standardMarketData) {
    console.log(`   lowestAsk: ${firstVariant.standardMarketData.lowestAsk ?? 'NULL'}`)
    console.log(`   highestBid: ${firstVariant.standardMarketData.highestBid ?? 'NULL'}`)
    console.log(`   sellFaster: ${firstVariant.standardMarketData.sellFaster ?? 'NULL'}`)
    console.log(`   earnMore: ${firstVariant.standardMarketData.earnMore ?? 'NULL'}`)
  } else {
    console.log('   ❌ No standardMarketData available')
  }
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('WHAT WE STORE IN MASTER_MARKET_DATA')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  console.log('✅ Dedicated Columns (Always Available):')
  console.log(`   average_deadstock_price: ${firstVariant.averagePrice ?? 'NULL'}`)
  console.log(`   volatility: ${firstVariant.volatility ?? 'NULL'}`)
  console.log(`   price_premium: ${firstVariant.pricePremium ?? 'NULL'}`)
  console.log()

  console.log('✅ raw_response_excerpt (Flex Row):')
  if (firstVariant.flexMarketData) {
    const excerpt = {
      variantId: firstVariant.variantId,
      size: firstVariant.size || firstVariant.variantValue,
      flexMarketData: firstVariant.flexMarketData,
      salesLast72Hours: firstVariant.salesLast72Hours,
    }
    console.log(JSON.stringify(excerpt, null, 2))
  } else {
    console.log('   (No flex data for this variant)')
  }
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('CONCLUSION')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  console.log('We ARE capturing:')
  console.log('  ✅ volatility, pricePremium, averagePrice → dedicated columns')
  console.log('  ✅ sellFaster, earnMore, beatUS → raw_response_excerpt (for Flex rows)')
  console.log()
  console.log('This data IS available for:')
  console.log('  • Analytics and insights')
  console.log('  • Future feature development')
  console.log('  • Reprocessing if needed')
  console.log()
}

main().catch(console.error)
