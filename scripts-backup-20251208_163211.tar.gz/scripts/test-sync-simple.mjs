#!/usr/bin/env node
/**
 * Simple test - check which products can be synced
 */
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('📊 Checking products ready for sync...\n')

// Find products with Alias catalog IDs
const { data: withAlias, error } = await supabase
  .from('product_variants')
  .select(`
    alias_catalog_id,
    products!inner (
      sku,
      brand,
      model
    )
  `)
  .not('alias_catalog_id', 'is', null)

if (error) {
  console.log('Error:', error)
} else {
  console.log(`✅ Found ${withAlias.length} variants with Alias catalog IDs`)
  
  // Group by SKU
  const bySku = {}
  withAlias.forEach(v => {
    const sku = v.products.sku
    if (!bySku[sku]) {
      bySku[sku] = {
        sku,
        brand: v.products.brand,
        model: v.products.model,
        catalogId: v.alias_catalog_id,
        variantCount: 0
      }
    }
    bySku[sku].variantCount++
  })
  
  console.log('\n📋 Products ready to sync:')
  Object.values(bySku).forEach(p => {
    console.log(`  ${p.sku} - ${p.brand} ${p.model}`)
    console.log(`    Alias catalog ID: ${p.catalogId}`)
    console.log(`    Variants: ${p.variantCount}`)
  })
}

// Check total products
const { count: totalProducts } = await supabase
  .from('products')
  .select('*', { count: 'exact', head: true })

console.log(`\n📊 Summary:`)
console.log(`  Total products: ${totalProducts}`)
console.log(`  Products with Alias IDs: ${Object.keys(bySku || {}).length}`)
console.log(`  Products without Alias IDs: ${totalProducts - Object.keys(bySku || {}).length}`)
console.log('\n⚠️  Note: Only products with Alias catalog IDs can be synced currently')
console.log('   StockX sync is marked as TODO in the code')
