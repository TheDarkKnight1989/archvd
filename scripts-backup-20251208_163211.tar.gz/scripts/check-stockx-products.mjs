import { createClient } from '@supabase/supabase-js'
import 'dotenv/config'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

const stockxProductId = '15795a80-5cc8-4d2d-9ed0-20250d83be7f'

const { data, error } = await supabase
  .from('stockx_products')
  .select('*')
  .eq('stockx_product_id', stockxProductId)
  .single()

if (error) {
  console.error('❌ Error:', error)
} else {
  console.log('✅ Found stockx_products row:')
  console.log('Columns:', Object.keys(data))
  console.log('\nValues:')
  Object.entries(data).forEach(([key, value]) => {
    console.log(`  ${key}:`, value)
  })
}
