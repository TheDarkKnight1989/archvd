#!/usr/bin/env npx tsx
/**
 * Show actual data stored in master_market_data for M2002RDB
 */

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function showData() {
  console.log('🔍 ACTUAL DATABASE DATA FOR M2002RDB\n');
  console.log('='.repeat(80));

  // Query all M2002RDB data from the last hour
  const { data, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'alias')
    .eq('sku', 'M2002RDB')
    .gte('snapshot_at', new Date(Date.now() - 60 * 60 * 1000).toISOString())
    .order('region_code')
    .order('size_key')
    .order('is_consigned');

  if (error) {
    console.error('Query error:', error);
    return;
  }

  if (!data || data.length === 0) {
    console.log('❌ No data found in database!');
    console.log('Run the test sync first: npx tsx scripts/test-full-sync-with-filtering.ts');
    return;
  }

  console.log(`\n📦 Total Records: ${data.length}\n`);

  // Group by region
  const byRegion = data.reduce((acc, row) => {
    if (!acc[row.region_code]) acc[row.region_code] = [];
    acc[row.region_code].push(row);
    return acc;
  }, {} as Record<string, any[]>);

  // Show breakdown by region
  console.log('REGIONAL BREAKDOWN:\n');
  Object.entries(byRegion).forEach(([region, records]) => {
    const consigned = records.filter(r => r.is_consigned);
    const nonConsigned = records.filter(r => !r.is_consigned);
    console.log(`${region}:`);
    console.log(`  Total: ${records.length}`);
    console.log(`  Consigned: ${consigned.length} | Non-consigned: ${nonConsigned.length}`);
  });

  // Show size range
  console.log('\n' + '='.repeat(80));
  console.log('SIZE RANGE:\n');
  const allSizes = Array.from(new Set(data.map(r => parseFloat(r.size_key))))
    .sort((a, b) => a - b);
  console.log(`Min size: ${allSizes[0]}`);
  console.log(`Max size: ${allSizes[allSizes.length - 1]}`);
  console.log(`Unique sizes: ${allSizes.length}`);
  console.log(`All sizes: ${allSizes.join(', ')}`);

  // Show pricing coverage
  console.log('\n' + '='.repeat(80));
  console.log('PRICING COVERAGE:\n');
  const withLowestAsk = data.filter(r => r.lowest_ask !== null).length;
  const withHighestBid = data.filter(r => r.highest_bid !== null).length;
  const withLastSale = data.filter(r => r.last_sale_price !== null).length;
  const withAnyPrice = data.filter(r => 
    r.lowest_ask !== null || r.highest_bid !== null || r.last_sale_price !== null
  ).length;

  console.log(`Records with ANY price:    ${withAnyPrice}/${data.length} (${Math.round(withAnyPrice/data.length*100)}%)`);
  console.log(`Records with lowest_ask:   ${withLowestAsk}/${data.length} (${Math.round(withLowestAsk/data.length*100)}%)`);
  console.log(`Records with highest_bid:  ${withHighestBid}/${data.length} (${Math.round(withHighestBid/data.length*100)}%)`);
  console.log(`Records with last_sale:    ${withLastSale}/${data.length} (${Math.round(withLastSale/data.length*100)}%)`);

  // Show sample records
  console.log('\n' + '='.repeat(80));
  console.log('SAMPLE RECORDS (first 10):\n');
  data.slice(0, 10).forEach(row => {
    console.log(`${row.region_code} | Size ${row.size_key.toString().padEnd(4)} | Consigned: ${row.is_consigned ? 'Y' : 'N'} | Ask: ${row.lowest_ask ? `$${row.lowest_ask}` : 'NULL'} | Bid: ${row.highest_bid ? `$${row.highest_bid}` : 'NULL'} | Last: ${row.last_sale_price ? `$${row.last_sale_price}` : 'NULL'}`);
  });

  // Show full data for one size across all regions
  console.log('\n' + '='.repeat(80));
  console.log('EXAMPLE: Size 10 across all regions/types:\n');
  const size10 = data.filter(r => r.size_key === '10');
  size10.forEach(row => {
    console.log(`${row.region_code} | Consigned: ${row.is_consigned ? 'Y' : 'N'} | Ask: ${row.lowest_ask ? `$${row.lowest_ask}` : 'NULL'} | Bid: ${row.highest_bid ? `$${row.highest_bid}` : 'NULL'} | Last: ${row.last_sale_price ? `$${row.last_sale_price}` : 'NULL'} | Vol30d: ${row.volume_30d || 'NULL'}`);
  });

  // Verify NO invalid sizes
  console.log('\n' + '='.repeat(80));
  console.log('VALIDATION CHECK:\n');
  const invalidSizes = allSizes.filter(s => s < 3.5 || s > 16);
  if (invalidSizes.length > 0) {
    console.log(`❌ Found ${invalidSizes.length} INVALID sizes: ${invalidSizes.join(', ')}`);
  } else {
    console.log('✅ All sizes within valid range (3.5-16)');
  }

  // Check for NULL pricing records
  const nullRecords = data.filter(r => 
    r.lowest_ask === null && r.highest_bid === null && r.last_sale_price === null
  );
  if (nullRecords.length > 0) {
    console.log(`⚠️  Found ${nullRecords.length} records with NO pricing data`);
    console.log('Sizes without pricing:', Array.from(new Set(nullRecords.map(r => r.size_key))).join(', '));
  } else {
    console.log('✅ All records have pricing data');
  }

  console.log('\n' + '='.repeat(80));
}

showData();
