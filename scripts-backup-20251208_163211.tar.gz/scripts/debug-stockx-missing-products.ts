#!/usr/bin/env npx tsx
/**
 * Debug StockX Missing Products
 * Check why products are failing with "Product not found in stockx_products table"
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🔍 Debugging StockX Missing Products\n')

  // Get all product_variants with stockx_product_id
  const { data: products, error: productsError } = await supabase
    .from('product_variants')
    .select(`
      id,
      stockx_product_id,
      product:products (
        sku,
        model
      )
    `)
    .not('stockx_product_id', 'is', null)

  if (productsError || !products) {
    console.error('❌ Failed to fetch products:', productsError?.message)
    return
  }

  console.log(`Found ${products.length} products with StockX IDs\n`)

  // Check which ones exist in stockx_products table
  const { data: stockxProducts, error: stockxError } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, title')

  if (stockxError || !stockxProducts) {
    console.error('❌ Failed to fetch stockx_products:', stockxError?.message)
    return
  }

  console.log(`Found ${stockxProducts.length} entries in stockx_products table\n`)

  // Create a set of stockx_product_ids in the table
  const stockxProductIds = new Set(stockxProducts.map(p => p.stockx_product_id))

  // Check which products are missing
  let missingCount = 0
  let foundCount = 0

  for (const variant of products) {
    const exists = stockxProductIds.has(variant.stockx_product_id!)
    const product = variant.product as any

    if (!exists) {
      console.log(`❌ MISSING: ${product?.sku} - StockX ID: ${variant.stockx_product_id}`)
      missingCount++
    } else {
      foundCount++
    }
  }

  console.log(`\n📊 Summary:`)
  console.log(`  ✅ Found in stockx_products: ${foundCount}`)
  console.log(`  ❌ Missing from stockx_products: ${missingCount}`)
  console.log(`  📦 Total products with StockX IDs: ${products.length}`)

  if (missingCount > 0) {
    console.log(`\n⚠️  ${missingCount} products are mapped but missing from stockx_products table!`)
    console.log(`   This is why sync is failing with "Product not found in stockx_products table"`)
  } else {
    console.log(`\n✅ All products with StockX IDs exist in stockx_products table`)
    console.log(`   The issue must be somewhere else in the sync logic`)
  }
}

main().catch(console.error)
