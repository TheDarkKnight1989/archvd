/**
 * COMPLETE ALIAS PIPELINE TEST FOR FV5029-010
 * Tests entire flow: Search → Catalog → Availabilities → Recent Sales → Mapper → Database
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { syncAliasToMasterMarketData } from '@/lib/services/alias/sync'
import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('COMPLETE ALIAS PIPELINE TEST')
  console.log('SKU:', SKU)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()

  // ============================================================================
  // STEP 1: Search Catalog
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 1: Search Catalog')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log('📤 REQUEST: GET /v1/catalog?query=' + SKU)
  console.log()

  const searchResults = await client.searchCatalog(SKU, { limit: 5 })

  console.log('📥 RESPONSE:')
  console.log(JSON.stringify(searchResults, null, 2))
  console.log()

  if (searchResults.catalog_items.length === 0) {
    console.log('❌ FAILED: No products found')
    return
  }

  // Normalize SKU for matching
  const normalizeSku = (sku: string) => sku.replace(/[\s-]/g, '').toUpperCase()
  const targetNormalized = normalizeSku(SKU)

  const product = searchResults.catalog_items.find(p =>
    normalizeSku(p.sku) === targetNormalized
  ) || searchResults.catalog_items[0]

  console.log('✅ MATCHED PRODUCT:')
  console.log(`   Name: ${product.name}`)
  console.log(`   Catalog ID: ${product.catalog_id}`)
  console.log(`   SKU (Alias): ${product.sku}`)
  console.log(`   SKU (Input): ${SKU}`)
  console.log(`   Brand: ${product.brand}`)
  console.log(`   Retail: $${product.retail_price_cents ? parseInt(product.retail_price_cents) / 100 : 'N/A'}`)
  console.log()

  // ============================================================================
  // STEP 2: Get Catalog Details
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 2: Get Catalog Item Details')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log(`📤 REQUEST: GET /v1/catalog/${product.catalog_id}`)
  console.log()

  const catalogDetails = await client.getCatalogItem(product.catalog_id)

  console.log('📥 RESPONSE:')
  console.log(JSON.stringify(catalogDetails, null, 2))
  console.log()

  console.log('✅ SIZES AVAILABLE:', catalogDetails.catalog_item.allowed_sizes.length)
  console.log()

  // ============================================================================
  // STEP 3: List Pricing Insights (All Sizes/Variants)
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 3: List Pricing Insights (All Variants)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log(`📤 REQUEST: GET /v1/pricing_insights/availabilities/${product.catalog_id}`)
  console.log()

  const availabilities = await client.listPricingInsights(product.catalog_id)

  console.log('📥 RESPONSE (FULL):')
  console.log(JSON.stringify(availabilities, null, 2))
  console.log()

  console.log('✅ VARIANTS FOUND:', availabilities.variants.length)
  console.log()

  // Show first 3 variants in detail
  console.log('SAMPLE VARIANTS (first 3):')
  for (let i = 0; i < Math.min(3, availabilities.variants.length); i++) {
    const v = availabilities.variants[i]
    console.log(`\n   Variant ${i + 1}:`)
    console.log(`   ├─ Size: ${v.size} ${v.size_unit || 'US'}`)
    console.log(`   ├─ Condition: ${v.product_condition}`)
    console.log(`   ├─ Packaging: ${v.packaging_condition}`)
    console.log(`   ├─ Consigned: ${v.consigned ?? 'not specified'}`)
    if (v.availability) {
      console.log(`   ├─ Lowest Ask: ${v.availability.lowest_listing_price_cents ? `$${parseInt(v.availability.lowest_listing_price_cents) / 100}` : 'N/A'}`)
      console.log(`   ├─ Highest Bid: ${v.availability.highest_offer_price_cents ? `$${parseInt(v.availability.highest_offer_price_cents) / 100}` : 'N/A'}`)
      console.log(`   ├─ Last Sale: ${v.availability.last_sold_listing_price_cents ? `$${parseInt(v.availability.last_sold_listing_price_cents) / 100}` : 'N/A'}`)
      console.log(`   └─ Global Indicator: ${v.availability.global_indicator_price_cents ? `$${parseInt(v.availability.global_indicator_price_cents) / 100}` : 'N/A'}`)
    } else {
      console.log(`   └─ Availability: NULL`)
    }
  }
  console.log()

  // ============================================================================
  // STEP 4: Recent Sales
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 4: Recent Sales')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log(`📤 REQUEST: GET /v1/pricing_insights/recent_sales?catalog_id=${product.catalog_id}&limit=20`)
  console.log()

  try {
    const recentSales = await client.getRecentSales({
      catalog_id: product.catalog_id,
      limit: 20
    })

    console.log('📥 RESPONSE (FULL):')
    console.log(JSON.stringify(recentSales, null, 2))
    console.log()

    console.log(`✅ SALES FOUND: ${recentSales.recent_sales.length}`)

    if (recentSales.recent_sales.length > 0) {
      console.log()
      console.log('SAMPLE SALES (first 5):')
      for (let i = 0; i < Math.min(5, recentSales.recent_sales.length); i++) {
        const sale = recentSales.recent_sales[i]
        console.log(`   ${i + 1}. ${sale.purchased_at} - Size ${sale.size} - $${parseInt(sale.price_cents) / 100} ${sale.consigned ? '(Consigned)' : '(Standard)'}`)
      }
    }
    console.log()
  } catch (error: any) {
    console.log('❌ RECENT SALES FAILED:')
    console.log(`   Error: ${error.message}`)
    console.log(`   Status: ${error.statusCode || 'unknown'}`)
    console.log()
  }

  // ============================================================================
  // STEP 5: Offer Histogram (Size 10 example)
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 5: Offer Histogram (Size 10)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log('📤 REQUEST: GET /v1/pricing_insights/offer_histogram')
  console.log('   catalog_id:', product.catalog_id)
  console.log('   size: 10')
  console.log('   product_condition: PRODUCT_CONDITION_NEW')
  console.log('   packaging_condition: PACKAGING_CONDITION_GOOD_CONDITION')
  console.log()

  try {
    const offerHistogram = await client.getOfferHistogram({
      catalog_id: product.catalog_id,
      size: 10,
      product_condition: 'PRODUCT_CONDITION_NEW',
      packaging_condition: 'PACKAGING_CONDITION_GOOD_CONDITION'
    })

    console.log('📥 RESPONSE:')
    console.log(JSON.stringify(offerHistogram, null, 2))
    console.log()

    if (offerHistogram.bins && offerHistogram.bins.length > 0) {
      console.log(`✅ OFFER BINS: ${offerHistogram.bins.length}`)
      console.log('   Price distribution:')
      offerHistogram.bins.slice(0, 5).forEach(bin => {
        console.log(`   $${parseInt(bin.price_cents) / 100}: ${bin.count} offers`)
      })
      if (offerHistogram.bins.length > 5) {
        console.log(`   ... and ${offerHistogram.bins.length - 5} more bins`)
      }
    } else {
      console.log('⚠️  No offer histogram data')
    }
    console.log()
  } catch (error: any) {
    console.log('❌ OFFER HISTOGRAM FAILED:')
    console.log(`   Error: ${error.message}`)
    console.log()
  }

  // ============================================================================
  // STEP 6: Listing Histogram (Size 10 example)
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 6: Listing Histogram (Size 10)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log('📤 REQUEST: GET /v1/pricing_insights/listing_histogram')
  console.log('   catalog_id:', product.catalog_id)
  console.log('   size: 10')
  console.log('   product_condition: PRODUCT_CONDITION_NEW')
  console.log('   packaging_condition: PACKAGING_CONDITION_GOOD_CONDITION')
  console.log()

  try {
    const listingHistogram = await client.getListingHistogram({
      catalog_id: product.catalog_id,
      size: 10,
      product_condition: 'PRODUCT_CONDITION_NEW',
      packaging_condition: 'PACKAGING_CONDITION_GOOD_CONDITION'
    })

    console.log('📥 RESPONSE:')
    console.log(JSON.stringify(listingHistogram, null, 2))
    console.log()

    if (listingHistogram.bins && listingHistogram.bins.length > 0) {
      console.log(`✅ LISTING BINS: ${listingHistogram.bins.length}`)
      console.log('   Price distribution:')
      listingHistogram.bins.slice(0, 5).forEach(bin => {
        console.log(`   $${parseInt(bin.price_cents) / 100}: ${bin.count} listings`)
      })
      if (listingHistogram.bins.length > 5) {
        console.log(`   ... and ${listingHistogram.bins.length - 5} more bins`)
      }
    } else {
      console.log('⚠️  No listing histogram data')
    }
    console.log()
  } catch (error: any) {
    console.log('❌ LISTING HISTOGRAM FAILED:')
    console.log(`   Error: ${error.message}`)
    console.log()
  }

  // ============================================================================
  // STEP 7: Run Master Market Data Sync
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 7: Sync to master_market_data')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log('🔄 Running syncAliasToMasterMarketData()...')
  console.log()

  const syncResult = await syncAliasToMasterMarketData(client, product.catalog_id, {
    sku: SKU,
  })

  console.log('SYNC RESULT:')
  console.log(JSON.stringify(syncResult, null, 2))
  console.log()

  if (!syncResult.success) {
    console.log('❌ SYNC FAILED:', syncResult.error)
    return
  }

  console.log('✅ SYNC SUCCESSFUL!')
  console.log(`   Variants ingested: ${syncResult.variantsIngested}`)
  console.log(`   Volume metrics updated: ${syncResult.volumeMetricsUpdated}`)
  console.log()

  // ============================================================================
  // STEP 8: Query master_market_data to verify
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 8: Verify Data in master_market_data')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const { data: marketData, error: queryError } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'alias')
    .eq('sku', SKU)
    .order('size_numeric', { ascending: true })

  if (queryError) {
    console.log('❌ QUERY FAILED:', queryError)
    return
  }

  console.log(`📊 FOUND ${marketData?.length || 0} ROWS IN master_market_data`)
  console.log()

  if (marketData && marketData.length > 0) {
    console.log('SAMPLE ROWS (first 5):')
    for (let i = 0; i < Math.min(5, marketData.length); i++) {
      const row = marketData[i]
      console.log(`\n   Row ${i + 1}:`)
      console.log(`   ├─ Provider: ${row.provider}`)
      console.log(`   ├─ Provider Source: ${row.provider_source}`)
      console.log(`   ├─ SKU: ${row.sku}`)
      console.log(`   ├─ Size: ${row.size_key} (numeric: ${row.size_numeric})`)
      console.log(`   ├─ Lowest Ask: ${row.lowest_ask !== null ? `$${row.lowest_ask}` : 'NULL'}`)
      console.log(`   ├─ Highest Bid: ${row.highest_bid !== null ? `$${row.highest_bid}` : 'NULL'}`)
      console.log(`   ├─ Last Sale: ${row.last_sale_price !== null ? `$${row.last_sale_price}` : 'NULL'}`)
      console.log(`   ├─ Global Indicator: ${row.global_indicator_price !== null ? `$${row.global_indicator_price}` : 'NULL'}`)
      console.log(`   ├─ Sales (72h/30d): ${row.sales_last_72h || 0}/${row.sales_last_30d || 0}`)
      console.log(`   └─ Created: ${new Date(row.created_at).toLocaleString()}`)
    }
    console.log()

    // Summary by source
    const bySources = marketData.reduce((acc, row) => {
      acc[row.provider_source] = (acc[row.provider_source] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    console.log('BREAKDOWN BY PROVIDER SOURCE:')
    for (const [source, count] of Object.entries(bySources)) {
      console.log(`   ${source}: ${count} rows`)
    }
    console.log()
  }

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('PIPELINE TEST COMPLETE!')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch((error) => {
  console.error('\n❌ FATAL ERROR:')
  console.error(error)
  process.exit(1)
})
