#!/usr/bin/env node
/**
 * Show RAW StockX API Response
 *
 * Directly calls StockX market-data API and displays the complete raw JSON response
 * WITHOUT any processing, database operations, or transformations
 */

import { createClient } from '@supabase/supabase-js';

const SKU = 'FV5029-010'; // Jordan 4 Black Cat
const CURRENCY = 'GBP';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function showRawResponse() {
  console.log('================================================================================');
  console.log('RAW STOCKX API RESPONSE');
  console.log('================================================================================');
  console.log('SKU:', SKU);
  console.log('Currency:', CURRENCY);
  console.log('================================================================================\n');

  // ========================================================================
  // Step 1: Look up StockX Product ID
  // ========================================================================

  const { data: product, error: productError } = await supabase
    .from('product_catalog')
    .select('id, sku, stockx_product_id')
    .eq('sku', SKU)
    .single();

  if (productError || !product) {
    console.error('❌ Product not found in catalog:', SKU);
    console.error('   Error:', productError?.message);
    process.exit(1);
  }

  if (!product.stockx_product_id) {
    console.error('❌ No stockx_product_id for SKU:', SKU);
    process.exit(1);
  }

  console.log('✅ Found Product:');
  console.log('   Catalog ID:', product.id);
  console.log('   SKU:', product.sku);
  console.log('   StockX Product ID:', product.stockx_product_id);
  console.log('\n' + '='.repeat(80) + '\n');

  // ========================================================================
  // Step 2: Call StockX API Directly
  // ========================================================================

  console.log('🔄 Calling StockX API...');
  console.log('   Endpoint: /v2/catalog/products/{productId}/market-data');
  console.log('   Currency:', CURRENCY);
  console.log('\n' + '='.repeat(80) + '\n');

  // Import StockX catalog service
  const { StockxCatalogService } = await import('../src/lib/services/stockx/catalog.ts');

  const catalogService = new StockxCatalogService(undefined); // Use client credentials
  const client = catalogService.client;

  let rawResponse;
  try {
    // Make the direct API call - same as market-refresh.ts line 264-266
    rawResponse = await client.request(
      `/v2/catalog/products/${product.stockx_product_id}/market-data?currencyCode=${CURRENCY}`
    );
  } catch (error) {
    console.error('❌ StockX API Error:', error.message);
    console.error('\nFull error:', error);
    process.exit(1);
  }

  // ========================================================================
  // Step 3: Display Complete Raw Response
  // ========================================================================

  console.log('✅ RAW API RESPONSE RECEIVED\n');
  console.log('Response type:', Array.isArray(rawResponse) ? 'Array' : 'Object');
  console.log('Number of variants:', Array.isArray(rawResponse) ? rawResponse.length : rawResponse?.variants?.length || 0);
  console.log('\n' + '='.repeat(80));
  console.log('COMPLETE RAW JSON:');
  console.log('='.repeat(80) + '\n');

  // Display the ENTIRE raw response with pretty formatting
  console.log(JSON.stringify(rawResponse, null, 2));

  console.log('\n' + '='.repeat(80));
  console.log('END OF RAW RESPONSE');
  console.log('='.repeat(80) + '\n');

  // ========================================================================
  // Step 4: Show Sample Variant (if exists)
  // ========================================================================

  const variants = Array.isArray(rawResponse) ? rawResponse : rawResponse?.variants || [];

  if (variants.length > 0) {
    console.log('\n📊 Sample Variant (First One):');
    console.log('='.repeat(80) + '\n');
    console.log(JSON.stringify(variants[0], null, 2));
    console.log('\n' + '='.repeat(80));
  }

  console.log('\n✅ Done! This is the exact data StockX is sending us.');
}

showRawResponse().catch(err => {
  console.error('\n❌ FATAL ERROR:', err.message);
  console.error(err.stack);
  process.exit(1);
});
