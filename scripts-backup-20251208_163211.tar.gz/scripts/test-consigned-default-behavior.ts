/**
 * Test what the API returns when consigned parameter is NOT provided
 * According to docs: "will include both consigned and unconsigned items"
 */

import { createAliasClient } from '@/lib/services/alias/client'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('TESTING DEFAULT BEHAVIOR (no consigned parameter)')
  console.log('SKU:', SKU)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()

  // Search for product
  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const product = searchResults.catalog_items[0]

  console.log(`Product: ${product.name}`)
  console.log(`Catalog ID: ${product.catalog_id}\n`)

  // Fetch WITHOUT consigned parameter (should include both per docs)
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('FETCH: listPricingInsights(catalogId) - NO CONSIGNED PARAMETER')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const allData = await client.listPricingInsights(product.catalog_id)

  console.log(`Total variants returned: ${allData.variants.length}\n`)

  // Count by consigned flag
  const byConsignedFlag = {
    true: allData.variants.filter(v => v.consigned === true),
    false: allData.variants.filter(v => v.consigned === false),
    undefined: allData.variants.filter(v => v.consigned === undefined),
  }

  console.log('BREAKDOWN BY CONSIGNED FLAG:')
  console.log(`  consigned = true:      ${byConsignedFlag.true.length}`)
  console.log(`  consigned = false:     ${byConsignedFlag.false.length}`)
  console.log(`  consigned = undefined: ${byConsignedFlag.undefined.length}\n`)

  // Show first few of each type
  if (byConsignedFlag.true.length > 0) {
    console.log('✅ FOUND CONSIGNED VARIANTS (consigned=true):')
    for (const v of byConsignedFlag.true.slice(0, 5)) {
      console.log(`  Size ${v.size}: ${v.product_condition} / ${v.packaging_condition}`)
      if (v.availability?.lowest_listing_price_cents) {
        console.log(`    Ask: $${parseInt(v.availability.lowest_listing_price_cents) / 100}`)
      }
    }
    console.log()
  }

  if (byConsignedFlag.false.length > 0) {
    console.log('✅ FOUND NON-CONSIGNED VARIANTS (consigned=false):')
    for (const v of byConsignedFlag.false.slice(0, 5)) {
      console.log(`  Size ${v.size}: ${v.product_condition} / ${v.packaging_condition}`)
      if (v.availability?.lowest_listing_price_cents) {
        console.log(`    Ask: $${parseInt(v.availability.lowest_listing_price_cents) / 100}`)
      }
    }
    console.log()
  }

  if (byConsignedFlag.undefined.length > 0) {
    console.log('⚠️  FOUND VARIANTS WITH UNDEFINED CONSIGNED FLAG:')
    for (const v of byConsignedFlag.undefined.slice(0, 5)) {
      console.log(`  Size ${v.size}: ${v.product_condition} / ${v.packaging_condition}`)
      if (v.availability?.lowest_listing_price_cents) {
        console.log(`    Ask: $${parseInt(v.availability.lowest_listing_price_cents) / 100}`)
      }
    }
    console.log()
  }

  // Filter to NEW + GOOD_CONDITION only
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('FILTERED TO: NEW + GOOD_CONDITION')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const standardVariants = allData.variants.filter(v =>
    v.product_condition === 'PRODUCT_CONDITION_NEW' &&
    v.packaging_condition === 'PACKAGING_CONDITION_GOOD_CONDITION'
  )

  console.log(`Total after filter: ${standardVariants.length}\n`)

  const standardByConsigned = {
    true: standardVariants.filter(v => v.consigned === true),
    false: standardVariants.filter(v => v.consigned === false),
    undefined: standardVariants.filter(v => v.consigned === undefined),
  }

  console.log('BREAKDOWN BY CONSIGNED FLAG:')
  console.log(`  consigned = true:      ${standardByConsigned.true.length}`)
  console.log(`  consigned = false:     ${standardByConsigned.false.length}`)
  console.log(`  consigned = undefined: ${standardByConsigned.undefined.length}\n`)

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('CONCLUSION:')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  if (byConsignedFlag.true.length > 0 && byConsignedFlag.false.length > 0) {
    console.log('✅ API RETURNS BOTH consigned=true AND consigned=false in default call')
    console.log('   → We can use ONE call and filter by the consigned flag in code')
    console.log()
  } else if (byConsignedFlag.true.length > 0) {
    console.log('⚠️  API ONLY RETURNS consigned=true variants')
    console.log('   → This contradicts the docs')
    console.log()
  } else if (byConsignedFlag.false.length > 0) {
    console.log('⚠️  API ONLY RETURNS consigned=false variants')
    console.log('   → Need to explicitly request consigned=true for consigned pricing')
    console.log()
  } else {
    console.log('⚠️  ALL VARIANTS HAVE consigned=undefined')
    console.log('   → Cannot distinguish consigned from non-consigned without explicit parameter')
    console.log()
  }
}

main().catch(console.error)
