#!/usr/bin/env npx tsx
/**
 * Verify that the deduplication fix is working
 * Check if we still have 6x duplicates or if it's fixed
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function verify() {
  console.log('🔍 Checking for duplicates after deduplication fix...\n')

  // Get all StockX data
  const { data: allData } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')

  const totalRows = allData?.length || 0
  console.log(`Total StockX rows: ${totalRows}`)

  // Count unique products
  const uniqueProducts = new Set(allData?.map(r => r.provider_product_id))
  console.log(`Unique products: ${uniqueProducts.size}`)

  // Count unique combinations (should match totalRows if no duplicates)
  const uniqueCombinations = new Set(
    allData?.map(r => `${r.provider_product_id}|${r.region_code}|${r.size_key}|${r.is_flex}|${r.is_consigned}|${r.provider_source}`)
  )

  console.log(`Unique combinations: ${uniqueCombinations.size}`)
  console.log(`Has duplicates: ${uniqueCombinations.size !== totalRows ? '❌ YES' : '✅ NO'}`)

  if (uniqueCombinations.size !== totalRows) {
    const duplicateCount = totalRows - uniqueCombinations.size
    console.log(`\n❌ DUPLICATES FOUND: ${duplicateCount} duplicate rows\n`)

    // Sample one product to show the duplication
    const sampleProductId = Array.from(uniqueProducts)[0]
    const { data: sampleData } = await supabase
      .from('master_market_data')
      .select('id, size_key, region_code, currency_code, lowest_ask, is_flex, is_consigned, provider_source, created_at')
      .eq('provider', 'stockx')
      .eq('provider_product_id', sampleProductId)
      .eq('size_key', '10')
      .limit(100)

    console.log(`Sample: Size 10 for product ${sampleProductId}:`)

    // Group by unique combination
    const grouped = new Map<string, any[]>()
    sampleData?.forEach(row => {
      const key = `${row.region_code}-${row.is_flex}-${row.is_consigned}-${row.provider_source}`
      if (!grouped.has(key)) {
        grouped.set(key, [])
      }
      grouped.get(key)!.push(row)
    })

    grouped.forEach((rows, key) => {
      console.log(`  ${key}: ${rows.length} rows`)
      if (rows.length > 1) {
        console.log(`    Prices: ${rows.map(r => r.lowest_ask).join(', ')}`)
        console.log(`    Created: ${rows.map(r => new Date(r.created_at).toISOString().substring(11, 19)).join(', ')}`)
      }
    })

    console.log(`\n⚠️  Duplication bug still exists - need to run comprehensive cleanup\n`)
  } else {
    console.log(`\n✅ NO DUPLICATES - Deduplication fix is working!\n`)

    // Verify prices are in cents
    const pricesInCents = allData?.filter(r => r.lowest_ask && r.lowest_ask >= 1000).length || 0
    const pricesInDollars = allData?.filter(r => r.lowest_ask && r.lowest_ask < 1000 && r.lowest_ask > 0).length || 0

    console.log(`Prices in cents (≥1000): ${pricesInCents} rows`)
    console.log(`Prices in dollars (<1000): ${pricesInDollars} rows ${pricesInDollars > 0 ? '❌' : '✅'}`)

    // Check region coverage
    const productRegions = new Map<string, Set<string>>()
    allData?.forEach(row => {
      if (!productRegions.has(row.provider_product_id)) {
        productRegions.set(row.provider_product_id, new Set())
      }
      productRegions.get(row.provider_product_id)!.add(row.region_code)
    })

    let fullCoverage = 0
    let partialCoverage = 0
    productRegions.forEach((regions) => {
      if (regions.size === 3) {
        fullCoverage++
      } else {
        partialCoverage++
      }
    })

    console.log(`\nRegion Coverage:`)
    console.log(`  Full (3 regions): ${fullCoverage} products`)
    console.log(`  Partial: ${partialCoverage} products`)

    if (pricesInDollars === 0 && partialCoverage === 0) {
      console.log(`\n✅ PERFECT DATA QUALITY - Everything looks good!\n`)
    }
  }
}

verify()
