/**
 * Show side-by-side comparison of consigned vs non-consigned pricing
 */

import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS DUAL PRICING COMPARISON')
  console.log('SKU:', SKU)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  // Fetch both types
  const { data: rows, error } = await supabase
    .from('master_market_data')
    .select('provider_source, size_key, size_numeric, lowest_ask, highest_bid, last_sale_price')
    .eq('sku', SKU)
    .eq('provider', 'alias')
    .order('size_numeric')
    .order('provider_source')

  if (error || !rows) {
    console.error('Error fetching data:', error)
    return
  }

  // Group by size
  const sizeMap = new Map<string, {
    nonConsigned?: typeof rows[0]
    consigned?: typeof rows[0]
  }>()

  for (const row of rows) {
    if (!sizeMap.has(row.size_key)) {
      sizeMap.set(row.size_key, {})
    }
    const entry = sizeMap.get(row.size_key)!
    if (row.provider_source === 'alias_availabilities') {
      entry.nonConsigned = row
    } else if (row.provider_source === 'alias_availabilities_consigned') {
      entry.consigned = row
    }
  }

  console.log('SIDE-BY-SIDE PRICING COMPARISON:\n')
  console.log('Size | Non-Consigned (Standard)      | Consigned                     ')
  console.log('     | Ask    Bid     Last           | Ask    Bid     Last           ')
  console.log('─────┼────────────────────────────────┼────────────────────────────────')

  for (const [sizeKey, data] of Array.from(sizeMap.entries()).slice(0, 15)) {
    const nc = data.nonConsigned
    const c = data.consigned

    const ncAsk = nc?.lowest_ask ? `$${nc.lowest_ask}`.padEnd(6) : '   -  '
    const ncBid = nc?.highest_bid ? `$${nc.highest_bid}`.padEnd(6) : '   -  '
    const ncLast = nc?.last_sale_price ? `$${nc.last_sale_price}`.padEnd(6) : '   -  '

    const cAsk = c?.lowest_ask ? `$${c.lowest_ask}`.padEnd(6) : '   -  '
    const cBid = c?.highest_bid ? `$${c.highest_bid}`.padEnd(6) : '   -  '
    const cLast = c?.last_sale_price ? `$${c.last_sale_price}`.padEnd(6) : '   -  '

    console.log(`${sizeKey.padEnd(4)} │ ${ncAsk} ${ncBid} ${ncLast} │ ${cAsk} ${cBid} ${cLast}`)
  }

  console.log()

  // Show totals
  const nonConsignedCount = rows.filter(r => r.provider_source === 'alias_availabilities').length
  const consignedCount = rows.filter(r => r.provider_source === 'alias_availabilities_consigned').length

  console.log('SUMMARY:')
  console.log(`  Non-Consigned rows: ${nonConsignedCount}`)
  console.log(`  Consigned rows: ${consignedCount}`)
  console.log(`  Total rows: ${rows.length}`)
  console.log()

  // Show pricing differences
  const sizesWithBothPricing = Array.from(sizeMap.values()).filter(
    d => d.nonConsigned && d.consigned &&
    (d.nonConsigned.lowest_ask || 0) > 0 &&
    (d.consigned.lowest_ask || 0) > 0
  )

  if (sizesWithBothPricing.length > 0) {
    console.log('PRICING DIFFERENCES (sizes with asks in both):')
    for (const data of sizesWithBothPricing.slice(0, 5)) {
      const nc = data.nonConsigned!
      const c = data.consigned!
      const diff = (nc.lowest_ask || 0) - (c.lowest_ask || 0)
      const pct = ((diff / (nc.lowest_ask || 1)) * 100).toFixed(1)
      console.log(`  Size ${nc.size_key}: Non-Consigned $${nc.lowest_ask} vs Consigned $${c.lowest_ask} (diff: $${diff.toFixed(2)} / ${pct}%)`)
    }
  } else {
    console.log('NOTE: Most consigned sizes have no active asks (only bids)')
    console.log('      This is normal - consigned inventory may not always have listings')
  }

  console.log()
  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
