#!/usr/bin/env node

/**
 * Check price data in both stockx_market_latest and master_market_latest
 * to understand the multiply by 100 issue
 */

import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

async function checkPriceTables() {
  console.log('\n🔍 PRICE DATA INVESTIGATION')
  console.log('='.repeat(80))

  // Check stockx_market_latest
  console.log('\n📊 STOCKX_MARKET_LATEST (current code uses this):')
  console.log('─'.repeat(80))

  const { data: stockxData, error: stockxError } = await supabase
    .from('stockx_market_latest')
    .select('*')
    .limit(5)

  if (stockxError) {
    console.error('❌ Error:', stockxError)
  } else {
    console.log(`Found ${stockxData?.length || 0} rows`)
    if (stockxData && stockxData.length > 0) {
      const sample = stockxData[0]
      console.log('\nSample row:')
      console.log('  stockx_product_id:', sample.stockx_product_id)
      console.log('  stockx_variant_id:', sample.stockx_variant_id)
      console.log('  currency_code:', sample.currency_code)
      console.log('  lowest_ask:', sample.lowest_ask, typeof sample.lowest_ask)
      console.log('  highest_bid:', sample.highest_bid, typeof sample.highest_bid)
      console.log('  snapshot_at:', sample.snapshot_at)
      console.log('\n  💡 If lowest_ask = 189.00, it represents £189.00 (major units)')
      console.log('     If lowest_ask = 18900, it represents £189.00 (cents/pennies)')
    }
  }

  // Check master_market_latest
  console.log('\n\n📊 MASTER_MARKET_LATEST (should use this):')
  console.log('─'.repeat(80))

  const { data: masterData, error: masterError } = await supabase
    .from('master_market_latest')
    .select('*')
    .eq('provider', 'stockx')
    .limit(5)

  if (masterError) {
    console.error('❌ Error:', masterError)
  } else {
    console.log(`Found ${masterData?.length || 0} rows`)
    if (masterData && masterData.length > 0) {
      const sample = masterData[0]
      console.log('\nSample row:')
      console.log('  provider:', sample.provider)
      console.log('  provider_product_id:', sample.provider_product_id)
      console.log('  provider_variant_id:', sample.provider_variant_id)
      console.log('  sku:', sample.sku)
      console.log('  size_key:', sample.size_key)
      console.log('  currency_code:', sample.currency_code)
      console.log('  lowest_ask:', sample.lowest_ask, typeof sample.lowest_ask)
      console.log('  highest_bid:', sample.highest_bid, typeof sample.highest_bid)
      console.log('  snapshot_at:', sample.snapshot_at)
      console.log('\n  💡 Schema says: "MAJOR UNITS, not cents!"')
      console.log('     If lowest_ask = 189.00, it represents £189.00')
    }
  }

  // Check stockx_market_snapshots (raw data source)
  console.log('\n\n📊 STOCKX_MARKET_SNAPSHOTS (raw source):')
  console.log('─'.repeat(80))

  const { data: snapshotsData, error: snapshotsError } = await supabase
    .from('stockx_market_snapshots')
    .select('*')
    .limit(5)

  if (snapshotsError) {
    console.error('❌ Error:', snapshotsError)
  } else {
    console.log(`Found ${snapshotsData?.length || 0} rows`)
    if (snapshotsData && snapshotsData.length > 0) {
      const sample = snapshotsData[0]
      console.log('\nSample row:')
      console.log('  stockx_variant_id:', sample.stockx_variant_id)
      console.log('  currency_code:', sample.currency_code)
      console.log('  lowest_ask:', sample.lowest_ask, typeof sample.lowest_ask)
      console.log('  highest_bid:', sample.highest_bid, typeof sample.highest_bid)
      console.log('  snapshot_at:', sample.snapshot_at)
      console.log('\n  💡 Check if this is pennies or major units')
    }
  }

  console.log('\n' + '='.repeat(80))
  console.log('✅ Investigation complete')
  console.log('\nNEXT STEPS:')
  console.log('1. If stockx_market_latest has values like 18900 → stored in pennies, need /100')
  console.log('2. If master_market_latest has values like 189.00 → stored in major units, no /100')
  console.log('3. Code should switch from stockx_market_latest to master_market_latest\n')
}

checkPriceTables().catch(console.error)
