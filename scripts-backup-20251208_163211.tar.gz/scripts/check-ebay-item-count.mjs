#!/usr/bin/env node

/**
 * Quick check: How many eBay sold items for a SKU?
 */

import 'dotenv/config'
import { searchAuthenticatedNewSneakers } from '../src/lib/services/ebay/sneakers.js'

const SKU = process.argv[2] || 'DZ4137-700'

async function main() {
  console.log(`\nChecking eBay sold items for: ${SKU}`)
  console.log('Filters: AG + conditions [1000, 1500, 1750] + soldItemsOnly\n')

  const result = await searchAuthenticatedNewSneakers(SKU, {
    fetchFullDetails: false, // Quick count
    soldItemsOnly: true,
  })

  console.log('Results:')
  console.log('  Total fetched:', result.totalFetched)
  console.log('  Items returned:', result.items.length)
  console.log()

  if (result.items.length > 0) {
    console.log('Sample items:')
    result.items.slice(0, 5).forEach((item, i) => {
      console.log(`\n${i + 1}. ${item.title}`)
      console.log(`   Price: ${item.currency} ${item.price}`)
      console.log(`   Condition: ${item.conditionId}`)
      console.log(`   Sold: ${item.soldAt}`)
    })

    // Count by condition
    const byCondition = result.items.reduce((acc, item) => {
      const cond = item.conditionId || 'unknown'
      acc[cond] = (acc[cond] || 0) + 1
      return acc
    }, {})

    console.log('\nBreakdown by condition:')
    Object.entries(byCondition).forEach(([cond, count]) => {
      const label = cond === '1000' ? 'NEW (1000)' :
                    cond === '1500' ? 'NEW_WITH_DEFECTS (1500)' :
                    cond === '1750' ? 'NEW_WITH_BOX (1750)' : cond
      console.log(`  ${label}: ${count}`)
    })
  }
  console.log()
}

main().catch(err => {
  console.error('Error:', err.message)
  process.exit(1)
})
