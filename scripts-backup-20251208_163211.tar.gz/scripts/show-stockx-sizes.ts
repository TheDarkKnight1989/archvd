/**
 * Show StockX data with proper sizes for FV5029-010
 */

import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010'

async function main() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  console.log('===============================================================================')
  console.log('StockX UK Data with Proper Sizes')
  console.log('===============================================================================\n')
  console.log('SKU:', SKU)
  console.log('Currency: GBP')
  console.log('Region: UK')
  console.log()

  // Query latest data
  const { data, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('sku', SKU)
    .eq('provider', 'stockx')
    .eq('currency_code', 'GBP')
    .eq('region_code', 'UK')
    .order('created_at', { ascending: false })
    .order('size_numeric', { ascending: true })
    .limit(60)

  if (error) {
    console.error('❌ Error:', error.message)
    return
  }

  if (!data || data.length === 0) {
    console.log('❌ No data found')
    return
  }

  console.log(`✅ Found ${data.length} rows\n`)

  // Group by size, showing both standard and flex
  const sizeGroups = new Map<string, any[]>()
  for (const row of data) {
    const size = row.size_key || 'Unknown'
    if (!sizeGroups.has(size)) {
      sizeGroups.set(size, [])
    }
    sizeGroups.get(size)!.push(row)
  }

  // Sort by numeric size
  const sortedSizes = Array.from(sizeGroups.entries()).sort((a, b) => {
    const numA = parseFloat(a[0]) || 999
    const numB = parseFloat(b[0]) || 999
    return numA - numB
  })

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('SIZE-BY-SIZE BREAKDOWN')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  for (const [size, rows] of sortedSizes.slice(0, 5)) {
    console.log(`📦 SIZE ${size} US`)
    console.log()

    const standard = rows.find(r => r.provider_source === 'stockx_market_data')
    const flex = rows.find(r => r.provider_source === 'stockx_market_data_flex')

    if (standard) {
      console.log('  📊 STANDARD:')
      console.log('     Lowest Ask:  £' + (standard.lowest_ask || 'N/A'))
      console.log('     Highest Bid: £' + (standard.highest_bid || 'N/A'))
      console.log('     Last Sale:   £' + (standard.last_sale_price || 'N/A'))
      if (standard.sales_last_72h !== null) {
        console.log('     Sales (72h): ' + standard.sales_last_72h)
      }
      console.log()
    }

    if (flex) {
      console.log('  🚀 FLEX:')
      console.log('     Lowest Ask:  £' + (flex.lowest_ask || 'N/A'))
      console.log('     Highest Bid: £' + (flex.highest_bid || 'N/A'))
      console.log('     Last Sale:   £' + (flex.last_sale_price || 'N/A'))
      console.log()
    }
  }

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('SUMMARY')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('Total rows:', data.length)
  console.log('Unique sizes:', sizeGroups.size)
  console.log('Standard rows:', data.filter(r => r.provider_source === 'stockx_market_data').length)
  console.log('Flex rows:', data.filter(r => r.provider_source === 'stockx_market_data_flex').length)
  console.log()

  // Check for "Unknown" sizes
  const unknownCount = data.filter(r => r.size_key === 'Unknown').length
  if (unknownCount > 0) {
    console.log('⚠️  WARNING:', unknownCount, 'rows still have size_key = "Unknown"')
  } else {
    console.log('✅ All rows have proper size information!')
  }
}

main().catch(console.error)
