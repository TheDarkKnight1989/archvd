#!/usr/bin/env node

/**
 * Test eBay transaction ingestion pipeline
 * Fetches sold items → stores in ebay_sold_transactions → shows stats
 */

import 'dotenv/config'
import { searchAuthenticatedNewSneakers } from '../src/lib/services/ebay/sneakers.js'
import { ingestEbayTransactions, getTransactionStats } from '../src/lib/services/ingestion/ebay-transaction-ingestion.js'

const SKU = process.argv[2] || 'DZ4137-700'

async function main() {
  console.log('\n' + '═'.repeat(80))
  console.log(`eBay Transaction Ingestion Test - ${SKU}`)
  console.log('═'.repeat(80) + '\n')

  // STEP 1: Fetch sold items with full details (two-step fetch)
  console.log('📡 Fetching eBay sold items with full details...\n')

  const result = await searchAuthenticatedNewSneakers(SKU, {
    fetchFullDetails: true, // CRITICAL: Enables two-step fetch for size data
    soldItemsOnly: true,
  })

  console.log('✅ Fetch complete:', {
    totalFetched: result.totalFetched,
    fullDetailsFetched: result.fullDetailsFetched,
    items: result.items.length,
  })

  if (result.items.length === 0) {
    console.log('\n❌ No items found')
    process.exit(0)
  }

  // STEP 2: Ingest into ebay_sold_transactions
  console.log('\n📥 Ingesting transactions...\n')

  const rows = await ingestEbayTransactions(result.items, {
    searchQuery: SKU,
    marketplaceId: 'EBAY_GB',
    dryRun: false, // Set to true to preview without inserting
  })

  console.log(`\n✅ Ingested ${rows.length} transaction rows\n`)

  // STEP 3: Get stats
  console.log('📊 Transaction Stats:\n')

  const stats = await getTransactionStats(SKU, 'EBAY_GB')

  if (!stats) {
    console.log('❌ Failed to fetch stats')
    process.exit(1)
  }

  console.log('Total transactions:', stats.totalTransactions)
  console.log('Included in metrics:', stats.includedInMetrics)
  console.log('Excluded:', stats.excluded)
  console.log()

  if (stats.excluded > 0) {
    console.log('Exclusion reasons:')
    Object.entries(stats.exclusionReasons).forEach(([reason, count]) => {
      console.log(`  - ${reason}: ${count}`)
    })
    console.log()
  }

  console.log('Size systems:')
  stats.sizeSystems.forEach(([system, count]) => {
    console.log(`  - ${system}: ${count}`)
  })
  console.log()

  console.log('Size confidence:')
  console.log(`  - HIGH (1.0): ${stats.sizeConfidence.high}`)
  console.log(`  - MEDIUM (0.7): ${stats.sizeConfidence.medium}`)
  console.log(`  - LOW (0.3): ${stats.sizeConfidence.low}`)
  console.log(`  - NULL: ${stats.sizeConfidence.null}`)

  console.log('\n' + '═'.repeat(80) + '\n')
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message)
  console.error(err)
  process.exit(1)
})
