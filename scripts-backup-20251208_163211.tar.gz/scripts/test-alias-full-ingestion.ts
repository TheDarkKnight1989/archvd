#!/usr/bin/env npx tsx
/**
 * Test Alias Full Ingestion Pipeline
 * Verify we can fetch AND ingest Alias data to master_market_data
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { syncAliasProductMultiRegion } from '@/lib/services/alias/sync'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🧪 Testing Alias Full Ingestion Pipeline\n')

  const testCatalogId = '2002r-protection-pack-phantom-m2002rdb'
  const testSku = 'M2002RDB'

  console.log(`Test Product: ${testSku}`)
  console.log(`Catalog ID: ${testCatalogId}`)
  console.log('='.repeat(80) + '\n')

  // Clear any existing data for this test
  console.log('1. Clearing previous test data...')
  const { error: deleteError } = await supabase
    .from('master_market_data')
    .delete()
    .eq('provider', 'alias')
    .eq('sku', testSku)
    .gte('snapshot_at', new Date(Date.now() - 60 * 60 * 1000).toISOString()) // Last hour

  if (deleteError) {
    console.warn(`   ⚠️ Delete warning: ${deleteError.message}`)
  } else {
    console.log('   ✅ Previous data cleared')
  }

  // Run the full sync
  console.log('\n2. Running full multi-region sync...')
  const aliasClient = createAliasClient()

  try {
    const result = await syncAliasProductMultiRegion(aliasClient, testCatalogId, {
      sku: testSku,
      userRegion: 'UK',
      syncSecondaryRegions: true, // Test all 3 regions
    })

    console.log('\n3. Sync Results:')
    if (result.success) {
      console.log(`   ✅ SUCCESS`)
      console.log(`   Primary Region: ${result.primaryRegion}`)
      console.log(`   Primary Variants: ${result.primaryResult.variantsIngested}`)
      console.log(`   Secondary Regions: ${Object.keys(result.secondaryResults).length}`)

      for (const [region, regionResult] of Object.entries(result.secondaryResults)) {
        console.log(`   - Region ${region}: ${regionResult.variantsIngested} variants (${regionResult.success ? '✅' : '❌'})`)
      }

      console.log(`   Total Variants Ingested: ${result.totalVariantsIngested}`)
    } else {
      console.log(`   ❌ FAILED: ${result.primaryResult.error}`)
      return
    }

    // Verify data in database
    console.log('\n4. Verifying database...')
    const oneMinuteAgo = new Date(Date.now() - 60 * 1000).toISOString()

    const { data: dbData, error: dbError } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('provider', 'alias')
      .eq('sku', testSku)
      .gte('snapshot_at', oneMinuteAgo)

    if (dbError) {
      console.error(`   ❌ Database query failed: ${dbError.message}`)
      return
    }

    if (!dbData || dbData.length === 0) {
      console.error('   ❌ NO DATA FOUND IN DATABASE!')
      console.error('      Sync reported success but no data was inserted!')
      return
    }

    // Analyze the data
    const byRegion = dbData.reduce((acc, row) => {
      const region = row.region_code || 'unknown'
      acc[region] = (acc[region] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    const uniqueSizes = new Set(dbData.map(r => r.size_key || r.size_numeric))
    const withPrices = dbData.filter(r => r.lowest_ask || r.highest_bid || r.last_sale_price)

    console.log(`   ✅ Found ${dbData.length} snapshots in database`)
    console.log(`   ✅ Regions: ${Object.keys(byRegion).length}`)
    for (const [region, count] of Object.entries(byRegion)) {
      console.log(`      - Region ${region}: ${count} snapshots`)
    }
    console.log(`   ✅ Unique sizes: ${uniqueSizes.size}`)
    console.log(`   ✅ Records with prices: ${withPrices.length}/${dbData.length}`)

    // Check data quality
    console.log('\n5. Data Quality Check:')
    let missingFields = 0
    let qualityIssues = []

    for (const row of dbData) {
      if (!row.size_key && !row.size_numeric) {
        missingFields++
        qualityIssues.push('Missing size_key/size_numeric')
      }
      if (!row.region_code) {
        missingFields++
        qualityIssues.push('Missing region_code')
      }
      if (!row.currency_code) {
        missingFields++
        qualityIssues.push('Missing currency_code')
      }
    }

    if (missingFields === 0) {
      console.log('   ✅ ALL REQUIRED FIELDS PRESENT')
    } else {
      console.log(`   ❌ ${missingFields} records with missing fields`)
      const issueCount = qualityIssues.reduce((acc, issue) => {
        acc[issue] = (acc[issue] || 0) + 1
        return acc
      }, {} as Record<string, number>)
      for (const [issue, count] of Object.entries(issueCount)) {
        console.log(`      - ${issue}: ${count}`)
      }
    }

    // Sample data
    console.log('\n6. Sample Record:')
    const sample = dbData[0]
    console.log(`   SKU: ${sample.sku}`)
    console.log(`   Provider: ${sample.provider}`)
    console.log(`   Region: ${sample.region_code}`)
    console.log(`   Size: ${sample.size_key || sample.size_numeric} ${sample.size_system}`)
    console.log(`   Lowest Ask: ${sample.lowest_ask ? '$' + sample.lowest_ask : 'null'}`)
    console.log(`   Highest Bid: ${sample.highest_bid ? '$' + sample.highest_bid : 'null'}`)
    console.log(`   Last Sale: ${sample.last_sale_price ? '$' + sample.last_sale_price : 'null'}`)
    console.log(`   Currency: ${sample.currency_code}`)
    console.log(`   Snapshot At: ${sample.snapshot_at}`)

    console.log('\n' + '='.repeat(80))
    if (missingFields === 0 && dbData.length > 0) {
      console.log('✅ ALIAS FULL INGESTION WORKING PERFECTLY!')
      console.log(`   ${result.totalVariantsIngested} variants synced across ${Object.keys(byRegion).length} regions`)
      console.log(`   All data successfully written to master_market_data`)
      console.log(`   Data quality: 100%`)
    } else {
      console.log('⚠️  ALIAS INGESTION HAS ISSUES')
    }

  } catch (error: any) {
    console.error('\n❌ SYNC FAILED:', error.message)
    console.error('   Stack:', error.stack?.split('\n').slice(0, 3).join('\n   '))
  }
}

main().catch(console.error)
