#!/usr/bin/env node
/**
 * Verify what data was actually stored for IF4491-100
 */

import { createClient } from '@supabase/supabase-js';

const SKU = 'IF4491-100';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

console.log('================================================================================');
console.log('VERIFYING STORED DATA FOR:', SKU);
console.log('================================================================================\n');

// ============================================================================
// 1. Product Catalog Entry
// ============================================================================

console.log('1️⃣  PRODUCT CATALOG\n');

const { data: catalogEntry } = await supabase
  .from('product_catalog')
  .select('*')
  .eq('sku', SKU)
  .single();

if (catalogEntry) {
  console.log('✅ Product exists in product_catalog:');
  console.log('   SKU:', catalogEntry.sku);
  console.log('   Product ID:', catalogEntry.id);
  console.log('   StockX Product ID:', catalogEntry.stockx_product_id);
  console.log('   Brand:', catalogEntry.brand);
  console.log('   Model:', catalogEntry.model);
  console.log('   Colorway:', catalogEntry.colorway || 'NULL');
  console.log('   Retail Price:', catalogEntry.retail_price ? `£${(catalogEntry.retail_price / 100).toFixed(2)}` : 'NULL');
  console.log('   Release Date:', catalogEntry.release_date || 'NULL');
  console.log('   Category:', catalogEntry.category || 'NULL');
  console.log('   Gender:', catalogEntry.gender || 'NULL');
  console.log('   Image URL:', catalogEntry.image_url ? 'SET' : 'NULL');
} else {
  console.log('❌ Product NOT found in product_catalog');
}

console.log('\n' + '='.repeat(80) + '\n');

// ============================================================================
// 2. Raw Snapshots
// ============================================================================

console.log('2️⃣  RAW SNAPSHOTS (stockx_raw_snapshots)\n');

const { data: rawSnapshots, count: rawCount } = await supabase
  .from('stockx_raw_snapshots')
  .select('id, currency_code, http_status, requested_at, endpoint', { count: 'exact' })
  .eq('product_id', catalogEntry?.stockx_product_id)
  .order('requested_at', { ascending: false })
  .limit(10);

if (rawSnapshots && rawSnapshots.length > 0) {
  console.log(`✅ Found ${rawCount} raw snapshots:\n`);

  rawSnapshots.forEach((snapshot, idx) => {
    const age = Math.floor((Date.now() - new Date(snapshot.requested_at).getTime()) / 1000 / 60);
    console.log(`   ${idx + 1}. ${snapshot.id.substring(0, 8)}...`);
    console.log(`      Currency: ${snapshot.currency_code}`);
    console.log(`      Endpoint: ${snapshot.endpoint}`);
    console.log(`      Status: ${snapshot.http_status}`);
    console.log(`      Age: ${age}m ago`);
    console.log('');
  });
} else {
  console.log('❌ No raw snapshots found');
}

console.log('='.repeat(80) + '\n');

// ============================================================================
// 3. Master Market Data
// ============================================================================

console.log('3️⃣  MASTER MARKET DATA (master_market_data)\n');

const { data: marketData, count: marketCount } = await supabase
  .from('master_market_data')
  .select('currency_code, region_code, size_key, is_flex, is_consigned, lowest_ask, highest_bid, snapshot_at', { count: 'exact' })
  .eq('provider', 'stockx')
  .eq('sku', SKU)
  .gte('snapshot_at', new Date(Date.now() - 60 * 60 * 1000).toISOString()) // Last hour
  .order('currency_code')
  .order('size_numeric')
  .limit(30);

if (marketData && marketData.length > 0) {
  console.log(`✅ Found ${marketCount} total rows (showing first 30):\n`);

  // Group by currency
  const byCurrency = marketData.reduce((acc, row) => {
    if (!acc[row.currency_code]) acc[row.currency_code] = [];
    acc[row.currency_code].push(row);
    return acc;
  }, {});

  for (const [currency, rows] of Object.entries(byCurrency)) {
    console.log(`   ${currency} (${rows[0].region_code}):`);
    console.log(`      Total rows: ${rows.length}`);

    // Count by pricing type
    const standard = rows.filter(r => !r.is_flex && !r.is_consigned).length;
    const flex = rows.filter(r => r.is_flex).length;
    const consigned = rows.filter(r => r.is_consigned).length;

    console.log(`      - Standard: ${standard} sizes`);
    console.log(`      - Flex: ${flex} sizes`);
    console.log(`      - Consigned: ${consigned} sizes`);

    // Show sample
    const sample = rows.filter(r => !r.is_flex && !r.is_consigned).slice(0, 2);
    if (sample.length > 0) {
      console.log(`      Sample prices:`);
      sample.forEach(r => {
        console.log(`         Size ${r.size_key}: Ask=${r.lowest_ask || 'NULL'}, Bid=${r.highest_bid || 'NULL'}`);
      });
    }
    console.log('');
  }
} else {
  console.log('❌ No market data found');
}

console.log('='.repeat(80) + '\n');

// ============================================================================
// 4. Materialized View (Latest Prices)
// ============================================================================

console.log('4️⃣  MATERIALIZED VIEW (master_market_latest)\n');

const { data: latestData, count: latestCount } = await supabase
  .from('master_market_latest')
  .select('currency_code, region_code, size_key, is_flex, is_consigned, lowest_ask, highest_bid, data_age_minutes', { count: 'exact' })
  .eq('provider', 'stockx')
  .eq('sku', SKU)
  .order('currency_code')
  .order('size_numeric')
  .limit(20);

if (latestData && latestData.length > 0) {
  console.log(`✅ Found ${latestCount} rows in materialized view:\n`);

  const byCurrency = latestData.reduce((acc, row) => {
    if (!acc[row.currency_code]) acc[row.currency_code] = 0;
    acc[row.currency_code]++;
    return acc;
  }, {});

  for (const [currency, count] of Object.entries(byCurrency)) {
    console.log(`   ${currency}: ${count} price points`);
  }

  const sampleRow = latestData[0];
  if (sampleRow) {
    console.log(`\n   Sample (Size ${sampleRow.size_key}, ${sampleRow.currency_code}):`);
    console.log(`      Lowest Ask: ${sampleRow.lowest_ask || 'NULL'}`);
    console.log(`      Highest Bid: ${sampleRow.highest_bid || 'NULL'}`);
    console.log(`      Data Age: ${sampleRow.data_age_minutes || 'NULL'} minutes`);
  }
} else {
  console.log('❌ No data in materialized view (may need refresh)');
}

console.log('\n' + '='.repeat(80) + '\n');

// ============================================================================
// SUMMARY
// ============================================================================

console.log('📊 STORAGE SUMMARY:\n');
console.log(`   Product Catalog: ${catalogEntry ? '✅' : '❌'}`);
console.log(`   Raw Snapshots: ${rawCount || 0} entries`);
console.log(`   Market Data Rows: ${marketCount || 0} entries`);
console.log(`   Materialized View: ${latestCount || 0} price points`);
console.log('');

if (rawCount > 0 && marketCount > 0) {
  console.log('✅ ALL DATA STORED SUCCESSFULLY!');
  console.log('');
  console.log('Complete pipeline verified:');
  console.log('  1. Product metadata in catalog ✓');
  console.log('  2. Raw API responses saved ✓');
  console.log('  3. Normalized market data stored ✓');
  console.log('  4. Materialized view populated ✓');
} else {
  console.log('⚠️  Some data missing - review above');
}
