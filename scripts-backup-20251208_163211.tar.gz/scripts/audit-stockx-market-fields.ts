/**
 * Audit: What market data fields does StockX provide that we're not capturing?
 */

import { StockxCatalogService } from '@/lib/services/stockx/catalog'

const TEST_PRODUCT_ID = '15795a80-5cc8-4d2d-9ed0-20250d83be7f' // FV5029-010
const CURRENCY = 'GBP'

async function main() {
  console.log('===============================================================================')
  console.log('StockX Market Data Fields Audit')
  console.log('===============================================================================\n')

  const catalogService = new StockxCatalogService(undefined)
  const client = (catalogService as any).client

  try {
    console.log('🔄 Fetching raw market data from StockX...')
    console.log(`   Product ID: ${TEST_PRODUCT_ID}`)
    console.log(`   Currency: ${CURRENCY}`)
    console.log()

    const marketData = await client.request(
      `/v2/catalog/products/${TEST_PRODUCT_ID}/market-data?currencyCode=${CURRENCY}`
    )

    if (!Array.isArray(marketData) || marketData.length === 0) {
      console.log('❌ No market data returned')
      return
    }

    console.log(`✅ Received ${marketData.length} variants\n`)

    // Analyze first variant to see all available fields
    const firstVariant = marketData[0]
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('RAW API RESPONSE (First Variant - Full Structure)')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
    console.log(JSON.stringify(firstVariant, null, 2))
    console.log()

    // Extract all unique keys across all variants
    const allKeys = new Set<string>()
    for (const variant of marketData) {
      Object.keys(variant).forEach(key => allKeys.add(key))

      // Also check nested objects
      if (variant.standardMarketData) {
        Object.keys(variant.standardMarketData).forEach(key =>
          allKeys.add(`standardMarketData.${key}`)
        )
      }
      if (variant.flexMarketData) {
        Object.keys(variant.flexMarketData).forEach(key =>
          allKeys.add(`flexMarketData.${key}`)
        )
      }
      if (variant.directMarketData) {
        Object.keys(variant.directMarketData).forEach(key =>
          allKeys.add(`directMarketData.${key}`)
        )
      }
    }

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('ALL AVAILABLE FIELDS')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    const sortedKeys = Array.from(allKeys).sort()
    for (const key of sortedKeys) {
      console.log(`   ${key}`)
    }
    console.log()

    // Now check what we're currently capturing
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('WHAT WE\'RE CURRENTLY CAPTURING')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    const captured = [
      'variantId → provider_variant_id',
      'lowestAskAmount → lowest_ask (standard)',
      'highestBidAmount → highest_bid (standard)',
      'lastSaleAmount → last_sale_price',
      'salesLast72Hours → sales_last_72h',
      'totalVolume → sales_last_30d',
      'averagePrice → average_deadstock_price',
      'volatility → volatility',
      'pricePremium → price_premium',
      'flexMarketData.lowestAsk → lowest_ask (flex)',
      'flexMarketData.highestBidAmount → highest_bid (flex)',
    ]

    for (const field of captured) {
      console.log(`   ✅ ${field}`)
    }
    console.log()

    // Identify what we're NOT capturing
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('POTENTIALLY MISSING FIELDS')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    const capturedBase = [
      'variantId', 'productId', 'currencyCode',
      'lowestAskAmount', 'highestBidAmount', 'lastSaleAmount',
      'salesLast72Hours', 'totalVolume', 'averagePrice',
      'volatility', 'pricePremium',
      'standardMarketData', 'flexMarketData', 'directMarketData'
    ]

    const missing: string[] = []
    for (const key of sortedKeys) {
      const baseKey = key.split('.')[0]
      if (!capturedBase.includes(baseKey)) {
        missing.push(key)
      }
    }

    if (missing.length === 0) {
      console.log('   ✅ We appear to be capturing all top-level fields!')
    } else {
      for (const key of missing) {
        console.log(`   ❌ ${key}`)
      }
    }
    console.log()

    // Check specific nested fields we're missing
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('FLEX FIELDS NOT CAPTURED')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    const flexVariant = marketData.find(v => v.flexMarketData)
    if (flexVariant?.flexMarketData) {
      console.log('Flex fields available but not stored:')
      if (flexVariant.flexMarketData.sellFaster) {
        console.log(`   ❌ sellFaster: £${flexVariant.flexMarketData.sellFaster} (price to sell with expedited shipping)`)
      }
      if (flexVariant.flexMarketData.earnMore) {
        console.log(`   ❌ earnMore: £${flexVariant.flexMarketData.earnMore} (price to earn more)`)
      }
      if (flexVariant.flexMarketData.beatUS) {
        console.log(`   ❌ beatUS: £${flexVariant.flexMarketData.beatUS}`)
      }
      console.log()
      console.log('💡 These Flex-specific fields could be useful for:')
      console.log('   - Showing sellers the expedited shipping price option')
      console.log('   - Comparing standard vs flex pricing')
      console.log('   - Optimizing listing strategies')
    } else {
      console.log('   No flex data available for this product')
    }
    console.log()

    // Check direct market data
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('DIRECT MARKET DATA')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    const directVariant = marketData.find(v => v.directMarketData)
    if (directVariant?.directMarketData) {
      console.log('Direct market data available:')
      console.log(JSON.stringify(directVariant.directMarketData, null, 2))
      console.log()
      console.log('💡 Direct market data is another selling option (similar to Flex)')
    } else {
      console.log('   No direct market data available for this product')
    }
    console.log()

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('RECOMMENDATIONS')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')
    console.log('Consider adding to master_market_data:')
    console.log()
    console.log('1. Flex-specific fields (if schema supports):')
    console.log('   - flex_sell_faster_price')
    console.log('   - flex_earn_more_price')
    console.log('   - flex_beat_us_price')
    console.log()
    console.log('2. Direct market data (if available):')
    console.log('   - Create separate rows with provider_source="stockx_market_data_direct"')
    console.log()
    console.log('3. Additional metadata:')
    console.log('   - Store full raw response in raw_response_excerpt for future analysis')
    console.log()

  } catch (error: any) {
    console.error('❌ Error:', error.message)
    throw error
  }
}

main().catch(console.error)
