#!/usr/bin/env node

/**
 * Test full eBay time-series pipeline
 * Fetch → Ingest → Compute Metrics → Show Results
 */

import 'dotenv/config'
import { searchAuthenticatedNewSneakers } from '../src/lib/services/ebay/sneakers.js'
import { ingestEbayTransactions, getTransactionStats } from '../src/lib/services/ingestion/ebay-transaction-ingestion.js'
import { computeEbayMetrics } from '../src/lib/services/ingestion/ebay-metrics-computation.js'
import { createClient } from '@supabase/supabase-js'

const SKU = process.argv[2] || 'DZ4137-700'

async function main() {
  console.log('\n' + '═'.repeat(80))
  console.log(`eBay Full Pipeline Test - ${SKU}`)
  console.log('═'.repeat(80) + '\n')

  // ============================================================================
  // STEP 1: FETCH SOLD ITEMS
  // ============================================================================

  console.log('📡 STEP 1: Fetching eBay sold items with full details...\n')

  const result = await searchAuthenticatedNewSneakers(SKU, {
    fetchFullDetails: true, // Two-step fetch for size data
    soldItemsOnly: true,
  })

  console.log('✅ Fetch complete:', {
    totalFetched: result.totalFetched,
    fullDetailsFetched: result.fullDetailsFetched,
  })

  if (result.items.length === 0) {
    console.log('\n❌ No items found')
    process.exit(0)
  }

  // ============================================================================
  // STEP 2: INGEST TRANSACTIONS
  // ============================================================================

  console.log('\n📥 STEP 2: Ingesting transactions into ebay_sold_transactions...\n')

  const rows = await ingestEbayTransactions(result.items, {
    searchQuery: SKU,
    marketplaceId: 'EBAY_GB',
  })

  console.log(`✅ Ingested ${rows.length} rows\n`)

  // ============================================================================
  // STEP 3: COMPUTE METRICS
  // ============================================================================

  console.log('📊 STEP 3: Computing rolling medians and metrics...\n')

  const metrics = await computeEbayMetrics({
    sku: SKU,
    marketplaceId: 'EBAY_GB',
  })

  console.log(`✅ Computed ${metrics.length} metric rows\n`)

  // ============================================================================
  // STEP 4: SHOW RESULTS
  // ============================================================================

  console.log('=' .repeat(80))
  console.log('TRANSACTION STATS')
  console.log('='.repeat(80) + '\n')

  const stats = await getTransactionStats(SKU, 'EBAY_GB')

  if (stats) {
    console.log(`Total transactions: ${stats.totalTransactions}`)
    console.log(`Included in metrics: ${stats.includedInMetrics}`)
    console.log(`Excluded: ${stats.excluded}\n`)

    if (stats.excluded > 0) {
      console.log('Exclusion reasons:')
      Object.entries(stats.exclusionReasons).forEach(([reason, count]) => {
        console.log(`  ${reason}: ${count}`)
      })
      console.log()
    }

    console.log('Size systems:')
    stats.sizeSystems.forEach(([system, count]) => {
      console.log(`  ${system}: ${count}`)
    })
    console.log()

    console.log('Size confidence:')
    console.log(`  HIGH (1.0): ${stats.sizeConfidence.high}`)
    console.log(`  MEDIUM (0.7): ${stats.sizeConfidence.medium}`)
    console.log(`  LOW (0.3): ${stats.sizeConfidence.low}`)
    console.log(`  NULL: ${stats.sizeConfidence.null}`)
  }

  console.log('\n' + '='.repeat(80))
  console.log('COMPUTED METRICS BY SIZE')
  console.log('='.repeat(80) + '\n')

  if (metrics.length === 0) {
    console.log('No metrics computed (no qualifying transactions)')
  } else {
    // Sort by size_numeric
    const sorted = metrics.sort((a, b) => {
      const aNum = parseFloat(a.size_key.replace(/[^0-9.]/g, '')) || 0
      const bNum = parseFloat(b.size_key.replace(/[^0-9.]/g, '')) || 0
      return aNum - bNum
    })

    console.log('Size       | 72h Median | 7d Median  | 30d Median | 90d Median | Conf | Liq')
    console.log('-----------|------------|------------|------------|------------|------|-----')

    sorted.forEach((m) => {
      const size = m.size_key.padEnd(10)
      const med72h = m.median_72h_cents ? `£${(m.median_72h_cents / 100).toFixed(2)}`.padStart(9) : 'N/A'.padStart(9)
      const med7d = m.median_7d_cents ? `£${(m.median_7d_cents / 100).toFixed(2)}`.padStart(9) : 'N/A'.padStart(9)
      const med30d = m.median_30d_cents ? `£${(m.median_30d_cents / 100).toFixed(2)}`.padStart(9) : 'N/A'.padStart(9)
      const med90d = m.median_90d_cents ? `£${(m.median_90d_cents / 100).toFixed(2)}`.padStart(9) : 'N/A'.padStart(9)
      const conf = m.confidence_score ? String(m.confidence_score).padStart(4) : 'N/A'.padStart(4)
      const liq = m.liquidity_score ? String(m.liquidity_score).padStart(3) : 'N/A'.padStart(3)

      console.log(`${size} | ${med72h} | ${med7d} | ${med30d} | ${med90d} | ${conf} | ${liq}`)
    })

    console.log('\n' + '='.repeat(80))
    console.log('METRIC DETAILS (First Size)')
    console.log('='.repeat(80) + '\n')

    const first = sorted[0]
    console.log(`SKU: ${first.sku}`)
    console.log(`Size: ${first.size_key} (${first.size_system})`)
    console.log(`Currency: ${first.currency_code}`)
    console.log()
    console.log('Sample sizes:')
    console.log(`  72h: ${first.sample_size_72h}`)
    console.log(`  7d: ${first.sample_size_7d}`)
    console.log(`  30d: ${first.sample_size_30d}`)
    console.log(`  90d: ${first.sample_size_90d}`)
    console.log()
    console.log('Price range (90d):')
    console.log(`  Min: ${first.min_price_90d_cents ? '£' + (first.min_price_90d_cents / 100).toFixed(2) : 'N/A'}`)
    console.log(`  Max: ${first.max_price_90d_cents ? '£' + (first.max_price_90d_cents / 100).toFixed(2) : 'N/A'}`)
    console.log()
    console.log(`Volatility (90d): ${first.volatility_90d ? first.volatility_90d.toFixed(2) + '%' : 'N/A'}`)
    console.log(`Confidence score: ${first.confidence_score || 'N/A'}`)
    console.log(`Liquidity score: ${first.liquidity_score || 'N/A'}`)
    console.log()
    console.log('Outlier stats (90d):')
    console.log(`  Total sales: ${first.total_sales_90d}`)
    console.log(`  Outliers: ${first.outlier_count_90d}`)
    console.log(`  Outlier ratio: ${first.outlier_ratio_90d ? (first.outlier_ratio_90d * 100).toFixed(2) + '%' : 'N/A'}`)
    console.log()
    console.log(`Last sale: ${first.last_sale_at ? new Date(first.last_sale_at).toLocaleString() : 'N/A'}`)
    console.log(`Computed at: ${new Date(first.computed_at).toLocaleString()}`)
  }

  console.log('\n' + '═'.repeat(80) + '\n')
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message)
  console.error(err)
  process.exit(1)
})
