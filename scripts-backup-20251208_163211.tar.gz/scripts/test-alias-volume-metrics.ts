/**
 * Test Alias volume metrics (recent sales)
 * Requires: ALIAS_RECENT_SALES_ENABLED=true
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { syncAliasToMasterMarketData } from '@/lib/services/alias/sync'
import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS VOLUME METRICS TEST')
  console.log('SKU:', SKU)
  console.log('Feature Flag:', process.env.ALIAS_RECENT_SALES_ENABLED)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  if (process.env.ALIAS_RECENT_SALES_ENABLED !== 'true') {
    console.log('❌ ALIAS_RECENT_SALES_ENABLED is not set to "true"')
    console.log('   Please run: export ALIAS_RECENT_SALES_ENABLED=true')
    process.exit(1)
  }

  const client = createAliasClient()
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  // Search for product
  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const product = searchResults.catalog_items[0]

  console.log(`Product: ${product.name}`)
  console.log(`Catalog ID: ${product.catalog_id}\n`)

  // Clear existing data
  console.log('Clearing existing data...')
  await supabase
    .from('master_market_data')
    .delete()
    .eq('sku', SKU)
    .eq('provider', 'alias')

  console.log('✅ Cleared\n')

  // Run sync with recent_sales enabled
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('RUNNING SYNC (with volume metrics)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const syncResult = await syncAliasToMasterMarketData(client, product.catalog_id, {
    sku: SKU,
  })

  console.log('\nSync Result:')
  console.log(JSON.stringify(syncResult, null, 2))
  console.log()

  if (!syncResult.success) {
    console.error('❌ SYNC FAILED:', syncResult.error)
    process.exit(1)
  }

  // Check volume data in database
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('DATABASE VERIFICATION')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const { data: allRows } = await supabase
    .from('master_market_data')
    .select('provider_source, size_key, lowest_ask, sales_last_72h, sales_last_30d, total_sales_volume')
    .eq('sku', SKU)
    .eq('provider', 'alias')
    .order('provider_source')
    .order('size_numeric')

  if (!allRows || allRows.length === 0) {
    console.log('❌ NO ROWS FOUND IN DATABASE!')
    process.exit(1)
  }

  const standardRows = allRows.filter(r => r.provider_source === 'alias_availabilities')
  const consignedRows = allRows.filter(r => r.provider_source === 'alias_availabilities_consigned')

  console.log(`Total rows: ${allRows.length}`)
  console.log(`  Standard: ${standardRows.length}`)
  console.log(`  Consigned: ${consignedRows.length}\n`)

  // Count rows with volume data
  const rowsWithVolume = allRows.filter(r =>
    r.sales_last_72h !== null ||
    r.sales_last_30d !== null ||
    r.total_sales_volume !== null
  )

  console.log(`Rows with volume metrics: ${rowsWithVolume.length} / ${allRows.length}\n`)

  if (rowsWithVolume.length === 0) {
    console.log('❌ NO VOLUME METRICS FOUND!')
    console.log('   All sales_last_72h, sales_last_30d, total_sales_volume are NULL')
    console.log('   This means recent_sales API did not return data or failed')
    process.exit(1)
  }

  // Show samples
  console.log('SAMPLE ROWS WITH VOLUME DATA:\n')

  const standardWithVolume = standardRows.filter(r =>
    r.sales_last_72h !== null ||
    r.sales_last_30d !== null
  ).slice(0, 5)

  if (standardWithVolume.length > 0) {
    console.log('Standard (Non-Consigned):')
    for (const row of standardWithVolume) {
      console.log(`  Size ${row.size_key}: Ask=$${row.lowest_ask}, 72h=${row.sales_last_72h || 0}, 30d=${row.sales_last_30d || 0}, Total=${row.total_sales_volume || 0}`)
    }
    console.log()
  }

  const consignedWithVolume = consignedRows.filter(r =>
    r.sales_last_72h !== null ||
    r.sales_last_30d !== null
  ).slice(0, 5)

  if (consignedWithVolume.length > 0) {
    console.log('Consigned:')
    for (const row of consignedWithVolume) {
      console.log(`  Size ${row.size_key}: Ask=$${row.lowest_ask}, 72h=${row.sales_last_72h || 0}, 30d=${row.sales_last_30d || 0}, Total=${row.total_sales_volume || 0}`)
    }
    console.log()
  }

  // Final verdict
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('FINAL RESULT')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  if (rowsWithVolume.length > 0) {
    console.log('✅ SUCCESS! Volume metrics are working!')
    console.log(`   - ${rowsWithVolume.length} sizes have sales data`)
    console.log(`   - Recent sales API fixed (size parameter working)`)
    console.log(`   - sales_last_72h, sales_last_30d, total_sales_volume populated`)
    console.log()
  } else {
    console.log('⚠️  Partial success - pricing works but no recent sales data')
    console.log('   This may be normal if the product has no recent sales')
  }

  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
