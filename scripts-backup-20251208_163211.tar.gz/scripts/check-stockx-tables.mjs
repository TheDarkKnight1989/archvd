#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function check() {
  // Check old stockx_market_latest table
  const { count: oldCount, error: oldError } = await supabase
    .from('stockx_market_latest')
    .select('*', { count: 'exact', head: true });

  if (!oldError) {
    console.log('📊 OLD TABLE (stockx_market_latest):', oldCount, 'rows');

    if (oldCount > 0) {
      const { data: sample } = await supabase
        .from('stockx_market_latest')
        .select('sku, size, lowest_ask, sales_last_30d, updated_at')
        .limit(5);

      console.log('\nSample data:');
      sample?.forEach(row => {
        const hoursAgo = Math.floor((Date.now() - new Date(row.updated_at).getTime()) / (1000 * 60 * 60));
        console.log('  ', row.sku, row.size, '£' + row.lowest_ask, hoursAgo, 'hrs ago');
      });
    }
  } else {
    console.log('❌ stockx_market_latest table not found or error:', oldError.message);
  }

  // Check raw snapshots
  const { count: snapshotCount } = await supabase
    .from('stockx_raw_snapshots')
    .select('*', { count: 'exact', head: true });

  console.log('\n📸 RAW SNAPSHOTS (stockx_raw_snapshots):', snapshotCount || 0, 'rows');

  if (snapshotCount > 0) {
    const { data: recent } = await supabase
      .from('stockx_raw_snapshots')
      .select('product_id, sku, snapshot_at')
      .order('snapshot_at', { ascending: false })
      .limit(5);

    console.log('\nMost recent snapshots:');
    recent?.forEach(row => {
      const hoursAgo = Math.floor((Date.now() - new Date(row.snapshot_at).getTime()) / (1000 * 60 * 60));
      console.log('  ', row.sku || row.product_id, hoursAgo, 'hours ago');
    });
  }
}

check().catch(console.error);
