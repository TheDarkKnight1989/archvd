#!/usr/bin/env node

/**
 * Test Finding API with proper sold dates
 */

import 'dotenv/config'
import { findCompletedItems } from '../src/lib/services/ebay/finding-api'
import { enrichEbaySoldItem } from '../src/lib/services/ebay/extractors'

const SKU = process.argv[2] || 'DZ4137-700'

async function main() {
  console.log('\n' + '═'.repeat(80))
  console.log(`Finding API Test - ${SKU}`)
  console.log('═'.repeat(80) + '\n')

  const result = await findCompletedItems({
    keywords: SKU,
    limit: 50,
    conditionIds: [1000], // NEW only
    categoryIds: ['15709', '95672', '155194'], // Sneaker categories
    authenticityGuaranteeOnly: true,
    marketplaceId: 'EBAY-GB',
  })

  console.log(`\n✅ Found ${result.items.length} items\n`)

  if (result.items.length === 0) {
    console.log('No items found')
    return
  }

  // Show first 10 with dates and prices
  console.log('═'.repeat(80))
  console.log('FIRST 10 ITEMS WITH SOLD DATES:')
  console.log('═'.repeat(80) + '\n')

  result.items.slice(0, 10).forEach((item, i) => {
    const date = new Date(item.soldAt).toISOString().split('T')[0]
    const title = item.title.substring(0, 50)
    console.log(`${String(i + 1).padStart(2, '0')}. ${date} | ${item.currency} ${String(item.price).padStart(7)} | ${title}`)
  })

  // Sort by date to see date range
  const sortedByDate = [...result.items].sort((a, b) =>
    new Date(a.soldAt).getTime() - new Date(b.soldAt).getTime()
  )

  console.log('\n' + '═'.repeat(80))
  console.log('DATE RANGE:')
  console.log('═'.repeat(80))
  console.log(`Oldest: ${new Date(sortedByDate[0].soldAt).toISOString().split('T')[0]}`)
  console.log(`Newest: ${new Date(sortedByDate[sortedByDate.length - 1].soldAt).toISOString().split('T')[0]}`)

  // Sort by price
  const sortedByPrice = [...result.items].sort((a, b) => a.price - b.price)

  console.log('\n' + '═'.repeat(80))
  console.log('PRICE RANGE:')
  console.log('═'.repeat(80))
  console.log(`Lowest:  ${sortedByPrice[0].currency} ${sortedByPrice[0].price}`)
  console.log(`Highest: ${sortedByPrice[sortedByPrice.length - 1].currency} ${sortedByPrice[sortedByPrice.length - 1].price}`)
  console.log(`Average: ${sortedByPrice[0].currency} ${(result.items.reduce((sum, item) => sum + item.price, 0) / result.items.length).toFixed(2)}`)

  console.log('\n' + '═'.repeat(80) + '\n')
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message)
  console.error(err)
  process.exit(1)
})
