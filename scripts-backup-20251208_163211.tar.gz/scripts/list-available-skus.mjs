#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('\n🔍 Checking available SKUs in master_market_latest...\n')

const { data, error } = await supabase
  .from('master_market_latest')
  .select('sku, provider, size_key, currency_code')
  .not('sku', 'is', null)
  .order('sku')
  .limit(50)

if (error) {
  console.error('Error:', error.message)
  process.exit(1)
}

const skus = [...new Set(data?.map(d => d.sku) || [])]

console.log('Available SKUs:')
skus.forEach((sku, i) => {
  const count = data.filter(d => d.sku === sku).length
  console.log(`  ${i + 1}. ${sku} (${count} price records)`)
})

console.log(`\nTotal: ${skus.length} unique SKUs`)
console.log(`Total price records: ${data?.length || 0}\n`)

// Show detailed breakdown for first SKU
if (skus.length > 0) {
  const firstSku = skus[0]
  const records = data.filter(d => d.sku === firstSku)

  console.log(`\nExample: ${firstSku}`)
  console.log('─'.repeat(60))
  records.forEach(r => {
    console.log(`  ${r.provider} | Size ${r.size_key} | ${r.currency_code}`)
  })
  console.log()
}
