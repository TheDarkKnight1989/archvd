/**
 * Test StockX product endpoint vs market-data endpoint
 * to see where sales data actually comes from
 */

import { StockxCatalogService } from '@/lib/services/stockx/catalog'

const SKU = 'FV5029-010' // Jordan 4 Black Cat

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('Testing Different StockX Endpoints for Sales Data')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const catalogService = new StockxCatalogService(undefined)
  const client = (catalogService as any).client

  // Search for product
  const products = await catalogService.searchProducts(SKU, { limit: 5 })
  const product = products.find(p => p.styleId?.toUpperCase() === SKU.toUpperCase()) || products[0]

  console.log(`Product: ${product.productName}`)
  console.log(`Product ID: ${product.productId}\n`)

  // ========================================================================
  // Test 1: Search Results (already have this)
  // ========================================================================
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('ENDPOINT 1: Search Results')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log('Fields in search result:')
  console.log(`  salesLast72Hours: ${'salesLast72Hours' in product ? product.salesLast72Hours : 'MISSING'}`)
  console.log(`  totalVolume: ${'totalVolume' in product ? product.totalVolume : 'MISSING'}`)
  console.log()

  // ========================================================================
  // Test 2: Product Details Endpoint
  // ========================================================================
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('ENDPOINT 2: Product Details (/v2/catalog/products/{id})')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  try {
    const productDetails = await client.request(`/v2/catalog/products/${product.productId}`)

    console.log('Product details response (top-level fields):')
    const topLevelFields = Object.keys(productDetails).sort()
    for (const field of topLevelFields) {
      console.log(`  ${field}: ${typeof productDetails[field]}`)
    }
    console.log()

    console.log('Checking for sales data:')
    console.log(`  salesLast72Hours: ${'salesLast72Hours' in productDetails ? productDetails.salesLast72Hours : 'MISSING'}`)
    console.log(`  totalVolume: ${'totalVolume' in productDetails ? productDetails.totalVolume : 'MISSING'}`)
    console.log(`  sales30Days: ${'sales30Days' in productDetails ? productDetails.sales30Days : 'MISSING'}`)
    console.log()
  } catch (error: any) {
    console.log(`❌ Error: ${error.message}`)
    console.log()
  }

  // ========================================================================
  // Test 3: Market Data Endpoint (we already know this one)
  // ========================================================================
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('ENDPOINT 3: Market Data (/v2/catalog/products/{id}/market-data)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const marketData = await client.request(
    `/v2/catalog/products/${product.productId}/market-data?currencyCode=GBP`
  )
  const firstVariant = marketData[0]

  console.log('First variant fields:')
  console.log(`  salesLast72Hours: ${'salesLast72Hours' in firstVariant ? firstVariant.salesLast72Hours : 'MISSING'}`)
  console.log(`  totalVolume: ${'totalVolume' in firstVariant ? firstVariant.totalVolume : 'MISSING'}`)
  console.log()

  // ========================================================================
  // Test 4: Try other potential endpoints
  // ========================================================================
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('ENDPOINT 4: Product Stats (/v2/catalog/products/{id}/stats)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  try {
    const stats = await client.request(`/v2/catalog/products/${product.productId}/stats`)
    console.log('Stats response:')
    console.log(JSON.stringify(stats, null, 2))
    console.log()
  } catch (error: any) {
    console.log(`❌ Error: ${error.message}`)
    console.log()
  }

  // ========================================================================
  // Test 5: Variants endpoint
  // ========================================================================
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('ENDPOINT 5: Variants (/v2/catalog/products/{id}/variants)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const variants = await catalogService.getProductVariants(product.productId)
  const firstVariantDetails = variants[0]

  console.log('First variant fields:')
  const variantFields = Object.keys(firstVariantDetails).sort()
  for (const field of variantFields) {
    console.log(`  ${field}: ${typeof firstVariantDetails[field]}`)
  }
  console.log()

  console.log('Checking for sales data:')
  console.log(`  salesLast72Hours: ${'salesLast72Hours' in firstVariantDetails ? firstVariantDetails.salesLast72Hours : 'MISSING'}`)
  console.log(`  totalVolume: ${'totalVolume' in firstVariantDetails ? firstVariantDetails.totalVolume : 'MISSING'}`)
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('CONCLUSION')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')
  console.log('Which endpoint has sales data?')
  console.log('This will tell us how that Price Comparison extension is getting it.')
  console.log()
}

main().catch(console.error)
