#!/usr/bin/env npx tsx
/**
 * Test Inngest Sync - Direct Test
 * Tests the sync functions directly without requiring Inngest Dev Server
 */

import { createClient } from '@supabase/supabase-js'
import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh'
import { createAliasClient } from '@/lib/services/alias/client'
import { getAliasRegions } from '@/lib/services/alias/regions'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

interface SyncResult {
  sku: string
  aliasSuccess: boolean
  aliasSnapshots: number
  stockxSuccess: boolean
  stockxSnapshots: number
}

async function syncProduct(
  sku: string,
  aliasCatalogId: string | null,
  stockxProductId: string | null
): Promise<SyncResult> {
  console.log(`\n🔄 Syncing ${sku}...`)

  let aliasSuccess = false
  let aliasSnapshots = 0
  let stockxSuccess = false
  let stockxSnapshots = 0

  // Sync Alias
  if (aliasCatalogId) {
    try {
      console.log(`  📍 Alias: ${aliasCatalogId}`)

      const aliasClient = createAliasClient()
      const regions = await getAliasRegions(aliasClient)

      for (const region of regions) {
        try {
          const pricingResponse = await aliasClient.listPricingInsights({
            catalog_id: aliasCatalogId,
            region_id: region.id,
          })

          for (const variant of pricingResponse.variants) {
            if (!variant.availability) continue

            await supabase.from('master_market_data').insert({
              provider: 'alias',
              provider_source: 'alias_pricing_insights',
              provider_product_id: aliasCatalogId,
              sku,
              size_numeric: variant.size,
              size_system: variant.size_unit || 'US',
              currency_code: 'USD',
              region_code: region.id.toLowerCase().replace('region_', ''),
              lowest_ask: variant.availability.lowest_listing_price_cents
                ? parseInt(variant.availability.lowest_listing_price_cents) / 100
                : null,
              highest_bid: variant.availability.highest_offer_price_cents
                ? parseInt(variant.availability.highest_offer_price_cents) / 100
                : null,
              last_sale_price: variant.availability.last_sold_listing_price_cents
                ? parseInt(variant.availability.last_sold_listing_price_cents) / 100
                : null,
              global_indicator_price: variant.availability.global_indicator_price_cents
                ? parseInt(variant.availability.global_indicator_price_cents) / 100
                : null,
              ask_count: variant.availability.number_of_listings,
              bid_count: variant.availability.number_of_offers,
              snapshot_at: new Date().toISOString(),
              is_flex: false,
              is_consigned: variant.consigned || false,
            })

            aliasSnapshots++
          }
        } catch (error: any) {
          // Continue with other regions
        }
      }

      aliasSuccess = aliasSnapshots > 0
      console.log(`  ✅ Alias: ${aliasSnapshots} snapshots`)
    } catch (error: any) {
      console.log(`  ❌ Alias failed: ${error.message}`)
    }
  }

  // Sync StockX
  if (stockxProductId) {
    try {
      console.log(`  🟢 StockX: ${stockxProductId}`)

      const result = await syncProductAllRegions(undefined, stockxProductId, 'UK', false)

      if (result.success) {
        stockxSuccess = true
        stockxSnapshots = result.totalSnapshotsCreated
        console.log(`  ✅ StockX: ${stockxSnapshots} snapshots`)
      } else {
        console.log(`  ❌ StockX failed: ${result.primaryResult.error}`)
      }
    } catch (error: any) {
      console.log(`  ❌ StockX error: ${error.message}`)
    }
  }

  // Update last_synced_at
  if (aliasSuccess || stockxSuccess) {
    await supabase.from('products').update({ last_synced_at: new Date().toISOString() }).eq('sku', sku)
  }

  return {
    sku,
    aliasSuccess,
    aliasSnapshots,
    stockxSuccess,
    stockxSnapshots,
  }
}

async function syncWithConcurrency(products: any[], concurrency: number = 10) {
  const results: SyncResult[] = []
  let successCount = 0
  let failCount = 0

  console.log(`\n🔄 Syncing ${products.length} products with concurrency ${concurrency}...\n`)

  // Process in batches
  for (let i = 0; i < products.length; i += concurrency) {
    const batch = products.slice(i, i + concurrency)

    console.log(`\n📦 Batch ${Math.floor(i / concurrency) + 1}/${Math.ceil(products.length / concurrency)} (${batch.length} products)`)

    const batchResults = await Promise.allSettled(
      batch.map(async (product) => {
        const variants = product.product_variants as any[]
        const aliasCatalogId = variants.find((v) => v.alias_catalog_id)?.alias_catalog_id
        const stockxProductId = variants.find((v) => v.stockx_product_id)?.stockx_product_id

        return syncProduct(product.sku, aliasCatalogId || null, stockxProductId || null)
      })
    )

    for (const result of batchResults) {
      if (result.status === 'fulfilled') {
        results.push(result.value)
        const success =
          (result.value.aliasSuccess || !result.value.aliasSnapshots) &&
          (result.value.stockxSuccess || !result.value.stockxSnapshots)
        if (success) {
          successCount++
        } else {
          failCount++
        }
      } else {
        failCount++
      }
    }

    // Small delay between batches to avoid rate limits
    if (i + concurrency < products.length) {
      await new Promise((resolve) => setTimeout(resolve, 2000))
    }
  }

  return { results, successCount, failCount }
}

async function main() {
  console.log('🧪 Testing Inngest Sync - Direct Mode\n')

  // Get all products
  const { data: allProducts, error } = await supabase
    .from('products')
    .select(
      `
      id,
      sku,
      brand,
      model,
      product_variants (
        alias_catalog_id,
        stockx_product_id
      )
    `
    )

  if (error || !allProducts) {
    console.error('❌ Failed to fetch products:', error?.message)
    return
  }

  // Filter products that have either Alias or StockX IDs
  const products = allProducts.filter((p) => {
    const variants = p.product_variants as any[]
    return (
      variants &&
      variants.some((v) => v.alias_catalog_id || v.stockx_product_id)
    )
  })

  console.log(`Found ${products.length} products to sync (out of ${allProducts.length} total)`)

  const { results, successCount, failCount } = await syncWithConcurrency(products, 10)

  // Print summary
  console.log(`\n${'='.repeat(80)}`)
  console.log('📊 Sync Results:')
  console.log(`  ✅ Success: ${successCount}/${products.length}`)
  console.log(`  ❌ Failed: ${failCount}/${products.length}`)
  console.log(`  📈 Success Rate: ${((successCount / products.length) * 100).toFixed(1)}%`)

  const totalSnapshots = results.reduce((sum, r) => sum + r.aliasSnapshots + r.stockxSnapshots, 0)
  console.log(`  📦 Total Snapshots: ${totalSnapshots}`)

  if (successCount === products.length) {
    console.log(`\n🎉 100% SUCCESS RATE ACHIEVED!`)
    console.log(`   All ${products.length} products synced successfully`)
  } else {
    console.log(`\n⚠️  ${failCount} products failed`)
    console.log('\nFailed products:')
    results
      .filter((r) => !r.aliasSuccess && !r.stockxSuccess)
      .forEach((r) => {
        console.log(`  ❌ ${r.sku}`)
      })
  }
}

main().catch(console.error)
