#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function showStockXData() {
  console.log('🔍 STOCKX DATA (CORRECT PRICING)\n');
  console.log('='.repeat(80));

  const { data, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')
    .order('sku')
    .order('size_numeric')
    .limit(30);

  if (error || !data || data.length === 0) {
    console.error('Error:', error);
    return;
  }

  console.log(`\nTotal Records: ${data.length}\n`);

  console.log('STOCKX PRICING (showing first 30 records):\n');
  console.log('SKU          | Size | Region | Lowest Ask  | Highest Bid | Currency');
  console.log('-------------|------|--------|-------------|-------------|----------');

  data.forEach(row => {
    const currency = row.currency_code === 'GBP' ? '£' : 
                     row.currency_code === 'EUR' ? '€' : '$';
    
    // StockX stores values in cents, so divide by 100
    const ask = row.lowest_ask ? `${currency}${(row.lowest_ask / 100).toFixed(2)}` : 'NULL';
    const bid = row.highest_bid ? `${currency}${(row.highest_bid / 100).toFixed(2)}` : 'NULL';
    
    console.log(
      `${row.sku.padEnd(12)} | ${row.size_key.toString().padEnd(4)} | ${row.region_code.padEnd(6)} | ${ask.padEnd(11)} | ${bid.padEnd(11)} | ${row.currency_code}`
    );
  });

  console.log('\n' + '='.repeat(80));
  console.log('\nRAW VALUES CHECK:\n');
  
  const sample = data[0];
  console.log('Database value (lowest_ask):', sample.lowest_ask);
  console.log('Display value:', `£${(sample.lowest_ask / 100).toFixed(2)}`);
  console.log('\nRaw API response excerpt:');
  console.log(sample.raw_response_excerpt);
}

showStockXData();
