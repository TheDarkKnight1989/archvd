/**
 * Debug which rows have Unknown size and why
 */

import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010'

async function main() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  console.log('===============================================================================')
  console.log('Debug Unknown Sizes')
  console.log('===============================================================================\n')

  // Query rows with Unknown size
  const { data: unknownRows, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('sku', SKU)
    .eq('provider', 'stockx')
    .eq('size_key', 'Unknown')

  if (error) {
    console.error('❌ Error:', error.message)
    return
  }

  if (!unknownRows || unknownRows.length === 0) {
    console.log('✅ No Unknown rows found!')
    return
  }

  console.log(`Found ${unknownRows.length} rows with size_key = "Unknown":\n`)

  for (const row of unknownRows) {
    console.log('Row ID:', row.id)
    console.log('  Provider Variant ID:', row.provider_variant_id)
    console.log('  Provider Source:', row.provider_source)
    console.log('  Created At:', row.created_at)
    console.log('  Snapshot At:', row.snapshot_at)
    console.log('  Raw Response Excerpt:', JSON.stringify(row.raw_response_excerpt, null, 2))
    console.log()

    // Check if this variantId exists in stockx_variants
    if (row.provider_variant_id) {
      const { data: variant } = await supabase
        .from('stockx_variants')
        .select('*')
        .eq('stockx_variant_id', row.provider_variant_id)
        .single()

      if (variant) {
        console.log('  ✅ Variant found in stockx_variants:')
        console.log('     variant_value:', variant.variant_value)
        console.log('     size_display:', variant.size_display)
      } else {
        console.log('  ❌ Variant NOT found in stockx_variants')
      }
      console.log()
    }
  }
}

main().catch(console.error)
