#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function checkMismatch() {
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString()

  // Get recent syncs
  const { data: recentData } = await supabase
    .from('master_market_data')
    .select('sku, provider_product_id')
    .eq('provider', 'stockx')
    .gte('created_at', oneHourAgo)
    .limit(50)

  console.log('\n📋 Recent SKUs and Product IDs:\n')
  const uniqueCombos = new Map()
  recentData?.forEach(r => {
    const key = `${r.sku}|${r.provider_product_id?.slice(0, 36)}`
    uniqueCombos.set(key, { sku: r.sku, productId: r.provider_product_id })
  })

  uniqueCombos.forEach((value, i) => {
    console.log(`  SKU: ${value.sku?.padEnd(15)} | Product ID: ${value.productId?.slice(0, 36)}`)
  })

  // Now check what stockx_products has for one of the SKUs that succeeded in the log
  console.log('\n\n🔍 Checking stockx_products for log SKUs:\n')
  const logSkus = ['1201A906-001', 'AA2261-100', 'CP9654', 'M2002RDA', 'M990AB6']

  for (const sku of logSkus) {
    const { data } = await supabase
      .from('stockx_products')
      .select('stockx_product_id, style_id')
      .eq('style_id', sku)
      .single()

    console.log(`  ${sku.padEnd(15)}: ${data ? `Found (ID: ${data.stockx_product_id.slice(0, 20)}...)` : 'NOT FOUND'}`)
  }
}

checkMismatch()
