#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function checkRecent() {
  // Get all StockX products in master_market_data
  const { data: allSynced } = await supabase
    .from('master_market_data')
    .select('provider_product_id, sku, region_code, created_at')
    .eq('provider', 'stockx')
    .order('created_at', { ascending: false })

  const uniqueProducts = new Map<string, { sku: string; firstSeen: string; regions: Set<string> }>()

  allSynced?.forEach(record => {
    if (!uniqueProducts.has(record.provider_product_id)) {
      uniqueProducts.set(record.provider_product_id, {
        sku: record.sku || 'unknown',
        firstSeen: record.created_at,
        regions: new Set([record.region_code])
      })
    } else {
      uniqueProducts.get(record.provider_product_id)!.regions.add(record.region_code)
    }
  })

  console.log(`\n📊 StockX Products in master_market_data: ${uniqueProducts.size}\n`)

  // Get products synced in last 10 minutes
  const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString()
  const recentProducts = Array.from(uniqueProducts.entries())
    .filter(([_, data]) => data.firstSeen >= tenMinutesAgo)
    .sort((a, b) => b[1].firstSeen.localeCompare(a[1].firstSeen))

  console.log(`🕐 Recently synced (last 10 min): ${recentProducts.length}\n`)

  recentProducts.forEach(([productId, data], i) => {
    const regionsList = Array.from(data.regions).sort().join(', ')
    const timestamp = new Date(data.firstSeen).toLocaleTimeString()
    console.log(`  ${i + 1}. ${data.sku.padEnd(15)} | ${regionsList.padEnd(12)} | ${timestamp}`)
  })

  // Total count
  const { count: totalProducts } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true })

  console.log(`\n📦 Total: ${uniqueProducts.size}/${totalProducts} products synced`)
  console.log(`📊 Coverage: ${((uniqueProducts.size / (totalProducts || 1)) * 100).toFixed(1)}%\n`)
}

checkRecent()
