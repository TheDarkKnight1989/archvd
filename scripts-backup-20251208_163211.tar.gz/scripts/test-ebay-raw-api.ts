/**
 * Direct eBay API test - check raw results
 */

import 'dotenv/config'
import { EbayClient } from '../src/lib/services/ebay/client'

async function main() {
  const sku = process.argv[2] || 'DZ4137-700'

  console.log(`\n${'='.repeat(80)}`)
  console.log(`eBay Raw API Test - ${sku}`)
  console.log('='.repeat(80) + '\n')

  const client = new EbayClient()

  // Test with current filters: AG + conditions [1000, 1500, 1750]
  const result = await client.searchSold({
    query: sku,
    limit: 200, // Max eBay allows in one request
    conditionIds: [1000, 1500, 1750],
    qualifiedPrograms: ['AUTHENTICITY_GUARANTEE'],
    categoryIds: ['15709', '95672', '155194'], // Sneaker categories
    soldItemsOnly: true,
    fetchFullDetails: false,
  })

  console.log('API Response:')
  console.log('  Total fetched:', result.totalFetched)
  console.log('  Items returned:', result.items.length)
  console.log()

  if (result.items.length > 0) {
    // Count by condition
    const byCondition = result.items.reduce((acc, item) => {
      const cond = item.conditionId || 'unknown'
      acc[cond] = (acc[cond] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    console.log('Breakdown by condition:')
    Object.entries(byCondition).forEach(([cond, count]) => {
      const label =
        cond === '1000'
          ? 'NEW (1000)'
          : cond === '1500'
          ? 'NEW_WITH_DEFECTS (1500)'
          : cond === '1750'
          ? 'NEW_WITH_BOX (1750)'
          : cond
      console.log(`  ${label}: ${count}`)
    })
    console.log()

    // Show first 5 items
    console.log('First 5 items:')
    result.items.slice(0, 5).forEach((item, i) => {
      console.log(`\n${i + 1}. ${item.title.substring(0, 70)}...`)
      console.log(`   Price: ${item.currency} ${item.price}`)
      console.log(`   Condition: ${item.conditionId}`)
      console.log(`   Sold: ${item.soldAt}`)
    })
    console.log()

    // Date range
    const dates = result.items.map((item) => new Date(item.soldAt))
    const oldest = new Date(Math.min(...dates.map((d) => d.getTime())))
    const newest = new Date(Math.max(...dates.map((d) => d.getTime())))

    console.log('Date range:')
    console.log(`  Oldest: ${oldest.toLocaleDateString()}`)
    console.log(`  Newest: ${newest.toLocaleDateString()}`)
    console.log()
  }

  console.log('='.repeat(80) + '\n')
}

main().catch((err) => {
  console.error('\nError:', err.message)
  console.error(err)
  process.exit(1)
})
