#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function compareRegionalPrices() {
  console.log('💱 REGIONAL PRICE COMPARISON: EU vs UK\n');
  console.log('='.repeat(80));
  console.log('Product: M2002RDB (New Balance 2002R Protection Pack)\n');

  // Get recent data for both regions
  const { data, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'alias')
    .eq('sku', 'M2002RDB')
    .in('region_code', ['EU', 'UK'])
    .gte('snapshot_at', new Date(Date.now() - 60 * 60 * 1000).toISOString())
    .order('size_numeric')
    .order('region_code');

  if (error || !data || data.length === 0) {
    console.error('Error fetching data:', error);
    return;
  }

  console.log('SIDE-BY-SIDE COMPARISON (Selected Sizes):\n');
  console.log('Size | Type         | EU (EUR)                    | UK (GBP)                    ');
  console.log('-----|--------------|-----------------------------|-----------------------------|');

  // Group by size
  const bySizeAndType = data.reduce((acc, row) => {
    const key = `${row.size_key}_${row.is_consigned ? 'C' : 'NC'}`;
    if (!acc[key]) acc[key] = {};
    acc[key][row.region_code] = row;
    return acc;
  }, {} as Record<string, any>);

  // Show common sizes
  const commonSizes = ['8', '9', '10', '10.5', '11', '12'];
  
  commonSizes.forEach(size => {
    // Non-consigned
    const ncKey = `${size}_NC`;
    if (bySizeAndType[ncKey]) {
      const eu = bySizeAndType[ncKey]['EU'];
      const uk = bySizeAndType[ncKey]['UK'];
      
      if (eu && uk) {
        const euAsk = eu.lowest_ask ? `€${(eu.lowest_ask/100).toFixed(2)}` : 'N/A';
        const euBid = eu.highest_bid ? `€${(eu.highest_bid/100).toFixed(2)}` : 'N/A';
        const ukAsk = uk.lowest_ask ? `£${(uk.lowest_ask/100).toFixed(2)}` : 'N/A';
        const ukBid = uk.highest_bid ? `£${(uk.highest_bid/100).toFixed(2)}` : 'N/A';
        
        console.log(
          `${size.padEnd(4)} | Regular      | Ask: ${euAsk.padEnd(9)} Bid: ${euBid.padEnd(9)} | Ask: ${ukAsk.padEnd(9)} Bid: ${ukBid.padEnd(9)}`
        );
      }
    }

    // Consigned
    const cKey = `${size}_C`;
    if (bySizeAndType[cKey]) {
      const eu = bySizeAndType[cKey]['EU'];
      const uk = bySizeAndType[cKey]['UK'];
      
      if (eu && uk) {
        const euAsk = eu.lowest_ask ? `€${(eu.lowest_ask/100).toFixed(2)}` : 'N/A';
        const euBid = eu.highest_bid ? `€${(eu.highest_bid/100).toFixed(2)}` : 'N/A';
        const ukAsk = uk.lowest_ask ? `£${(uk.lowest_ask/100).toFixed(2)}` : 'N/A';
        const ukBid = uk.highest_bid ? `£${(uk.highest_bid/100).toFixed(2)}` : 'N/A';
        
        console.log(
          `     | Consigned    | Ask: ${euAsk.padEnd(9)} Bid: ${euBid.padEnd(9)} | Ask: ${ukAsk.padEnd(9)} Bid: ${ukBid.padEnd(9)}`
        );
      }
    }
    console.log('-----|--------------|-----------------------------|-----------------------------|');
  });

  console.log('\n' + '='.repeat(80));
  console.log('\nDETAILED VIEW: Size 10 Across Both Regions\n');

  const size10 = data.filter(r => r.size_key === '10');
  
  size10.forEach(row => {
    console.log(`${row.region_code} | ${row.is_consigned ? 'Consigned' : 'Regular  '} | ${row.currency_code}`);
    console.log(`  Lowest Ask:     ${row.lowest_ask ? `${row.currency_code === 'EUR' ? '€' : '£'}${(row.lowest_ask/100).toFixed(2)}` : 'NULL'}`);
    console.log(`  Highest Bid:    ${row.highest_bid ? `${row.currency_code === 'EUR' ? '€' : '£'}${(row.highest_bid/100).toFixed(2)}` : 'NULL'}`);
    console.log(`  Last Sale:      ${row.last_sale_price ? `${row.currency_code === 'EUR' ? '€' : '£'}${(row.last_sale_price/100).toFixed(2)}` : 'NULL'}`);
    console.log(`  Spread:         ${row.spread_percentage ? `${row.spread_percentage.toFixed(1)}%` : 'N/A'}`);
    console.log(`  Sales (72h):    ${row.sales_last_72h ?? 'NULL'}`);
    console.log('');
  });

  console.log('='.repeat(80));
}

compareRegionalPrices();
