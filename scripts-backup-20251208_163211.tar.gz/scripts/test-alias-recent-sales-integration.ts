/**
 * Test Alias Recent Sales integration
 * Verifies sales_last_72h data is fetched and stored correctly
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { syncAliasToMasterMarketData } from '@/lib/services/alias/sync'
import { createClient } from '@supabase/supabase-js'

const SKU = 'DZ5485-410' // Jordan 4 Craft (popular product with sales)

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS RECENT SALES INTEGRATION TEST')
  console.log('SKU:', SKU)
  console.log('Feature Flag:', process.env.ALIAS_RECENT_SALES_ENABLED)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  if (process.env.ALIAS_RECENT_SALES_ENABLED !== 'true') {
    console.log('❌ ALIAS_RECENT_SALES_ENABLED is not set to "true"')
    console.log('   Current value:', process.env.ALIAS_RECENT_SALES_ENABLED)
    console.log('   Please set: ALIAS_RECENT_SALES_ENABLED=true')
    process.exit(1)
  }

  const client = createAliasClient()
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  // Search for product
  console.log('Step 1: Searching for product...')
  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const product = searchResults.catalog_items[0]

  console.log(`Found: ${product.name}`)
  console.log(`Catalog ID: ${product.catalog_id}\n`)

  // Check sales_last_72h BEFORE sync
  console.log('Step 2: Checking sales_last_72h BEFORE sync...')
  const { data: beforeData } = await supabase
    .from('master_market_data')
    .select('size_key, sales_last_72h')
    .eq('sku', SKU)
    .eq('provider', 'alias')
    .order('size_key')

  const beforeCount = beforeData?.filter(row => row.sales_last_72h !== null).length || 0
  console.log(`  Rows with sales_last_72h: ${beforeCount} / ${beforeData?.length || 0}`)
  console.log()

  // Run sync with recent sales enabled
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('Step 3: Running sync (with recent sales enabled)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const syncResult = await syncAliasToMasterMarketData(client, product.catalog_id, {
    sku: SKU,
  })

  console.log('\nSync Result:')
  console.log(JSON.stringify(syncResult, null, 2))
  console.log()

  if (!syncResult.success) {
    console.error('❌ SYNC FAILED:', syncResult.error)
    process.exit(1)
  }

  // Check sales_last_72h AFTER sync
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('Step 4: Verifying sales_last_72h AFTER sync')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const { data: afterData } = await supabase
    .from('master_market_data')
    .select('size_key, sales_last_72h, lowest_ask, highest_bid')
    .eq('sku', SKU)
    .eq('provider', 'alias')
    .not('sales_last_72h', 'is', null)
    .order('size_key')

  if (!afterData || afterData.length === 0) {
    console.log('❌ NO sales_last_72h DATA FOUND!')
    console.log('   This could mean:')
    console.log('   - No recent sales for this product')
    console.log('   - API returned empty sales data')
    console.log('   - Product has low trading activity')
    console.log()
  } else {
    console.log(`✅ Found ${afterData.length} sizes with sales_last_72h data\n`)

    // Show first 10 sizes
    console.log('Sample data (first 10 sizes):\n')
    afterData.slice(0, 10).forEach(row => {
      console.log(`  Size ${row.size_key.padEnd(8)} | Sales: ${String(row.sales_last_72h).padStart(3)} | Ask: $${row.lowest_ask} | Bid: $${row.highest_bid}`)
    })
    console.log()

    // Stats
    const totalSales = afterData.reduce((sum, row) => sum + (row.sales_last_72h || 0), 0)
    const avgSales = totalSales / afterData.length
    const maxSales = Math.max(...afterData.map(row => row.sales_last_72h || 0))

    console.log('═══════════════════════════════════════════════════════════════════════════')
    console.log('SUMMARY')
    console.log('═══════════════════════════════════════════════════════════════════════════\n')

    console.log('✅ Recent sales integration WORKING!')
    console.log(`   - ${afterData.length} sizes have sales_last_72h data`)
    console.log(`   - ${totalSales} total sales in last 72h`)
    console.log(`   - Avg ${avgSales.toFixed(1)} sales per size`)
    console.log(`   - Max ${maxSales} sales for a single size`)
    console.log()
    console.log('✅ sales_last_72h column is being populated!')
    console.log()
  }
}

main().catch(console.error)
