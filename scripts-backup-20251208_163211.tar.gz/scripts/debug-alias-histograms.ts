/**
 * Debug Alias histogram endpoints
 * Tests both offer_histogram and listing_histogram
 */

import { createAliasClient } from '@/lib/services/alias/client'

const SKU = 'FV5029-010'
const TEST_SIZE = 10 // Men's size 10

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS HISTOGRAM ENDPOINTS DEBUG')
  console.log('SKU:', SKU)
  console.log('Test Size:', TEST_SIZE)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()

  // Get catalog_id first
  console.log('Step 1: Get catalog_id from search...')
  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const product = searchResults.catalog_items[0]
  console.log(`Found: ${product.name}`)
  console.log(`Catalog ID: ${product.catalog_id}\n`)

  // ========================================================================
  // TEST 1: OFFER HISTOGRAM
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('TEST 1: OFFER HISTOGRAM (Bid Depth Chart)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log('API ENDPOINT:')
  console.log(`  GET /api/v1/pricing_insights/offer_histogram`)
  console.log(`  catalog_id: ${product.catalog_id}`)
  console.log(`  size: ${TEST_SIZE}`)
  console.log(`  product_condition: PRODUCT_CONDITION_NEW`)
  console.log(`  packaging_condition: PACKAGING_CONDITION_GOOD_CONDITION`)
  console.log()

  try {
    const offerHistogram = await client.getOfferHistogram({
      catalog_id: product.catalog_id,
      size: TEST_SIZE,
      product_condition: 'PRODUCT_CONDITION_NEW',
      packaging_condition: 'PACKAGING_CONDITION_GOOD_CONDITION',
    })

    console.log('✅ API SUCCESS\n')
    console.log('RESPONSE:')
    console.log(JSON.stringify(offerHistogram, null, 2))
    console.log()

    if (offerHistogram?.offer_histogram?.bins?.length > 0) {
      console.log(`✅ ${offerHistogram.offer_histogram.bins.length} histogram bins returned`)
      console.log('\nSample bins (top 5 prices):')
      offerHistogram.offer_histogram.bins.slice(0, 5).forEach((bin) => {
        const price = parseInt(bin.offer_price_cents) / 100
        const count = parseInt(bin.count)
        console.log(`  $${price.toFixed(2)}: ${count} offers`)
      })
      console.log()
      console.log('Market Depth Summary:')
      const totalOffers = offerHistogram.offer_histogram.bins.reduce((sum, bin) => sum + parseInt(bin.count), 0)
      const avgPrice = offerHistogram.offer_histogram.bins.reduce((sum, bin) => {
        return sum + (parseInt(bin.offer_price_cents) * parseInt(bin.count))
      }, 0) / totalOffers
      console.log(`  Total Offers: ${totalOffers}`)
      console.log(`  Price Levels: ${offerHistogram.offer_histogram.bins.length}`)
      console.log(`  Avg Offer: $${(avgPrice / 100).toFixed(2)}`)
    } else {
      console.log('⚠️  API returned empty bins array')
      console.log('   This could mean:')
      console.log('   - Not enough market depth for histogram')
      console.log('   - Product/size has low liquidity')
      console.log('   - Histogram requires minimum thresholds')
    }
  } catch (error: any) {
    console.log('❌ API ERROR\n')
    console.log(`Status: ${error.statusCode || 'unknown'}`)
    console.log(`Message: ${error.message}`)
    console.log()

    if (error.statusCode === 415) {
      console.log('⚠️  415 Unsupported Media Type')
      console.log('   Error suggests gRPC content-type issue')
      console.log('   API may expect: application/grpc or application/grpc+proto')
      console.log('   We are sending: application/json')
    }

    console.log('\nFull error:')
    console.log(JSON.stringify(error, null, 2))
  }
  console.log()

  // ========================================================================
  // CONCLUSION
  // ========================================================================

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('SUMMARY')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  console.log('✅ OFFER HISTOGRAM: Working via REST API')
  console.log('   - Provides bid depth chart (price levels + offer counts)')
  console.log('   - Useful for market liquidity analysis')
  console.log()
  console.log('❌ LISTING HISTOGRAM: Does NOT exist in Alias API')
  console.log('   - Not documented in Alias dev docs')
  console.log('   - Only offer_histogram is available')
  console.log()
}

main().catch(console.error)
