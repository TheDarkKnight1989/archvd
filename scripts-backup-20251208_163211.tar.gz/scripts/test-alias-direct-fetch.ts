#!/usr/bin/env npx tsx
/**
 * Test Alias API with direct fetch (no client wrapper)
 * Tests different Content-Type configurations
 */

async function testDirectFetch() {
  const ALIAS_PAT = process.env.ALIAS_PAT
  const BASE_URL = 'https://api.alias.org/api/v1'

  if (!ALIAS_PAT) {
    console.error('❌ ALIAS_PAT not set')
    return
  }

  console.log('🧪 Testing Alias API Direct Fetch\n')

  // Test 1: No Content-Type header (like add-by-sku route)
  console.log('Test 1: NO Content-Type header')
  try {
    const response = await fetch(`${BASE_URL}/regions`, {
      headers: {
        'Authorization': `Bearer ${ALIAS_PAT}`,
      },
    })

    console.log(`  Status: ${response.status}`)
    console.log(`  Content-Type: ${response.headers.get('content-type')}`)

    if (response.ok) {
      const data = await response.json()
      console.log(`  ✅ SUCCESS - Found ${data.regions?.length || 0} regions`)
    } else {
      const text = await response.text()
      console.log(`  ❌ FAILED - ${text}`)
    }
  } catch (error: any) {
    console.log(`  ❌ ERROR: ${error.message}`)
  }

  // Test 2: With application/json
  console.log('\nTest 2: Content-Type: application/json')
  try {
    const response = await fetch(`${BASE_URL}/regions`, {
      headers: {
        'Authorization': `Bearer ${ALIAS_PAT}`,
        'Content-Type': 'application/json',
      },
    })

    console.log(`  Status: ${response.status}`)
    if (response.ok) {
      const data = await response.json()
      console.log(`  ✅ SUCCESS - Found ${data.regions?.length || 0} regions`)
    } else {
      const text = await response.text()
      console.log(`  ❌ FAILED - ${text}`)
    }
  } catch (error: any) {
    console.log(`  ❌ ERROR: ${error.message}`)
  }

  // Test 3: With application/grpc-web+json
  console.log('\nTest 3: Content-Type: application/grpc-web+json')
  try {
    const response = await fetch(`${BASE_URL}/regions`, {
      headers: {
        'Authorization': `Bearer ${ALIAS_PAT}`,
        'Content-Type': 'application/grpc-web+json',
      },
    })

    console.log(`  Status: ${response.status}`)
    if (response.ok) {
      const data = await response.json()
      console.log(`  ✅ SUCCESS - Found ${data.regions?.length || 0} regions`)
    } else {
      const text = await response.text()
      console.log(`  ❌ FAILED - ${text}`)
    }
  } catch (error: any) {
    console.log(`  ❌ ERROR: ${error.message}`)
  }

  // Test 4: Test catalog endpoint (known to work in add-by-sku)
  console.log('\nTest 4: Catalog endpoint (NO Content-Type)')
  const testCatalogId = '2002r-protection-pack-phantom-m2002rdb'
  try {
    const response = await fetch(`${BASE_URL}/catalog/${testCatalogId}`, {
      headers: {
        'Authorization': `Bearer ${ALIAS_PAT}`,
      },
    })

    console.log(`  Status: ${response.status}`)
    if (response.ok) {
      const data = await response.json()
      console.log(`  ✅ SUCCESS - Found product: ${data.name}`)
    } else {
      const text = await response.text()
      console.log(`  ❌ FAILED - ${text}`)
    }
  } catch (error: any) {
    console.log(`  ❌ ERROR: ${error.message}`)
  }
}

testDirectFetch().catch(console.error)
