#!/bin/bash

echo "Monitoring sync progress..."
echo ""

while true; do
  # Get latest product number
  LATEST=$(grep -E "^\[" /tmp/simple-uk-sync.log | tail -1)

  # Count successes and failures
  SUCCESS=$(grep -c "✅ Success" /tmp/simple-uk-sync.log)
  FAILED=$(grep -c "❌ Failed" /tmp/simple-uk-sync.log)
  TOTAL=$((SUCCESS + FAILED))

  # Clear and show update
  clear
  echo "═══════════════════════════════════════════════════════"
  echo "StockX UK-Only Sync Progress"
  echo "═══════════════════════════════════════════════════════"
  echo ""
  echo "Latest: $LATEST"
  echo ""
  echo "Progress: $TOTAL/125 products"
  echo "Success:  $SUCCESS"
  echo "Failed:   $FAILED"
  echo ""

  if [ $TOTAL -gt 0 ]; then
    PERCENT=$(echo "scale=1; $SUCCESS * 100 / $TOTAL" | bc)
    echo "Success rate: ${PERCENT}%"
  fi

  # Check if complete
  if grep -q "FINAL RESULTS" /tmp/simple-uk-sync.log; then
    echo ""
    echo "═══════════════════════════════════════════════════════"
    echo "SYNC COMPLETE!"
    echo "═══════════════════════════════════════════════════════"
    echo ""
    grep -A 10 "FINAL RESULTS" /tmp/simple-uk-sync.log
    break
  fi

  echo ""
  echo "Updating every 10 seconds... (Ctrl+C to stop monitoring)"
  sleep 10
done
