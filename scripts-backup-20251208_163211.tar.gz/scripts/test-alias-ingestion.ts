/**
 * Test Alias UK ingestion for a known working SKU
 */

import { createClient } from '@supabase/supabase-js'
import { AliasClient } from '@/lib/services/alias/client'
import { ingestAliasAvailabilities } from '@/lib/services/ingestion/alias-mapper'

const TEST_SKU = 'AA2261-100' // Mars Yard - known to exist on Alias
const ALIAS_CATALOG_ID = 'tom-sachs-x-nikecraft-mars-yard-2-0-aa2261-100'
const REGION_ID = '3' // UK

async function main() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  console.log('================================================================================')
  console.log('Alias UK Ingestion Test')
  console.log('================================================================================\n')
  console.log('SKU:', TEST_SKU)
  console.log('Alias Catalog ID:', ALIAS_CATALOG_ID)
  console.log('Region: UK (region_id=3)')
  console.log()

  // Fetch availability from Alias
  const pat = process.env.ALIAS_PAT
  if (!pat) {
    throw new Error('ALIAS_PAT not found in environment')
  }

  const aliasClient = new AliasClient(pat)
  console.log('🔄 Fetching Alias UK availability data...')

  try {
    const availabilities = await aliasClient.listPricingInsights(
      ALIAS_CATALOG_ID,
      REGION_ID,
      undefined // include both consigned and non-consigned
    )

    console.log('✅ Fetched', availabilities.variants?.length || 0, 'variants from Alias')

    if (!availabilities.variants || availabilities.variants.length === 0) {
      console.log('❌ No variants returned from Alias')
      return
    }

    console.log('\n📊 Sample variant:')
    console.log(JSON.stringify(availabilities.variants[0], null, 2).substring(0, 500))

    // Ingest to master_market_data
    console.log('\n🔄 Ingesting to master_market_data...')
    await ingestAliasAvailabilities(
      null as any, // No raw snapshot for this test
      availabilities,
      {
        catalogId: ALIAS_CATALOG_ID,
        regionId: REGION_ID,
        sku: TEST_SKU,
        snapshotAt: new Date(),
        includeConsigned: true,
      }
    )

    console.log('✅ Ingestion complete')

    // Query back to verify
    console.log('\n🔍 Querying master_market_data...')
    const { data, error } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('sku', TEST_SKU)
      .eq('provider', 'alias')
      .eq('currency_code', 'GBP')
      .eq('region_code', 'UK')
      .order('size_numeric', { ascending: true })

    if (error) {
      console.error('❌ Query error:', error.message)
      return
    }

    console.log(`✅ Found ${data.length} rows for ${TEST_SKU} (Alias UK)`)

    if (data.length > 0) {
      console.log('\n📦 First 3 sizes:')
      for (const row of data.slice(0, 3)) {
        console.log(`   Size ${row.size_key}: Ask £${row.lowest_ask}, Bid £${row.highest_bid}`)
      }
    }

    console.log('\n🎉 Test complete!')

  } catch (error: any) {
    console.error('❌ Error:', error.message)
    throw error
  }
}

main().catch(console.error)
