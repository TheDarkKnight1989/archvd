#!/usr/bin/env npx tsx
/**
 * Full Multi-Region Sync Test with Gender Filtering
 * Tests all 3 regions and analyzes NULL pricing data
 */

import { createAliasClient } from '@/lib/services/alias/client';
import { syncAliasProductMultiRegion } from '@/lib/services/alias/sync';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function main() {
  console.log('🚀 Full Multi-Region Sync Test\n');
  console.log('Testing: M2002RDB (New Balance 2002R Protection Pack Phantom)');
  console.log('Regions: US, EU, UK');
  console.log('Feature: Gender-based size filtering (3.5-16 unisex)\n');

  const testCatalogId = '2002r-protection-pack-phantom-m2002rdb';
  const testSku = 'M2002RDB';

  // ========================================================================
  // Step 1: Delete ALL old data
  // ========================================================================

  console.log('1️⃣  Deleting ALL old Alias data for M2002RDB...');
  const { data: oldData, error: countError } = await supabase
    .from('master_market_data')
    .select('id', { count: 'exact', head: true })
    .eq('provider', 'alias')
    .eq('sku', testSku);

  const oldCount = oldData?.length || 0;
  console.log(`   Found ${oldCount} existing records`);

  const { error: deleteError } = await supabase
    .from('master_market_data')
    .delete()
    .eq('provider', 'alias')
    .eq('sku', testSku);

  if (deleteError) {
    console.error(`   ❌ Delete failed: ${deleteError.message}`);
    return;
  }
  console.log(`   ✅ Deleted all old records\n`);

  // ========================================================================
  // Step 2: Run full multi-region sync
  // ========================================================================

  console.log('2️⃣  Running multi-region sync (US, EU, UK)...\n');
  const aliasClient = createAliasClient();

  const startTime = Date.now();
  const result = await syncAliasProductMultiRegion(aliasClient, testCatalogId, {
    sku: testSku,
    userRegion: 'UK', // Primary region
    syncSecondaryRegions: true, // Sync all regions
  });
  const duration = Date.now() - startTime;

  console.log(`\n⏱️  Total sync time: ${(duration / 1000).toFixed(2)}s\n`);

  if (!result.success) {
    console.error(`❌ Sync failed: ${result.primaryResult.error}`);
    return;
  }

  console.log('✅ Sync completed successfully!');
  console.log(`   Total variants ingested: ${result.totalVariantsIngested}`);
  console.log(`   Primary (UK): ${result.primaryResult.variantsIngested} variants`);
  Object.entries(result.secondaryResults).forEach(([region, res]) => {
    console.log(`   Secondary (${region}): ${res.variantsIngested} variants`);
  });

  // Wait for all writes to complete
  console.log('\n⏳ Waiting for writes to complete...');
  await new Promise(resolve => setTimeout(resolve, 3000));

  // ========================================================================
  // Step 3: Analyze data quality across all regions
  // ========================================================================

  console.log('\n3️⃣  Analyzing data quality across all regions...\n');

  const { data: allData, error: queryError } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'alias')
    .eq('sku', testSku)
    .gte('snapshot_at', new Date(Date.now() - 5 * 60 * 1000).toISOString())
    .order('region_code')
    .order('size_key')
    .order('is_consigned');

  if (queryError) {
    console.error(`❌ Query failed: ${queryError.message}`);
    return;
  }

  console.log(`📊 Total Records: ${allData.length}\n`);

  // Group by region
  const byRegion = allData.reduce((acc, row) => {
    if (!acc[row.region_code]) acc[row.region_code] = [];
    acc[row.region_code].push(row);
    return acc;
  }, {} as Record<string, any[]>);

  // Analyze each region
  console.log('═'.repeat(80));
  console.log('REGIONAL BREAKDOWN\n');

  Object.entries(byRegion).forEach(([region, records]) => {
    const consigned = records.filter(r => r.is_consigned);
    const nonConsigned = records.filter(r => !r.is_consigned);
    const uniqueSizes = new Set(records.map(r => r.size_key));

    const withPricing = records.filter(r =>
      r.lowest_ask !== null || r.highest_bid !== null || r.last_sale_price !== null
    );
    const withoutPricing = records.length - withPricing.length;

    console.log(`${region} Region:`);
    console.log(`  Total records: ${records.length}`);
    console.log(`  Consigned: ${consigned.length} | Non-consigned: ${nonConsigned.length}`);
    console.log(`  Unique sizes: ${uniqueSizes.size}`);
    console.log(`  With pricing: ${withPricing.length}/${records.length} (${Math.round(withPricing.length / records.length * 100)}%)`);
    console.log(`  WITHOUT pricing: ${withoutPricing.length}/${records.length} (${Math.round(withoutPricing.length / records.length * 100)}%) ${withoutPricing.length > 0 ? '⚠️' : '✅'}`);
    console.log('');
  });

  // ========================================================================
  // Step 4: Analyze NULL pricing across all data
  // ========================================================================

  console.log('═'.repeat(80));
  console.log('PRICING DATA QUALITY\n');

  const totalRecords = allData.length;
  const withAnyPrice = allData.filter(r =>
    r.lowest_ask !== null || r.highest_bid !== null || r.last_sale_price !== null
  ).length;
  const withoutAnyPrice = totalRecords - withAnyPrice;

  const withLowestAsk = allData.filter(r => r.lowest_ask !== null).length;
  const withHighestBid = allData.filter(r => r.highest_bid !== null).length;
  const withLastSale = allData.filter(r => r.last_sale_price !== null).length;

  console.log('Overall Pricing Coverage:');
  console.log(`  Records with ANY price: ${withAnyPrice}/${totalRecords} (${Math.round(withAnyPrice / totalRecords * 100)}%)`);
  console.log(`  Records with NO prices: ${withoutAnyPrice}/${totalRecords} (${Math.round(withoutAnyPrice / totalRecords * 100)}%)\n`);

  console.log('By Price Field:');
  console.log(`  Lowest Ask:   ${withLowestAsk}/${totalRecords} (${Math.round(withLowestAsk / totalRecords * 100)}%)`);
  console.log(`  Highest Bid:  ${withHighestBid}/${totalRecords} (${Math.round(withHighestBid / totalRecords * 100)}%)`);
  console.log(`  Last Sale:    ${withLastSale}/${totalRecords} (${Math.round(withLastSale / totalRecords * 100)}%)\n`);

  // ========================================================================
  // Step 5: Show which sizes have NULL pricing
  // ========================================================================

  if (withoutAnyPrice > 0) {
    console.log('═'.repeat(80));
    console.log('SIZES WITHOUT PRICING DATA\n');

    const sizesWithoutPricing = allData
      .filter(r => r.lowest_ask === null && r.highest_bid === null && r.last_sale_price === null)
      .reduce((acc, r) => {
        const key = `${r.size_key}`;
        if (!acc[key]) acc[key] = [];
        acc[key].push(r.region_code);
        return acc;
      }, {} as Record<string, string[]>);

    Object.entries(sizesWithoutPricing)
      .sort(([a], [b]) => parseFloat(a) - parseFloat(b))
      .forEach(([size, regions]) => {
        console.log(`  Size ${size.padEnd(4)}: ${regions.join(', ')} (${regions.length} regions)`);
      });
    console.log('');
  }

  // ========================================================================
  // Step 6: Size range verification
  // ========================================================================

  console.log('═'.repeat(80));
  console.log('SIZE RANGE VERIFICATION\n');

  const allSizes = Array.from(new Set(allData.map(r => parseFloat(r.size_key))))
    .sort((a, b) => a - b);

  console.log(`Sizes stored: ${allSizes.length} unique`);
  console.log(`Range: ${allSizes[0]} - ${allSizes[allSizes.length - 1]}`);
  console.log(`Expected: 3.5 - 16 (unisex)\n`);

  const invalidSizes = allSizes.filter(s => s < 3.5 || s > 16);
  if (invalidSizes.length > 0) {
    console.log(`⚠️  Found ${invalidSizes.length} INVALID sizes:`);
    console.log(`   ${invalidSizes.join(', ')}`);
  } else {
    console.log(`✅ All sizes within valid range (3.5-16)`);
  }

  // ========================================================================
  // Final verdict
  // ========================================================================

  console.log('\n' + '═'.repeat(80));
  console.log('FINAL ASSESSMENT\n');

  const pricingCoverage = Math.round(withAnyPrice / totalRecords * 100);

  console.log(`⏱️  Sync Duration: ${(duration / 1000).toFixed(2)}s`);
  console.log(`📦 Total Records: ${totalRecords}`);
  console.log(`✅ Valid Size Range: ${invalidSizes.length === 0 ? 'YES' : 'NO'}`);
  console.log(`💰 Pricing Coverage: ${pricingCoverage}%`);
  console.log(`🗑️  NULL Records: ${withoutAnyPrice} (${Math.round(withoutAnyPrice / totalRecords * 100)}%)\n`);

  if (invalidSizes.length === 0 && pricingCoverage >= 90) {
    console.log('🎉 EXCELLENT: Gender filtering working perfectly!');
    console.log('   - All sizes in valid range');
    console.log(`   - ${pricingCoverage}% pricing coverage`);
  } else if (invalidSizes.length === 0 && pricingCoverage >= 70) {
    console.log('✅ GOOD: Gender filtering working well');
    console.log('   - All sizes in valid range');
    console.log(`   - ${pricingCoverage}% pricing coverage (some rare sizes lack data)`);
  } else {
    console.log('⚠️  NEEDS REVIEW:');
    if (invalidSizes.length > 0) console.log(`   - Found ${invalidSizes.length} invalid sizes`);
    if (pricingCoverage < 70) console.log(`   - Low pricing coverage: ${pricingCoverage}%`);
  }
  console.log('═'.repeat(80));
}

main().catch(console.error);
