/**
 * Check RAW StockX API response to see what fields we're actually getting
 */

import { StockxCatalogService } from '@/lib/services/stockx/catalog'

const SKU = 'U992AC1'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('RAW StockX API Response Inspector')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const catalogService = new StockxCatalogService(undefined)

  // Search for product
  const products = await catalogService.searchProducts(SKU, { limit: 5 })
  const product = products.find(p => p.styleId?.toUpperCase() === SKU.toUpperCase()) || products[0]

  console.log(`Product: ${product.productName}`)
  console.log(`Product ID: ${product.productId}\n`)

  // Fetch market data
  const client = (catalogService as any).client
  const rawMarketData = await client.request(
    `/v2/catalog/products/${product.productId}/market-data?currencyCode=GBP`
  )

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('COMPLETE RAW RESPONSE FOR FIRST VARIANT')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const firstVariant = rawMarketData[0]

  console.log(JSON.stringify(firstVariant, null, 2))
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('FIELD ANALYSIS')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  console.log('Top-level fields present:')
  const topLevelFields = Object.keys(firstVariant)
  for (const field of topLevelFields.sort()) {
    const value = firstVariant[field]
    const type = typeof value
    const isNull = value === null
    const isUndefined = value === undefined

    let display = ''
    if (isNull) {
      display = 'null'
    } else if (isUndefined) {
      display = 'undefined'
    } else if (type === 'object') {
      display = `{...} (${Object.keys(value).length} fields)`
    } else {
      display = String(value).substring(0, 50)
    }

    console.log(`  ${field}: ${type} = ${display}`)
  }
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('CHECKING FOR VOLATILITY-RELATED FIELDS')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const fieldsToCheck = [
    'volatility',
    'pricePremium',
    'averagePrice',
    'averageDeadstockPrice',
    'lowestAskAmount',
    'highestBidAmount',
    'lastSaleAmount',
  ]

  for (const field of fieldsToCheck) {
    if (field in firstVariant) {
      console.log(`✅ ${field}: ${firstVariant[field] ?? 'NULL'}`)
    } else {
      console.log(`❌ ${field}: FIELD DOES NOT EXIST`)
    }
  }
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('CHECKING ALL VARIANTS')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  let hasVolatility = false
  let hasPricePremium = false
  let hasAveragePrice = false

  for (const variant of rawMarketData) {
    if (variant.volatility !== null && variant.volatility !== undefined) {
      hasVolatility = true
    }
    if (variant.pricePremium !== null && variant.pricePremium !== undefined) {
      hasPricePremium = true
    }
    if (variant.averagePrice !== null && variant.averagePrice !== undefined) {
      hasAveragePrice = true
    }
  }

  console.log(`Total variants checked: ${rawMarketData.length}`)
  console.log(`Variants with volatility: ${hasVolatility ? 'YES' : 'NO'}`)
  console.log(`Variants with pricePremium: ${hasPricePremium ? 'YES' : 'NO'}`)
  console.log(`Variants with averagePrice: ${hasAveragePrice ? 'YES' : 'NO'}`)
  console.log()

  if (!hasVolatility && !hasPricePremium && !hasAveragePrice) {
    console.log('⚠️  CONCLUSION: StockX is NOT returning these fields for this product')
    console.log('   This could mean:')
    console.log('   1. Product too new/not enough data for analytics')
    console.log('   2. StockX changed their API response format')
    console.log('   3. These fields only available in certain API endpoints/currencies')
    console.log()
    console.log('   Let\'s test with a more popular product...')
  } else {
    console.log('✅ CONCLUSION: StockX IS returning these fields!')
    console.log('   Our mapper SHOULD be capturing them correctly.')
  }
  console.log()
}

main().catch(console.error)
