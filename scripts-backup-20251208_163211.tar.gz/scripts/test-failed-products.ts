#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js'
import { getStockxClient } from '@/lib/services/stockx/client'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function test() {
  // Get a product that's NOT in master_market_data (i.e., one that failed)
  const { data: synced } = await supabase
    .from('master_market_data')
    .select('provider_product_id')
    .eq('provider', 'stockx')

  const syncedIds = new Set(synced?.map(r => r.provider_product_id))

  const { data: allProducts } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id')

  const failedProducts = allProducts?.filter(p => !syncedIds.has(p.stockx_product_id)) || []

  console.log(`\n📊 Testing FAILED products (${failedProducts.length} total)\n`)

  const client = getStockxClient()

  // Test first 5 failed products
  for (let i = 0; i < Math.min(5, failedProducts.length); i++) {
    const product = failedProducts[i]
    console.log(`\n${i + 1}. Testing ${product.style_id} (${product.stockx_product_id.substring(0, 20)}...)`)

    try {
      const result = await client.request(`/v2/catalog/products/${product.stockx_product_id}/market-data?currencyCode=USD`)
      console.log(`   ✅ SUCCESS - Found ${Array.isArray(result) ? result.length : 0} variants`)
    } catch (e: any) {
      console.log(`   ❌ FAILED: ${e.message}`)
      if (e.message?.includes('404')) {
        console.log(`   ⚠️  Product ID not found in StockX - INVALID ID`)
      } else if (e.message?.includes('500')) {
        console.log(`   ⚠️  StockX server error - API issue`)
      } else if (e.message?.includes('401')) {
        console.log(`   ⚠️  Authentication error`)
      }
    }

    // Small delay between requests
    await new Promise(resolve => setTimeout(resolve, 500))
  }
}

test()
