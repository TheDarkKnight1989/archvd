#!/usr/bin/env tsx

/**
 * Check the Nardwuar items (II1493-600) that were just added
 * Verify which fields are populated vs missing
 */

import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

const TEST_USER_ID = 'fbcde760-820b-4eaf-949f-534a8130d44b'
const NARDWUAR_SKU = 'II1493-600'

async function checkNardwuarItems() {
  console.log('\n🔍 CHECKING NARDWUAR ITEMS (SKU: II1493-600)')
  console.log('='.repeat(80))

  // Get all Nardwuar items
  const { data: items, error: itemsError } = await supabase
    .from('inventory')
    .select('*')
    .eq('user_id', TEST_USER_ID)
    .ilike('sku', `%${NARDWUAR_SKU}%`)
    .order('created_at', { ascending: false })

  if (itemsError) {
    console.error('❌ Error fetching items:', itemsError)
    return
  }

  if (!items || items.length === 0) {
    console.log('❌ NO ITEMS FOUND - items were not created')
    return
  }

  console.log(`\n📦 Found ${items.length} item(s)\n`)

  // Check each item
  for (let i = 0; i < items.length; i++) {
    const inventory = items[i]

    console.log(`\n${'='.repeat(80)}`)
    console.log(`ITEM ${i + 1} of ${items.length}`)
    console.log('='.repeat(80))

    console.log('\n📊 INVENTORY TABLE:')
    console.log('─'.repeat(80))
    console.log('  id:', inventory.id)
    console.log('  catalog_id:', inventory.catalog_id, inventory.catalog_id ? '✅' : '❌ NULL')
    console.log('  sku:', inventory.sku, inventory.sku ? '✅' : '❌ NULL')
    console.log('  size:', inventory.size, inventory.size ? '✅' : '❌ NULL')
    console.log('  size_system:', inventory.size_system, inventory.size_system ? '✅' : '❌ NULL')
    console.log('  condition:', inventory.condition, inventory.condition ? '✅' : '❌ NULL')
    console.log('  status:', inventory.status, inventory.status ? '✅' : '❌ NULL')
    console.log('  purchase_price:', inventory.purchase_price, inventory.purchase_price !== null ? '✅' : '❌ NULL')
    console.log('  purchase_currency:', inventory.purchase_currency, inventory.purchase_currency ? '✅' : '❌ NULL')
    console.log('  created_at:', inventory.created_at)

    // Check product_catalog
    if (!inventory.catalog_id) {
      console.log('\n❌ NO CATALOG_ID - This is why item has no brand/model/image!')
      console.log('   → Item was created but not linked to product catalog')
      console.log('   → This means StockX catalog creation failed')
      continue
    }

    console.log('\n📚 PRODUCT_CATALOG:')
    console.log('─'.repeat(80))
    const { data: catalog, error: catError } = await supabase
      .from('product_catalog')
      .select('*')
      .eq('id', inventory.catalog_id)
      .single()

    if (catError) {
      console.error('❌ Error fetching catalog:', catError)
    } else {
      console.log('  id:', catalog.id)
      console.log('  sku:', catalog.sku, catalog.sku ? '✅' : '❌ NULL')
      console.log('  brand:', catalog.brand, catalog.brand ? '✅' : '❌ NULL')
      console.log('  model:', catalog.model, catalog.model ? '✅' : '❌ NULL')
      console.log('  colorway:', catalog.colorway, catalog.colorway ? '✅' : '❌ NULL')
      console.log('  image_url:', catalog.image_url ? '✅ HAS IMAGE' : '❌ NO IMAGE')
      console.log('  retail_price:', catalog.retail_price, catalog.retail_price ? '✅' : '❌ NULL')
      console.log('  stockx_product_id:', catalog.stockx_product_id, catalog.stockx_product_id ? '✅' : '❌ NULL')
      console.log('  category:', catalog.category, catalog.category ? '✅' : '❌ NULL')
    }

    // Check inventory_market_links
    console.log('\n🔗 INVENTORY_MARKET_LINKS:')
    console.log('─'.repeat(80))
    const { data: marketLink, error: linkError } = await supabase
      .from('inventory_market_links')
      .select('*')
      .eq('inventory_id', inventory.id)
      .single()

    if (linkError) {
      console.error('❌ NO MARKET LINK:', linkError.message)
    } else {
      console.log('  inventory_id:', marketLink.inventory_id, '✅')
      console.log('  stockx_product_id:', marketLink.stockx_product_id, marketLink.stockx_product_id ? '✅' : '❌ NULL')
      console.log('  stockx_variant_id:', marketLink.stockx_variant_id, marketLink.stockx_variant_id ? '✅' : '❌ NULL')
      console.log('  last_sync_success_at:', marketLink.last_sync_success_at, marketLink.last_sync_success_at ? '✅' : '❌ NULL')
    }

    // Check stockx_market_snapshots
    if (marketLink?.stockx_variant_id) {
      console.log('\n📸 STOCKX_MARKET_SNAPSHOTS:')
      console.log('─'.repeat(80))
      const { data: snapshots, error: snapError } = await supabase
        .from('stockx_market_snapshots')
        .select('*')
        .eq('stockx_variant_id', marketLink.stockx_variant_id)
        .order('snapshot_at', { ascending: false })
        .limit(1)

      if (snapError) {
        console.error('❌ Error fetching snapshots:', snapError.message)
      } else if (!snapshots || snapshots.length === 0) {
        console.error('❌ NO SNAPSHOTS - no pricing data saved!')
      } else {
        const snap = snapshots[0]
        console.log('  ✅ Found snapshot')
        console.log('    stockx_variant_id:', snap.stockx_variant_id)
        console.log('    lowest_ask:', snap.lowest_ask ? `£${(snap.lowest_ask / 100).toFixed(2)}` : '❌ NULL')
        console.log('    highest_bid:', snap.highest_bid ? `£${(snap.highest_bid / 100).toFixed(2)}` : '❌ NULL')
        console.log('    snapshot_at:', snap.snapshot_at)
      }
    } else {
      console.log('\n📸 STOCKX_MARKET_SNAPSHOTS: ❌ Skipped (no variant_id)')
    }

    // UI Display Summary for this item
    console.log('\n🖼️  WHAT UI SHOWS:')
    console.log('─'.repeat(80))
    const hasBrand = !!catalog?.brand
    const hasModel = !!catalog?.model
    const hasImage = !!catalog?.image_url
    const hasSize = !!inventory.size
    const hasBuyPrice = inventory.purchase_price !== null
    const hasStatus = !!inventory.status

    console.log('  Brand:', hasBrand ? `✅ ${catalog.brand}` : '❌ MISSING')
    console.log('  Model:', hasModel ? `✅ ${catalog.model}` : '❌ MISSING')
    console.log('  Image:', hasImage ? '✅ YES' : '❌ MISSING')
    console.log('  Size:', hasSize ? `✅ ${inventory.size}` : '❌ MISSING')
    console.log('  Buy Price:', hasBuyPrice ? `✅ £${inventory.purchase_price}` : '❌ MISSING')
    console.log('  Status:', hasStatus ? `✅ ${inventory.status}` : '❌ MISSING')

    const allFieldsPopulated = hasBrand && hasModel && hasImage && hasSize && hasBuyPrice && hasStatus

    if (allFieldsPopulated) {
      console.log('\n  ✅ ALL REQUIRED FIELDS POPULATED')
    } else {
      console.log('\n  ❌ MISSING FIELDS - item appears broken in UI')
    }
  }

  console.log('\n' + '='.repeat(80))
  console.log('END OF CHECK\n')
}

checkNardwuarItems().catch(console.error)
