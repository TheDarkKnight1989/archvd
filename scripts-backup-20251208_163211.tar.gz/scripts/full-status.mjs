#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('📊 Full Product Mapping Status\n')

// Total products
const { count: total } = await supabase
  .from('products')
  .select('*', { count: 'exact', head: true })

// Products with Alias IDs
const { data: withAlias } = await supabase
  .from('product_variants')
  .select('alias_catalog_id, products!inner(sku)')
  .not('alias_catalog_id', 'is', null)

const uniqueAlias = [...new Set(withAlias?.map(v => v.products.sku) || [])]

// Products with StockX IDs
const { data: withStockX } = await supabase
  .from('product_variants')
  .select('stockx_product_id, products!inner(sku)')
  .not('stockx_product_id', 'is', null)

const uniqueStockX = [...new Set(withStockX?.map(v => v.products.sku) || [])]

// Products with EITHER
const allMapped = new Set([...uniqueAlias, ...uniqueStockX])

console.log(`Total products: ${total}`)
console.log(`With Alias catalog IDs: ${uniqueAlias.length}`)
console.log(`With StockX product IDs: ${uniqueStockX.length}`)
console.log(`With EITHER mapping: ${allMapped.size}`)
console.log(`Unmapped: ${total - allMapped.size}`)
console.log('')

console.log('✅ Ready for market data sync: ' + allMapped.size + ' products')
