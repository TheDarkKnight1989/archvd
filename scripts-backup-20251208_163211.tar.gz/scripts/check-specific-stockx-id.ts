#!/usr/bin/env npx tsx
/**
 * Check if specific StockX ID exists in stockx_products table
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  const testId = '9f107fa3-65ff-426a-90e6-c3d132df360e'

  console.log(`🔍 Checking for StockX ID: ${testId}\n`)

  // Check in stockx_products table
  const { data: stockxProduct, error } = await supabase
    .from('stockx_products')
    .select('*')
    .eq('stockx_product_id', testId)
    .single()

  if (error) {
    console.log('❌ Error querying stockx_products:', error.message)
    console.log('   Code:', error.code)
  }

  if (!stockxProduct) {
    console.log('❌ NOT FOUND in stockx_products table\n')

    // Check if it exists in product_variants
    const { data: variant } = await supabase
      .from('product_variants')
      .select(`
        id,
        stockx_product_id,
        product:products (
          sku,
          model
        )
      `)
      .eq('stockx_product_id', testId)
      .limit(1)
      .single()

    if (variant) {
      const product = variant.product as any
      console.log('✅ FOUND in product_variants:')
      console.log(`   SKU: ${product?.sku}`)
      console.log(`   Model: ${product?.model}`)
      console.log(`   StockX ID: ${variant.stockx_product_id}`)
      console.log('\n⚠️  This ID is mapped in product_variants but NOT in stockx_products!')
      console.log('   This is why the sync is failing.')
    } else {
      console.log('❌ Also NOT FOUND in product_variants')
    }
  } else {
    console.log('✅ FOUND in stockx_products table:')
    console.log('   ID:', stockxProduct.id)
    console.log('   StockX Product ID:', stockxProduct.stockx_product_id)
    console.log('   Style ID:', stockxProduct.style_id)
    console.log('   Title:', stockxProduct.title)
  }
}

main().catch(console.error)
