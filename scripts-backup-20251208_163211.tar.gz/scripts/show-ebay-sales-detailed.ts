/**
 * Show every eBay sale in detail
 */

import 'dotenv/config'
import { EbayClient } from '../src/lib/services/ebay/client'
import { enrichEbaySoldItem } from '../src/lib/services/ebay/extractors'

const SKU = process.argv[2] || 'DZ4137-700'

async function main() {
  console.log('\n' + '═'.repeat(80))
  console.log(`eBay Detailed Sales Report - ${SKU}`)
  console.log('═'.repeat(80) + '\n')

  console.log('Fetching from eBay API with TWO-STEP fetch...\n')

  const client = new EbayClient()

  const result = await client.searchSold({
    query: SKU,
    limit: 50,
    conditionIds: [1000, 1500, 1750],
    qualifiedPrograms: ['AUTHENTICITY_GUARANTEE'],
    categoryIds: ['15709', '95672', '155194'],
    soldItemsOnly: true,
    fetchFullDetails: true, // ← CRITICAL: Gets variations
  })

  console.log(`✅ Fetched ${result.items.length} items`)
  console.log(`   Full details fetched: ${result.fullDetailsFetched}\n`)

  if (result.items.length === 0) {
    console.log('❌ No items returned')
    console.log('Check EBAY_MARKET_DATA_ENABLED=true in .env.local')
    process.exit(0)
  }

  // Enrich all items
  result.items.forEach((item) => {
    enrichEbaySoldItem(item)
  })

  console.log('═'.repeat(80))
  console.log('ALL SALES - LINE BY LINE')
  console.log('═'.repeat(80) + '\n')

  result.items.forEach((item, i) => {
    const num = String(i + 1).padStart(2, '0')
    console.log(`${num}. ${item.title}`)
    console.log(`    Item ID: ${item.itemId}`)
    console.log(`    Price: ${item.currency} ${item.price}`)
    console.log(`    Condition: ${item.conditionId}`)
    console.log(`    AG: ${item.authenticityVerification ? 'YES ✅' : 'NO ❌'}`)

    // Show variations
    if (item.variations && item.variations.length > 0) {
      console.log(`    Variations: ${item.variations.length} found`)
      item.variations.slice(0, 1).forEach((v) => {
        if (v.localizedAspects) {
          console.log('    Aspects:')
          v.localizedAspects.forEach((aspect) => {
            console.log(`      - ${aspect.name}: ${aspect.value}`)
          })
        }
      })
    } else {
      console.log('    Variations: NONE (will use title)')
    }

    // Show extracted size
    if (item.sizeInfo) {
      console.log('    EXTRACTED:')
      console.log(`      Size: ${item.sizeInfo.normalizedKey}`)
      console.log(`      System: ${item.sizeInfo.system}`)
      console.log(`      Confidence: ${item.sizeInfo.confidence}`)

      // Determine if included
      const included =
        item.conditionId === 1000 &&
        item.authenticityVerification &&
        item.sizeInfo.system !== 'UNKNOWN' &&
        item.sizeInfo.confidence === 'HIGH'

      console.log(`      INCLUDED: ${included ? 'YES ✅' : 'NO ❌'}`)

      if (!included) {
        let reason = ''
        if (item.conditionId !== 1000) {
          reason = `not_new_condition (${item.conditionId})`
        } else if (!item.authenticityVerification) {
          reason = 'no_authenticity_guarantee'
        } else if (item.sizeInfo.system === 'UNKNOWN') {
          reason = 'size_system_unknown'
        } else if (item.sizeInfo.confidence !== 'HIGH') {
          reason = `size_not_from_variations (${item.sizeInfo.confidence})`
        }
        console.log(`      Exclusion: ${reason}`)
      }
    } else {
      console.log('    EXTRACTED: No size found')
      console.log('    INCLUDED: NO ❌')
      console.log('    Exclusion: missing_size')
    }

    console.log()
  })

  // Summary
  console.log('═'.repeat(80))
  console.log('SUMMARY')
  console.log('═'.repeat(80) + '\n')

  const included = result.items.filter((item) => {
    return (
      item.conditionId === 1000 &&
      item.authenticityVerification &&
      item.sizeInfo &&
      item.sizeInfo.system !== 'UNKNOWN' &&
      item.sizeInfo.confidence === 'HIGH'
    )
  })

  console.log(`Total items: ${result.items.length}`)
  console.log(`Included: ${included.length}`)
  console.log(`Excluded: ${result.items.length - included.length}\n`)

  // Group included by size system
  const bySystem = included.reduce((acc, item) => {
    const sys = item.sizeInfo!.system
    if (!acc[sys]) {
      acc[sys] = []
    }
    acc[sys].push(item)
    return acc
  }, {} as Record<string, typeof included>)

  console.log('Included items by size system:\n')
  Object.entries(bySystem).forEach(([system, items]) => {
    console.log(`${system}: ${items.length} items`)
    items.forEach((item) => {
      console.log(`  - ${item.sizeInfo!.normalizedKey}: ${item.currency} ${item.price}`)
    })
    console.log()
  })

  console.log('═'.repeat(80) + '\n')
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message)
  console.error(err)
  process.exit(1)
})
