#!/usr/bin/env npx tsx
/**
 * PHASE 1 AUDIT: StockX Data Quality Assessment
 *
 * Analyzes existing StockX data in master_market_data to identify:
 * - Incorrect price conversions (dollars vs cents)
 * - Invalid sizes outside valid ranges
 * - Duplicate records
 * - Regional distribution
 * - Data freshness
 */

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function auditStockXData() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║                  PHASE 1: StockX Data Quality Audit                   ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  // =========================================================================
  // 1. OVERALL DATA VOLUME
  // =========================================================================

  console.log('📊 SECTION 1: Overall Data Volume\n');
  console.log('─'.repeat(75));

  const { count: totalRecords } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx');

  console.log(`Total StockX records: ${totalRecords?.toLocaleString() || 0}`);

  // Count unique SKUs
  const { data: uniqueSKUs } = await supabase
    .from('master_market_data')
    .select('sku')
    .eq('provider', 'stockx')
    .not('sku', 'is', null);

  const skuSet = new Set(uniqueSKUs?.map(r => r.sku) || []);
  console.log(`Unique SKUs: ${skuSet.size}`);

  // Regional distribution
  const { data: regionalData } = await supabase
    .from('master_market_data')
    .select('region_code')
    .eq('provider', 'stockx');

  const regionCounts = regionalData?.reduce((acc, r) => {
    acc[r.region_code || 'NULL'] = (acc[r.region_code || 'NULL'] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  console.log('\nRegional Distribution:');
  Object.entries(regionCounts).forEach(([region, count]) => {
    console.log(`  ${region.padEnd(6)}: ${count.toLocaleString()} records`);
  });

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 2. PRICE CONVERSION AUDIT (Critical Issue)
  // =========================================================================

  console.log('💰 SECTION 2: Price Conversion Audit\n');
  console.log('─'.repeat(75));

  console.log('Checking for incorrect price conversions (dollars vs cents)...\n');

  // Prices below £10 (1000 cents) are suspicious for sneakers
  // StockX lowest ask is typically £50-£500, so anything under 1000 cents is likely wrong
  const { data: suspiciouslyLowPrices, count: lowPriceCount } = await supabase
    .from('master_market_data')
    .select('sku, size_key, lowest_ask, highest_bid, region_code, currency_code, snapshot_at', { count: 'exact' })
    .eq('provider', 'stockx')
    .not('lowest_ask', 'is', null)
    .lt('lowest_ask', 1000) // Less than £10 / $10 / €10 in cents
    .order('lowest_ask')
    .limit(10);

  if (lowPriceCount && lowPriceCount > 0) {
    console.log(`🚨 CRITICAL: Found ${lowPriceCount.toLocaleString()} records with suspiciously low prices (<£10)`);
    console.log('   These are likely incorrect price conversions (stored as dollars, not cents)\n');

    console.log('Sample of suspicious records:');
    console.log('SKU          | Size | Region | Lowest Ask  | Currency');
    console.log('─'.repeat(75));

    suspiciouslyLowPrices?.slice(0, 10).forEach(r => {
      const currency = r.currency_code === 'GBP' ? '£' : r.currency_code === 'EUR' ? '€' : '$';
      const displayPrice = `${currency}${((r.lowest_ask || 0) / 100).toFixed(2)}`;
      console.log(
        `${r.sku.padEnd(12)} | ${r.size_key.toString().padEnd(4)} | ${r.region_code.padEnd(6)} | ${displayPrice.padEnd(11)} | ${r.currency_code}`
      );
    });

    console.log('\n⚠️  Action Required: All StockX data needs to be deleted and re-synced');
  } else {
    console.log('✅ No suspiciously low prices found - price conversion appears correct');
  }

  // Check for reasonable price range distribution
  const { data: priceDistribution } = await supabase
    .from('master_market_data')
    .select('lowest_ask')
    .eq('provider', 'stockx')
    .not('lowest_ask', 'is', null);

  const priceBuckets = {
    '<£10': 0,
    '£10-£50': 0,
    '£50-£100': 0,
    '£100-£200': 0,
    '£200-£500': 0,
    '>£500': 0,
  };

  priceDistribution?.forEach(r => {
    const price = r.lowest_ask / 100;
    if (price < 10) priceBuckets['<£10']++;
    else if (price < 50) priceBuckets['£10-£50']++;
    else if (price < 100) priceBuckets['£50-£100']++;
    else if (price < 200) priceBuckets['£100-£200']++;
    else if (price < 500) priceBuckets['£200-£500']++;
    else priceBuckets['>£500']++;
  });

  console.log('\nPrice Distribution (Lowest Ask):');
  Object.entries(priceBuckets).forEach(([range, count]) => {
    const percent = ((count / (priceDistribution?.length || 1)) * 100).toFixed(1);
    console.log(`  ${range.padEnd(12)}: ${count.toLocaleString().padStart(6)} (${percent}%)`);
  });

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 3. SIZE VALIDATION AUDIT
  // =========================================================================

  console.log('📏 SECTION 3: Size Validation Audit\n');
  console.log('─'.repeat(75));

  const { data: sizeData } = await supabase
    .from('master_market_data')
    .select('size_numeric')
    .eq('provider', 'stockx')
    .not('size_numeric', 'is', null);

  const sizes = sizeData?.map(r => r.size_numeric).filter(Boolean) || [];
  const uniqueSizes = [...new Set(sizes)].sort((a, b) => a - b);

  console.log('Size Range:', Math.min(...uniqueSizes), 'to', Math.max(...uniqueSizes));
  console.log('Unique sizes:', uniqueSizes.length);

  // Identify invalid sizes (outside 3.5-16 range for sneakers)
  const invalidSizes = uniqueSizes.filter(size => size < 3.5 || size > 16);

  if (invalidSizes.length > 0) {
    console.log(`\n🚨 Found ${invalidSizes.length} invalid sizes outside valid range (3.5-16):`);
    console.log('  Invalid sizes:', invalidSizes.slice(0, 20).join(', '));

    // Count records with invalid sizes
    const invalidSizeCounts = await Promise.all(
      invalidSizes.map(async (size) => {
        const { count } = await supabase
          .from('master_market_data')
          .select('*', { count: 'exact', head: true })
          .eq('provider', 'stockx')
          .eq('size_numeric', size);
        return { size, count };
      })
    );

    const totalInvalidRecords = invalidSizeCounts.reduce((sum, { count }) => sum + (count || 0), 0);
    console.log(`\n  Total records with invalid sizes: ${totalInvalidRecords.toLocaleString()}`);

    console.log('\n  Top invalid sizes by record count:');
    invalidSizeCounts
      .sort((a, b) => (b.count || 0) - (a.count || 0))
      .slice(0, 10)
      .forEach(({ size, count }) => {
        console.log(`    Size ${size}: ${count?.toLocaleString() || 0} records`);
      });

    console.log('\n⚠️  Action Required: Re-sync with size filtering to remove invalid sizes');
  } else {
    console.log('\n✅ All sizes are within valid range (3.5-16)');
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 4. DUPLICATE DETECTION
  // =========================================================================

  console.log('🔍 SECTION 4: Duplicate Detection\n');
  console.log('─'.repeat(75));

  // Check for duplicate entries (same SKU, size, region, timestamp)
  const { data: potentialDuplicates } = await supabase
    .from('master_market_data')
    .select('sku, size_key, region_code, currency_code, is_flex, is_consigned, snapshot_at')
    .eq('provider', 'stockx')
    .order('sku')
    .order('size_key')
    .order('snapshot_at', { ascending: false });

  // Group by SKU + size + region + flex/consigned
  const groupedRecords = potentialDuplicates?.reduce((acc, record) => {
    const key = `${record.sku}|${record.size_key}|${record.region_code}|${record.is_flex}|${record.is_consigned}`;
    if (!acc[key]) acc[key] = [];
    acc[key].push(record);
    return acc;
  }, {} as Record<string, any[]>) || {};

  const duplicateGroups = Object.entries(groupedRecords).filter(([_, records]) => records.length > 1);

  if (duplicateGroups.length > 0) {
    console.log(`⚠️  Found ${duplicateGroups.length} groups with multiple records (same SKU/size/region/type)`);
    console.log('   Note: Multiple timestamps are normal (historical snapshots)');

    // Show a sample
    const sample = duplicateGroups[0][1];
    console.log(`\n  Sample group (${sample[0].sku} size ${sample[0].size_key} ${sample[0].region_code}):`);
    sample.slice(0, 3).forEach(r => {
      console.log(`    - ${new Date(r.snapshot_at).toISOString().split('T')[0]} (flex: ${r.is_flex}, consigned: ${r.is_consigned})`);
    });
  } else {
    console.log('✅ No duplicate records found');
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 5. DATA FRESHNESS AUDIT
  // =========================================================================

  console.log('📅 SECTION 5: Data Freshness Audit\n');
  console.log('─'.repeat(75));

  const { data: freshnessData } = await supabase
    .from('master_market_data')
    .select('snapshot_at')
    .eq('provider', 'stockx')
    .order('snapshot_at', { ascending: false })
    .limit(1);

  const mostRecent = freshnessData?.[0]?.snapshot_at;

  if (mostRecent) {
    const hoursSinceSync = (Date.now() - new Date(mostRecent).getTime()) / (1000 * 60 * 60);
    console.log(`Most recent sync: ${new Date(mostRecent).toISOString()}`);
    console.log(`Time since last sync: ${hoursSinceSync.toFixed(1)} hours ago`);

    if (hoursSinceSync > 24) {
      console.log('⚠️  Data is more than 24 hours old - consider re-syncing');
    } else if (hoursSinceSync > 12) {
      console.log('⚠️  Data is more than 12 hours old');
    } else {
      console.log('✅ Data is relatively fresh');
    }
  } else {
    console.log('⚠️  No snapshot data found');
  }

  // Age distribution
  const { data: ageData } = await supabase
    .from('master_market_data')
    .select('snapshot_at')
    .eq('provider', 'stockx');

  const now = Date.now();
  const ageBuckets = {
    '<1 hour': 0,
    '1-6 hours': 0,
    '6-24 hours': 0,
    '1-7 days': 0,
    '>7 days': 0,
  };

  ageData?.forEach(r => {
    const hours = (now - new Date(r.snapshot_at).getTime()) / (1000 * 60 * 60);
    if (hours < 1) ageBuckets['<1 hour']++;
    else if (hours < 6) ageBuckets['1-6 hours']++;
    else if (hours < 24) ageBuckets['6-24 hours']++;
    else if (hours < 168) ageBuckets['1-7 days']++;
    else ageBuckets['>7 days']++;
  });

  console.log('\nData Age Distribution:');
  Object.entries(ageBuckets).forEach(([range, count]) => {
    const percent = ((count / (ageData?.length || 1)) * 100).toFixed(1);
    console.log(`  ${range.padEnd(12)}: ${count.toLocaleString().padStart(6)} (${percent}%)`);
  });

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // 6. FLEX & CONSIGNED PRICING COVERAGE
  // =========================================================================

  console.log('🏷️  SECTION 6: Flex & Consigned Pricing Coverage\n');
  console.log('─'.repeat(75));

  const { count: standardCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .eq('is_flex', false)
    .eq('is_consigned', false);

  const { count: flexCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .eq('is_flex', true);

  const { count: consignedCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')
    .eq('is_consigned', true);

  console.log('Pricing Type Distribution:');
  console.log(`  Standard:  ${standardCount?.toLocaleString() || 0} records`);
  console.log(`  Flex:      ${flexCount?.toLocaleString() || 0} records`);
  console.log(`  Consigned: ${consignedCount?.toLocaleString() || 0} records`);

  const total = (standardCount || 0) + (flexCount || 0) + (consignedCount || 0);
  if (total !== totalRecords) {
    console.log(`\n⚠️  Mismatch: Sum of types (${total}) ≠ total records (${totalRecords})`);
  }

  console.log('\n' + '─'.repeat(75) + '\n');

  // =========================================================================
  // SUMMARY & RECOMMENDATIONS
  // =========================================================================

  console.log('╔═══════════════════════════════════════════════════════════════════════╗');
  console.log('║                            AUDIT SUMMARY                              ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n');

  const issues: string[] = [];
  const warnings: string[] = [];
  const passed: string[] = [];

  // Critical issues
  if (lowPriceCount && lowPriceCount > 0) {
    issues.push(`${lowPriceCount.toLocaleString()} records with incorrect price conversion (CRITICAL)`);
  } else {
    passed.push('Price conversion validation');
  }

  if (invalidSizes.length > 0) {
    const totalInvalidRecords = sizes.filter(s => s < 3.5 || s > 16).length;
    issues.push(`${totalInvalidRecords.toLocaleString()} records with invalid sizes (needs filtering)`);
  } else {
    passed.push('Size range validation');
  }

  // Warnings
  if (mostRecent) {
    const hoursSinceSync = (Date.now() - new Date(mostRecent).getTime()) / (1000 * 60 * 60);
    if (hoursSinceSync > 24) {
      warnings.push(`Data is ${hoursSinceSync.toFixed(0)} hours old (stale)`);
    }
  }

  if (issues.length > 0) {
    console.log('🚨 CRITICAL ISSUES:\n');
    issues.forEach((issue, i) => {
      console.log(`  ${i + 1}. ${issue}`);
    });
    console.log('');
  }

  if (warnings.length > 0) {
    console.log('⚠️  WARNINGS:\n');
    warnings.forEach((warning, i) => {
      console.log(`  ${i + 1}. ${warning}`);
    });
    console.log('');
  }

  if (passed.length > 0) {
    console.log('✅ PASSED:\n');
    passed.forEach((item, i) => {
      console.log(`  ${i + 1}. ${item}`);
    });
    console.log('');
  }

  console.log('─'.repeat(75));
  console.log('\n📋 RECOMMENDED ACTIONS:\n');

  if (lowPriceCount && lowPriceCount > 0) {
    console.log('  1. DELETE all StockX data from master_market_data');
    console.log('  2. Re-sync all products with corrected price conversion');
  }

  if (invalidSizes.length > 0) {
    console.log('  3. Re-sync with gender-based size filtering enabled');
  }

  if (issues.length === 0 && warnings.length === 0) {
    console.log('  ✅ No action required - data quality is good!');
  }

  console.log('\n' + '─'.repeat(75));
  console.log('\n✅ Phase 1 Audit Complete\n');
}

auditStockXData().catch(console.error);
