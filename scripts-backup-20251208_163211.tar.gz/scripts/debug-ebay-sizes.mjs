#!/usr/bin/env node

/**
 * Debug eBay size system detection
 * Shows exactly what eBay returns and how we interpret it
 */

import 'dotenv/config'
import { createClient } from '@supabase/supabase-js'

const SKU = process.argv[2] || 'DZ4137-700'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('\n' + '═'.repeat(80))
console.log(`eBay Size System Debug - ${SKU}`)
console.log('═'.repeat(80) + '\n')

console.log('Checking current master_market_data...\n')

const { data, error } = await supabase
  .from('master_market_data')
  .select('*')
  .eq('provider', 'ebay')
  .ilike('sku', `%${SKU}%`)

if (error) {
  console.error('Error:', error)
  process.exit(1)
}

if (!data || data.length === 0) {
  console.log('❌ No eBay data found in master_market_data')
  console.log('\nThis means the sync hasnt run yet or no items match.')
  console.log('The "34 items" was from a previous test.')
  process.exit(0)
}

console.log(`Found ${data.length} rows in master_market_data:\n`)

console.log('Size Key     | Size Sys | Size Num | Price    | Currency | Snapshot Date')
console.log('-------------|----------|----------|----------|----------|------------------')

data
  .sort((a, b) => (a.size_numeric || 0) - (b.size_numeric || 0))
  .forEach((row) => {
    const sizeKey = (row.size_key || 'N/A').padEnd(12)
    const sizeSystem = (row.size_system || 'N/A').padEnd(8)
    const sizeNumeric = (row.size_numeric?.toString() || 'N/A').padEnd(8)
    const price = row.last_sale_price
      ? `£${row.last_sale_price.toFixed(2)}`.padEnd(8)
      : 'N/A'.padEnd(8)
    const currency = (row.currency_code || 'N/A').padEnd(8)
    const date = row.snapshot_at
      ? new Date(row.snapshot_at).toLocaleDateString()
      : 'N/A'

    console.log(
      `${sizeKey} | ${sizeSystem} | ${sizeNumeric} | ${price} | ${currency} | ${date}`
    )
  })

console.log('\n' + '─'.repeat(80))
console.log('Analysis:')
console.log('─'.repeat(80) + '\n')

// Count by size system
const bySizeSystem = data.reduce((acc, row) => {
  const system = row.size_system || 'NULL'
  acc[system] = (acc[system] || 0) + 1
  return acc
}, {})

console.log('Size Systems:')
Object.entries(bySizeSystem).forEach(([system, count]) => {
  console.log(`  ${system}: ${count}`)
})

// Price stats
const prices = data
  .filter((r) => r.last_sale_price)
  .map((r) => r.last_sale_price)

if (prices.length > 0) {
  const avg = prices.reduce((sum, p) => sum + p, 0) / prices.length
  const min = Math.min(...prices)
  const max = Math.max(...prices)

  console.log('\nPrice Stats (all sizes):')
  console.log(`  Average: £${avg.toFixed(2)}`)
  console.log(`  Min: £${min.toFixed(2)}`)
  console.log(`  Max: £${max.toFixed(2)}`)
}

// Check raw_response_excerpt for clues
console.log('\n' + '─'.repeat(80))
console.log('Sample Raw Data (first 3 items):')
console.log('─'.repeat(80) + '\n')

data.slice(0, 3).forEach((row, i) => {
  console.log(`${i + 1}. Size: ${row.size_key}`)
  if (row.raw_response_excerpt) {
    console.log('   Raw excerpt:', JSON.stringify(row.raw_response_excerpt, null, 2))
  }
  console.log()
})

console.log('═'.repeat(80))
console.log('\nQUESTIONS TO INVESTIGATE:')
console.log('1. Are these sizes US or UK?')
console.log('2. Why do we have more items than manual search (12 vs 34)?')
console.log('3. Are prices in GBP or USD?')
console.log('4. What did the original eBay API response say?')
console.log('\nTo see what eBay actually returns, we need to:')
console.log('- Run a fresh API call with EBAY_MARKET_DATA_ENABLED=true')
console.log('- Check the variation aspect names in the response')
console.log('- Verify the marketplace_id is EBAY_GB')
console.log('═'.repeat(80) + '\n')
