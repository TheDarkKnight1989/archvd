#!/usr/bin/env node

/**
 * Test eBay API with explicit env loading
 */

import { config } from 'dotenv'
import { resolve } from 'path'

// Explicitly load .env.local
config({ path: resolve(process.cwd(), '.env.local') })

console.log('\n' + '='.repeat(80))
console.log('Environment Check:')
console.log('EBAY_MARKET_DATA_ENABLED:', process.env.EBAY_MARKET_DATA_ENABLED)
console.log('EBAY_ENV:', process.env.EBAY_ENV)
console.log('EBAY_CLIENT_ID:', process.env.EBAY_CLIENT_ID ? 'Set' : 'Missing')
console.log('='.repeat(80) + '\n')

// Now import the modules
const { EbayClient } = await import('../src/lib/services/ebay/client.js')
const { enrichEbaySoldItem } = await import('../src/lib/services/ebay/extractors.js')

const SKU = process.argv[2] || 'DZ4137-700'

console.log('Fetching ' + SKU + ' from eBay with TWO-STEP API...\n')

const client = new EbayClient()

try {
  const result = await client.searchSold({
    query: SKU,
    limit: 50,
    conditionIds: [1000, 1500, 1750],
    qualifiedPrograms: ['AUTHENTICITY_GUARANTEE'],
    categoryIds: ['15709', '95672', '155194'],
    soldItemsOnly: true,
    fetchFullDetails: true,
  })

  console.log('✅ Success! Fetched ' + result.items.length + ' items')
  console.log('   Full details: ' + result.fullDetailsFetched + '\n')

  if (result.items.length === 0) {
    console.log('No items found for ' + SKU)
    process.exit(0)
  }

  // Enrich
  result.items.forEach((item) => {
    enrichEbaySoldItem(item)
  })

  console.log('='.repeat(80))
  console.log('EVERY SALE - LINE BY LINE')
  console.log('='.repeat(80) + '\n')

  result.items.forEach((item, i) => {
    console.log((i + 1) + '. ' + item.title)
    console.log('   Price: ' + item.currency + ' ' + item.price)
    console.log('   Condition: ' + item.conditionId)
    console.log('   AG: ' + (item.authenticityVerification ? 'YES' : 'NO'))

    if (item.variations && item.variations.length > 0) {
      console.log('   Variations: ' + item.variations.length)
      if (item.variations[0].localizedAspects) {
        item.variations[0].localizedAspects.slice(0, 3).forEach((a) => {
          console.log('     ' + a.name + ': ' + a.value)
        })
      }
    } else {
      console.log('   Variations: NONE')
    }

    if (item.sizeInfo) {
      console.log('   EXTRACTED: ' + item.sizeInfo.normalizedKey)
      console.log('   System: ' + item.sizeInfo.system)
      console.log('   Confidence: ' + item.sizeInfo.confidence)

      const included = item.conditionId === 1000 &&
                      item.authenticityVerification &&
                      item.sizeInfo.system !== 'UNKNOWN' &&
                      item.sizeInfo.confidence === 'HIGH'

      console.log('   INCLUDED: ' + (included ? 'YES ✅' : 'NO ❌'))
    } else {
      console.log('   EXTRACTED: No size')
      console.log('   INCLUDED: NO ❌')
    }
    console.log()
  })

  // Summary
  const included = result.items.filter((item) => {
    return item.conditionId === 1000 &&
           item.authenticityVerification &&
           item.sizeInfo &&
           item.sizeInfo.system !== 'UNKNOWN' &&
           item.sizeInfo.confidence === 'HIGH'
  })

  console.log('='.repeat(80))
  console.log('SUMMARY')
  console.log('='.repeat(80) + '\n')
  console.log('Total: ' + result.items.length)
  console.log('Included: ' + included.length)
  console.log('Excluded: ' + (result.items.length - included.length) + '\n')

  // By size system
  const bySystem = included.reduce((acc, item) => {
    const sys = item.sizeInfo.system
    if (!acc[sys]) acc[sys] = []
    acc[sys].push(item)
    return acc
  }, {})

  Object.entries(bySystem).forEach(([sys, items]) => {
    console.log(sys + ': ' + items.length + ' items')
    items.forEach((item) => {
      console.log('  ' + item.sizeInfo.normalizedKey + ': ' + item.currency + ' ' + item.price)
    })
  })

  console.log('\n' + '='.repeat(80) + '\n')

} catch (err) {
  console.error('Error:', err.message)
  console.error(err)
  process.exit(1)
}
