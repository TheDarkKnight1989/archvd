#!/usr/bin/env node

/**
 * Investigation script: Check StockX image data availability
 *
 * This script:
 * 1. Counts total products in stockx_products
 * 2. Counts how many have image_url or thumb_url
 * 3. Samples some products including Fear of God 1 Triple Black
 * 4. Logs raw image URLs for manual browser testing
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

async function investigateStockXImages() {
  console.log('\n🔍 STEP 1: Checking stockx_products image data\n')

  // Count total products
  const { count: totalCount, error: countError } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true })

  if (countError) {
    console.error('❌ Error counting products:', countError)
    return
  }

  console.log(`📊 Total products in stockx_products: ${totalCount}`)

  // Count products with image_url
  const { count: imageUrlCount, error: imageUrlError } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true })
    .not('image_url', 'is', null)

  if (imageUrlError) {
    console.error('❌ Error counting image_url:', imageUrlError)
    return
  }

  console.log(`🖼️  Products with image_url: ${imageUrlCount} (${totalCount > 0 ? ((imageUrlCount / totalCount) * 100).toFixed(1) : 0}%)`)

  // Count products with thumb_url
  const { count: thumbUrlCount, error: thumbUrlError } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true })
    .not('thumb_url', 'is', null)

  if (thumbUrlError) {
    console.error('❌ Error counting thumb_url:', thumbUrlError)
    return
  }

  console.log(`📸 Products with thumb_url: ${thumbUrlCount} (${totalCount > 0 ? ((thumbUrlCount / totalCount) * 100).toFixed(1) : 0}%)`)

  // Count products with EITHER image field
  const { count: anyImageCount, error: anyImageError } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true })
    .or('image_url.not.is.null,thumb_url.not.is.null')

  if (anyImageError) {
    console.error('❌ Error counting any image:', anyImageError)
    return
  }

  console.log(`✅ Products with ANY image: ${anyImageCount} (${totalCount > 0 ? ((anyImageCount / totalCount) * 100).toFixed(1) : 0}%)\n`)

  // Look for Fear of God 1 Triple Black
  console.log('🔍 STEP 2: Looking for Fear of God 1 Triple Black (AR4237-005)\n')

  const { data: fogProducts, error: fogError } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, title, brand, image_url, thumb_url')
    .eq('style_id', 'AR4237-005')

  if (fogError) {
    console.error('❌ Error finding Fear of God:', fogError)
  } else if (fogProducts && fogProducts.length > 0) {
    console.log('✅ Found Fear of God 1 Triple Black:')
    fogProducts.forEach(product => {
      console.log(`\n  Product ID: ${product.stockx_product_id}`)
      console.log(`  Style ID: ${product.style_id}`)
      console.log(`  Title: ${product.title}`)
      console.log(`  Brand: ${product.brand}`)
      console.log(`  image_url: ${product.image_url || 'NULL'}`)
      console.log(`  thumb_url: ${product.thumb_url || 'NULL'}`)
    })
  } else {
    console.log('❌ Fear of God 1 Triple Black not found in database')
  }

  // Sample 5 random products with images
  console.log('\n🔍 STEP 3: Sampling 5 random products with images\n')

  const { data: sampleProducts, error: sampleError } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, title, brand, image_url, thumb_url')
    .not('image_url', 'is', null)
    .limit(5)

  if (sampleError) {
    console.error('❌ Error sampling products:', sampleError)
  } else if (sampleProducts && sampleProducts.length > 0) {
    console.log('📸 Sample products with images:')
    sampleProducts.forEach((product, idx) => {
      console.log(`\n${idx + 1}. ${product.title}`)
      console.log(`   Product ID: ${product.stockx_product_id}`)
      console.log(`   Style ID: ${product.style_id}`)
      console.log(`   image_url: ${product.image_url}`)
      console.log(`   thumb_url: ${product.thumb_url || 'NULL'}`)
    })
  }

  // Check what products I currently have in my inventory with StockX mappings
  console.log('\n🔍 STEP 4: Checking your inventory items with StockX mappings\n')

  const { data: mappedItems, error: mappedError } = await supabase
    .from('inventory_market_links')
    .select(`
      item_id,
      stockx_product_id,
      stockx_variant_id,
      stockx_products!inner(
        stockx_product_id,
        style_id,
        title,
        brand,
        image_url,
        thumb_url
      )
    `)
    .limit(10)

  if (mappedError) {
    console.error('❌ Error fetching mapped inventory:', mappedError)
  } else if (mappedItems && mappedItems.length > 0) {
    console.log(`✅ Found ${mappedItems.length} inventory items with StockX mappings:`)
    mappedItems.forEach((item, idx) => {
      const product = item.stockx_products
      console.log(`\n${idx + 1}. ${product.title}`)
      console.log(`   Product ID: ${product.stockx_product_id}`)
      console.log(`   Style ID: ${product.style_id}`)
      console.log(`   Has image_url: ${product.image_url ? '✅ YES' : '❌ NO'}`)
      console.log(`   Has thumb_url: ${product.thumb_url ? '✅ YES' : '❌ NO'}`)
      if (product.image_url) {
        console.log(`   URL: ${product.image_url}`)
      }
    })
  } else {
    console.log('❌ No inventory items with StockX mappings found')
  }

  console.log('\n✅ Investigation complete!\n')
  console.log('📝 Next steps:')
  console.log('   1. Copy one of the image URLs above')
  console.log('   2. Test it in your browser to see if StockX allows direct access')
  console.log('   3. If blocked, we\'ll need to proxy the images through our API\n')
}

investigateStockXImages().catch(console.error)
