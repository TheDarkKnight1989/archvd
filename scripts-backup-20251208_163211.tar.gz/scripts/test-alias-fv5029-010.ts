/**
 * Test Alias API for FV5029-010 (Jordan 4 Black Cat)
 * Shows EXACT endpoints, payloads, and responses
 */

import { createAliasClient } from '@/lib/services/alias/client'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS API TEST FOR SKU:', SKU)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()

  // ============================================================================
  // TEST 1: Search Catalog
  // ============================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('ENDPOINT 1: Search Catalog')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log('📤 REQUEST:')
  console.log(`   Endpoint: GET /v1/catalog?query=${SKU}`)
  console.log(`   Query: "${SKU}"`)
  console.log()

  try {
    const searchResults = await client.searchCatalog(SKU, { limit: 5 })

    console.log('📥 RESPONSE:')
    console.log(`   Status: 200 OK`)
    console.log(`   Results: ${searchResults.catalog_items.length} items`)
    console.log()

    if (searchResults.catalog_items.length > 0) {
      console.log('📋 ITEMS FOUND:')
      for (const item of searchResults.catalog_items) {
        console.log(`   • ${item.name}`)
        console.log(`     catalog_id: ${item.catalog_id}`)
        console.log(`     sku: ${item.sku}`)
        console.log(`     brand: ${item.brand}`)
        console.log()
      }

      const exactMatch = searchResults.catalog_items.find(item =>
        item.sku?.toUpperCase() === SKU.toUpperCase()
      )

      if (!exactMatch) {
        console.log('⚠️  NO EXACT SKU MATCH FOUND')
        console.log(`   Searched for: ${SKU}`)
        console.log(`   Found SKUs: ${searchResults.catalog_items.map(i => i.sku).join(', ')}`)
        console.log()
        console.log('❌ PROBLEM IDENTIFIED: Alias does not have this SKU in their catalog')
        console.log('   This means FV5029-010 does not exist in Alias\'s system\n')
        return
      }

      const catalogItem = exactMatch
      console.log('✅ EXACT MATCH FOUND!')
      console.log()

      // ========================================================================
      // TEST 2: Get Catalog Item Details
      // ========================================================================

      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
      console.log('ENDPOINT 2: Get Catalog Item')
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

      console.log('📤 REQUEST:')
      console.log(`   Endpoint: GET /v1/catalog/${catalogItem.catalog_id}`)
      console.log()

      const catalogDetails = await client.getCatalogItem(catalogItem.catalog_id)

      console.log('📥 RESPONSE:')
      console.log(JSON.stringify(catalogDetails, null, 2))
      console.log()

      // ========================================================================
      // TEST 3: List Pricing Insights (All Sizes)
      // ========================================================================

      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
      console.log('ENDPOINT 3: List Pricing Insights')
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

      console.log('📤 REQUEST:')
      console.log(`   Endpoint: GET /v1/pricing_insights/availabilities/${catalogItem.catalog_id}`)
      console.log('   Parameters: (none - fetching all variants)')
      console.log()

      const pricingInsights = await client.listPricingInsights(catalogItem.catalog_id)

      console.log('📥 RESPONSE:')
      console.log(`   Total variants: ${pricingInsights.variants.length}`)
      console.log()

      console.log('FIRST VARIANT (FULL RAW RESPONSE):')
      console.log(JSON.stringify(pricingInsights.variants[0], null, 2))
      console.log()

      console.log('ALL VARIANTS SUMMARY:')
      for (const variant of pricingInsights.variants.slice(0, 5)) {
        console.log(`   • Size ${variant.size} ${variant.size_unit || 'US'}`)
        console.log(`     Condition: ${variant.product_condition} / ${variant.packaging_condition}`)
        console.log(`     Consigned: ${variant.consigned ?? 'not specified'}`)
        if (variant.availability) {
          console.log(`     Lowest Ask: ${variant.availability.lowest_listing_price_cents ? `$${parseInt(variant.availability.lowest_listing_price_cents) / 100}` : 'N/A'}`)
          console.log(`     Highest Bid: ${variant.availability.highest_offer_price_cents ? `$${parseInt(variant.availability.highest_offer_price_cents) / 100}` : 'N/A'}`)
        } else {
          console.log(`     Availability: NULL`)
        }
        console.log()
      }

      if (pricingInsights.variants.length > 5) {
        console.log(`   ... and ${pricingInsights.variants.length - 5} more variants`)
        console.log()
      }

      // ========================================================================
      // TEST 4: Get Pricing Insights (Specific Size)
      // ========================================================================

      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
      console.log('ENDPOINT 4: Get Pricing Insights (Size 10)')
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

      const size10Params = {
        catalog_id: catalogItem.catalog_id,
        size: 10,
        product_condition: 'PRODUCT_CONDITION_NEW' as const,
        packaging_condition: 'PACKAGING_CONDITION_GOOD_CONDITION' as const
      }

      console.log('📤 REQUEST:')
      console.log(`   Endpoint: GET /v1/pricing_insights/availability`)
      console.log(`   Parameters:`)
      console.log(`     catalog_id: ${size10Params.catalog_id}`)
      console.log(`     size: ${size10Params.size}`)
      console.log(`     product_condition: ${size10Params.product_condition}`)
      console.log(`     packaging_condition: ${size10Params.packaging_condition}`)
      console.log()

      const size10Pricing = await client.getPricingInsights(size10Params)

      console.log('📥 RESPONSE:')
      console.log(JSON.stringify(size10Pricing, null, 2))
      console.log()

      // ========================================================================
      // TEST 5: Recent Sales
      // ========================================================================

      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
      console.log('ENDPOINT 5: Recent Sales')
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

      console.log('📤 REQUEST:')
      console.log(`   Endpoint: GET /v1/pricing_insights/recent_sales`)
      console.log(`   Parameters:`)
      console.log(`     catalog_id: ${catalogItem.catalog_id}`)
      console.log(`     limit: 20`)
      console.log()

      try {
        const recentSales = await client.getRecentSales({
          catalog_id: catalogItem.catalog_id,
          limit: 20
        })

        console.log('📥 RESPONSE:')
        console.log(`   Total sales: ${recentSales.recent_sales.length}`)
        console.log()

        if (recentSales.recent_sales.length > 0) {
          console.log('FIRST SALE (FULL RAW RESPONSE):')
          console.log(JSON.stringify(recentSales.recent_sales[0], null, 2))
          console.log()

          console.log('ALL SALES SUMMARY:')
          for (const sale of recentSales.recent_sales) {
            console.log(`   • ${sale.purchased_at} - Size ${sale.size} - $${parseInt(sale.price_cents) / 100} ${sale.consigned ? '(Consigned)' : '(Standard)'}`)
          }
        } else {
          console.log('   No recent sales data')
        }
        console.log()
      } catch (error: any) {
        console.log('❌ RECENT SALES FAILED:')
        console.log(`   Error: ${error.message}`)
        console.log(`   Status: ${error.statusCode || 'unknown'}`)
        console.log()
      }

    } else {
      console.log('❌ NO RESULTS FOUND')
      console.log(`   The SKU "${SKU}" does not exist in Alias catalog`)
      console.log()
    }

  } catch (error: any) {
    console.log('❌ ERROR:')
    console.log(`   Message: ${error.message}`)
    console.log(`   Status: ${error.statusCode || 'unknown'}`)
    console.log()

    if (error.rawResponse) {
      console.log('RAW ERROR RESPONSE:')
      console.log(error.rawResponse)
      console.log()
    }
  }

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('TEST COMPLETE')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
