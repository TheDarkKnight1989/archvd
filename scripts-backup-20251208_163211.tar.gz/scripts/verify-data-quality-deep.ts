#!/usr/bin/env npx tsx
/**
 * Deep Data Quality Check
 * Don't trust logs - verify actual database contents
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function checkDataQuality() {
  console.log('🔍 DEEP DATA QUALITY CHECK\n')

  // Get all recent Alias data
  const { data, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'alias')
    .eq('sku', 'M2002RDB')
    .gte('snapshot_at', new Date(Date.now() - 10 * 60 * 1000).toISOString())
    .order('region_code')
    .order('size_key')
    .order('is_consigned')

  if (error) {
    console.error('❌ Query failed:', error.message)
    return
  }

  console.log(`Total records: ${data.length}\n`)

  // Check for NULL/missing data
  const issues: string[] = []

  const nullLowestAsk = data.filter(r => r.lowest_ask === null).length
  const nullHighestBid = data.filter(r => r.highest_bid === null).length
  const nullLastSale = data.filter(r => r.last_sale_price === null).length
  const nullSizeKey = data.filter(r => !r.size_key).length
  const nullRegion = data.filter(r => !r.region_code).length
  const nullCurrency = data.filter(r => !r.currency_code).length

  console.log('NULL VALUE ANALYSIS:')
  console.log(`  Missing lowest_ask: ${nullLowestAsk}/${data.length}`)
  console.log(`  Missing highest_bid: ${nullHighestBid}/${data.length}`)
  console.log(`  Missing last_sale_price: ${nullLastSale}/${data.length}`)
  console.log(`  Missing size_key: ${nullSizeKey}/${data.length} ${nullSizeKey > 0 ? '❌' : '✅'}`)
  console.log(`  Missing region_code: ${nullRegion}/${data.length} ${nullRegion > 0 ? '❌' : '✅'}`)
  console.log(`  Missing currency_code: ${nullCurrency}/${data.length} ${nullCurrency > 0 ? '❌' : '✅'}`)

  if (nullSizeKey > 0) issues.push('Missing size_key')
  if (nullRegion > 0) issues.push('Missing region_code')
  if (nullCurrency > 0) issues.push('Missing currency_code')

  // Check price data quality
  const withAnyPrice = data.filter(r => r.lowest_ask || r.highest_bid || r.last_sale_price).length
  const withoutAnyPrice = data.length - withAnyPrice

  console.log(`\nPRICE DATA:`)
  console.log(`  Records with at least 1 price: ${withAnyPrice}/${data.length}`)
  console.log(`  Records with NO prices: ${withoutAnyPrice}/${data.length}`)

  if (withoutAnyPrice > data.length * 0.5) {
    issues.push('More than 50% of records have no pricing data')
  }

  // Check consigned flag distribution
  const consignedTrue = data.filter(r => r.is_consigned === true).length
  const consignedFalse = data.filter(r => r.is_consigned === false).length
  const consignedNull = data.filter(r => r.is_consigned === null).length

  console.log(`\nCONSIGNED FLAG:`)
  console.log(`  is_consigned = true:  ${consignedTrue}`)
  console.log(`  is_consigned = false: ${consignedFalse}`)
  console.log(`  is_consigned = null:  ${consignedNull} ${consignedNull > 0 ? '❌' : '✅'}`)

  if (consignedNull > 0) issues.push('Some records have NULL is_consigned')
  if (consignedTrue === 0) issues.push('NO consigned data (all false)')
  if (consignedFalse === 0) issues.push('NO non-consigned data (all true)')

  // Sample actual data
  console.log(`\nSAMPLE RECORDS (first 5):`)
  data.slice(0, 5).forEach((row, i) => {
    console.log(`\n[${i + 1}] ${row.region_code} | Size ${row.size_key} | Consigned: ${row.is_consigned}`)
    console.log(`    Lowest Ask: $${row.lowest_ask || 'NULL'}`)
    console.log(`    Highest Bid: $${row.highest_bid || 'NULL'}`)
    console.log(`    Last Sale: $${row.last_sale_price || 'NULL'}`)
    console.log(`    Provider Source: ${row.provider_source}`)
    console.log(`    Snapshot At: ${new Date(row.snapshot_at).toLocaleString()}`)
  })

  // Check for duplicate keys (shouldn't exist with unique constraint)
  const keys = data.map(r => `${r.region_code}_${r.size_key}_${r.is_consigned}`)
  const uniqueKeys = new Set(keys)
  const duplicates = keys.length - uniqueKeys.size

  console.log(`\nDUPLICATE CHECK:`)
  console.log(`  Total records: ${data.length}`)
  console.log(`  Unique keys: ${uniqueKeys.size}`)
  console.log(`  Duplicates: ${duplicates} ${duplicates > 0 ? '❌' : '✅'}`)

  // Check provider_variant_id (should be NULL for Alias)
  const withVariantId = data.filter(r => r.provider_variant_id !== null).length
  console.log(`\nPROVIDER VARIANT ID:`)
  console.log(`  With variant_id: ${withVariantId} ${withVariantId > 0 ? '⚠️  (unexpected for Alias)' : '✅'}`)

  // Final assessment
  console.log('\n' + '='.repeat(80))
  if (issues.length === 0 && data.length > 0) {
    console.log('✅ DATA QUALITY: EXCELLENT')
    console.log(`   ${data.length} records with no critical issues`)
  } else if (data.length === 0) {
    console.log('❌ DATA QUALITY: FAILED - NO DATA')
  } else {
    console.log('⚠️  DATA QUALITY: ISSUES FOUND')
    issues.forEach(issue => console.log(`   - ${issue}`))
  }
  console.log('='.repeat(80))
}

checkDataQuality()
