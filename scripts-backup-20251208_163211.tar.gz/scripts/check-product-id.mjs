import { createClient } from '@supabase/supabase-js'
import 'dotenv/config'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

const stockxProductId = '15795a80-5cc8-4d2d-9ed0-20250d83be7f'

// Check if there's a product_catalog entry for this stockx_product_id
const { data, error } = await supabase
  .from('product_catalog')
  .select('id, sku')
  .eq('stockx_product_id', stockxProductId)
  .single()

if (error) {
  console.error('Error:', error)
} else {
  console.log('✅ Found product_catalog entry:')
  console.log('  product_id:', data.id)
  console.log('  sku:', data.sku)
}
