#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function debug() {
  console.log('Checking master_market_data table...\n');

  // Get all StockX data
  const { data: allData } = await supabase
    .from('master_market_data')
    .select('provider_product_id, sku, region_code, created_at')
    .eq('provider', 'stockx')
    .order('created_at', { ascending: true });

  console.log(`Total rows: ${allData?.length || 0}`);

  // Get unique products by provider_product_id
  const uniqueProductIds = new Set(allData?.map(r => r.provider_product_id));
  console.log(`Unique provider_product_ids: ${uniqueProductIds.size}`);

  // Get unique products by SKU
  const uniqueSkus = new Set(allData?.map(r => r.sku).filter(Boolean));
  console.log(`Unique SKUs: ${uniqueSkus.size}`);

  // List first 30 unique SKUs
  console.log('\nFirst 30 unique SKUs:');
  Array.from(uniqueSkus).slice(0, 30).forEach((sku, i) => {
    const rows = allData?.filter(r => r.sku === sku).length || 0;
    const regions = new Set(allData?.filter(r => r.sku === sku).map(r => r.region_code));
    console.log(`  ${i + 1}. ${sku} - ${rows} rows - regions: ${Array.from(regions).join(',')}`);
  });

  // Check timestamps
  if (allData && allData.length > 0) {
    const firstTimestamp = allData[0].created_at;
    const lastTimestamp = allData[allData.length - 1].created_at;
    console.log(`\nFirst created: ${firstTimestamp}`);
    console.log(`Last created: ${lastTimestamp}`);
  }
}

debug();
