#!/usr/bin/env node

/**
 * Debug eBay results - show dates, prices, and sizes
 */

import 'dotenv/config'
import { EbayClient } from '../src/lib/services/ebay/client'
import { enrichEbaySoldItem } from '../src/lib/services/ebay/extractors'

const SKU = process.argv[2] || 'DZ4137-700'

async function main() {
  const client = new EbayClient()

  console.log('\n' + '═'.repeat(80))
  console.log('eBay API Results Debug')
  console.log('═'.repeat(80) + '\n')

  const result = await client.searchSold({
    query: SKU,
    limit: 50,
    conditionIds: [1000],
    qualifiedPrograms: ['AUTHENTICITY_GUARANTEE'],
    categoryIds: ['15709', '95672', '155194'],
    soldItemsOnly: true,
    fetchFullDetails: true,
  })

  console.log(`Total items: ${result.items.length}\n`)

  // Enrich
  result.items.forEach((item) => {
    enrichEbaySoldItem(item)
  })

  // Show each item with date, price, size
  console.log('ALL ITEMS (with dates):')
  console.log('─'.repeat(80))

  result.items.forEach((item, i) => {
    const size = item.sizeInfo?.normalizedKey || 'NO SIZE'
    const date = new Date(item.soldAt).toISOString().split('T')[0]
    const title = item.title.substring(0, 50)

    console.log(`${String(i + 1).padStart(2, '0')}. ${date} | ${item.currency} ${String(item.price).padStart(7)} | ${size.padEnd(10)} | ${title}`)
  })

  console.log('\n' + '═'.repeat(80))
  console.log('SORTED BY PRICE (lowest first):')
  console.log('═'.repeat(80) + '\n')

  const sortedByPrice = [...result.items].sort((a, b) => a.price - b.price)

  sortedByPrice.forEach((item, i) => {
    const size = item.sizeInfo?.normalizedKey || 'NO SIZE'
    const date = new Date(item.soldAt).toISOString().split('T')[0]

    console.log(`${i + 1}. ${item.currency} ${String(item.price).padStart(7)} | ${size.padEnd(10)} | ${date}`)
  })

  console.log('\n' + '═'.repeat(80))
  console.log('SIZE DISTRIBUTION:')
  console.log('═'.repeat(80) + '\n')

  const sizeCount: Record<string, number> = {}
  result.items.forEach(item => {
    const size = item.sizeInfo?.normalizedKey || 'NO SIZE'
    sizeCount[size] = (sizeCount[size] || 0) + 1
  })

  Object.entries(sizeCount).sort().forEach(([size, count]) => {
    console.log(`${size.padEnd(10)} : ${count} items`)
  })

  console.log('\n' + '═'.repeat(80) + '\n')
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message)
  process.exit(1)
})
