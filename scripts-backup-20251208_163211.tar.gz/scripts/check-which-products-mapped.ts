#!/usr/bin/env npx tsx
/**
 * Check which products have StockX mappings
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  const { data: products } = await supabase
    .from('products')
    .select(`
      id,
      sku,
      product_variants (
        id,
        size_key,
        stockx_product_id
      )
    `)
    .order('sku')

  console.log('\n📊 StockX Mapping Coverage by Product\n')

  let mappedProducts = 0
  let unmappedProducts = 0

  products?.forEach((p: any) => {
    const variantsWithStockX = p.product_variants.filter((v: any) => v.stockx_product_id)
    const totalVariants = p.product_variants.length

    if (variantsWithStockX.length > 0) {
      mappedProducts++
      const stockxIds = new Set(variantsWithStockX.map((v: any) => v.stockx_product_id))
      console.log(`✅ ${p.sku}: ${variantsWithStockX.length}/${totalVariants} variants mapped to ${stockxIds.size} StockX ID(s)`)

      if (stockxIds.size > 1) {
        console.log(`   ⚠️  WARNING: Multiple StockX IDs for same product!`)
        stockxIds.forEach(id => {
          const count = variantsWithStockX.filter((v: any) => v.stockx_product_id === id).length
          console.log(`      ${id}: ${count} variants`)
        })
      }
    } else {
      unmappedProducts++
      console.log(`❌ ${p.sku}: 0/${totalVariants} variants mapped`)
    }
  })

  console.log(`\n${'='.repeat(80)}`)
  console.log(`Summary:`)
  console.log(`  ✅ Products with StockX mapping: ${mappedProducts}`)
  console.log(`  ❌ Products without StockX mapping: ${unmappedProducts}`)
  console.log(`  📦 Total products: ${products?.length}`)
  console.log('')
}

main().catch(console.error)
