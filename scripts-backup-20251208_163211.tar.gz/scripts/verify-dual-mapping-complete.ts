#!/usr/bin/env npx tsx
/**
 * Verify Dual Mapping - Check all products have both Alias + StockX
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🔍 Verifying Dual Mapping Coverage\n')

  // Get all products with their mappings
  const { data: products } = await supabase
    .from('products')
    .select(`
      id,
      sku,
      brand,
      model,
      product_variants (
        id,
        alias_catalog_id,
        stockx_product_id
      )
    `)
    .order('sku')

  console.log(`📦 Total products: ${products?.length || 0}\n`)

  let withBoth = 0
  let withAliasOnly = 0
  let withStockXOnly = 0
  let withNeither = 0

  const examples: any[] = []

  for (const product of products || []) {
    const hasAlias = product.product_variants.some((v: any) => v.alias_catalog_id)
    const hasStockX = product.product_variants.some((v: any) => v.stockx_product_id)

    if (hasAlias && hasStockX) {
      withBoth++
      if (examples.length < 5) {
        const variant = product.product_variants[0]
        examples.push({
          sku: product.sku,
          brand: product.brand,
          model: product.model,
          aliasId: variant.alias_catalog_id,
          stockxId: variant.stockx_product_id
        })
      }
    } else if (hasAlias) {
      withAliasOnly++
      console.log(`⚠️  Alias only: ${product.sku}`)
    } else if (hasStockX) {
      withStockXOnly++
      console.log(`⚠️  StockX only: ${product.sku}`)
    } else {
      withNeither++
      console.log(`❌ Neither: ${product.sku}`)
    }
  }

  console.log('\n' + '='.repeat(80))
  console.log('📊 DUAL MAPPING VERIFICATION')
  console.log('='.repeat(80))
  console.log(`✅ Both Alias + StockX: ${withBoth}`)
  console.log(`⚠️  Alias only: ${withAliasOnly}`)
  console.log(`⚠️  StockX only: ${withStockXOnly}`)
  console.log(`❌ Neither: ${withNeither}`)
  console.log('')

  if (withBoth === products?.length) {
    console.log('🎉 SUCCESS! All products have BOTH Alias AND StockX mappings!')
  } else {
    console.log('⚠️  Some products are missing dual mappings')
  }

  console.log('\n📋 Example Dual-Mapped Products:')
  console.log('='.repeat(80))
  for (const ex of examples) {
    console.log(`\n${ex.sku} - ${ex.brand} ${ex.model}`)
    console.log(`  Alias:  ${ex.aliasId}`)
    console.log(`  StockX: ${ex.stockxId}`)
  }

  console.log('')
}

main().catch(console.error)
