import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

const { data, error } = await supabase
  .from('stockx_accounts')
  .select('*')
  .limit(5)

if (error) {
  console.log('Error:', error.message)
} else {
  console.log('StockX accounts found:', data ? data.length : 0)
  if (data && data.length > 0) {
    console.log(JSON.stringify(data, null, 2))
  }
}
