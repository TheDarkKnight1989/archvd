/**
 * Test Alias sync with BOTH consigned and non-consigned pricing
 * Verifies that both provider_source types are inserted into master_market_data
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { syncAliasToMasterMarketData } from '@/lib/services/alias/sync'
import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010' // Jordan 4 Black Cat

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('ALIAS DUAL PRICING SYNC TEST (Consigned + Non-Consigned)')
  console.log('SKU:', SKU)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  // ========================================================================
  // Step 1: Search for product
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 1: Search Catalog')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const product = searchResults.catalog_items[0]

  console.log(`Product: ${product.name}`)
  console.log(`Catalog ID: ${product.catalog_id}\n`)

  // ========================================================================
  // Step 2: Clear existing data for this SKU
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 2: Clear Existing Data')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const { data: beforeDelete } = await supabase
    .from('master_market_data')
    .select('id', { count: 'exact', head: true })
    .eq('sku', SKU)
    .eq('provider', 'alias')

  console.log(`Rows before delete: ${beforeDelete ? 'some' : 0}`)

  await supabase
    .from('master_market_data')
    .delete()
    .eq('sku', SKU)
    .eq('provider', 'alias')

  console.log('✅ Cleared existing Alias data for this SKU\n')

  // ========================================================================
  // Step 3: Run sync (fetches BOTH consigned and non-consigned)
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 3: Sync to master_market_data')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const syncResult = await syncAliasToMasterMarketData(client, product.catalog_id, {
    sku: SKU,
  })

  console.log('Sync Result:')
  console.log(JSON.stringify(syncResult, null, 2))
  console.log()

  if (!syncResult.success) {
    console.error('❌ SYNC FAILED:', syncResult.error)
    process.exit(1)
  }

  // ========================================================================
  // Step 4: Verify database - check both provider_source types
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('STEP 4: Verify Database')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  // Count by provider_source
  const { data: allRows, error: queryError } = await supabase
    .from('master_market_data')
    .select('provider_source, size_key, lowest_ask, highest_bid, last_sale_price')
    .eq('sku', SKU)
    .eq('provider', 'alias')
    .order('provider_source')
    .order('size_numeric')

  if (queryError) {
    console.error('❌ Query error:', queryError)
    process.exit(1)
  }

  if (!allRows || allRows.length === 0) {
    console.error('❌ NO ROWS FOUND IN DATABASE!')
    console.error('Expected to find rows with provider_source:')
    console.error('  - alias_availabilities (non-consigned)')
    console.error('  - alias_availabilities_consigned (consigned)')
    process.exit(1)
  }

  const nonConsignedRows = allRows.filter(r => r.provider_source === 'alias_availabilities')
  const consignedRows = allRows.filter(r => r.provider_source === 'alias_availabilities_consigned')

  console.log('RESULTS BY PROVIDER SOURCE:')
  console.log(`  alias_availabilities (non-consigned): ${nonConsignedRows.length} rows`)
  console.log(`  alias_availabilities_consigned: ${consignedRows.length} rows`)
  console.log(`  TOTAL: ${allRows.length} rows\n`)

  // Show sample non-consigned pricing
  if (nonConsignedRows.length > 0) {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('SAMPLE NON-CONSIGNED PRICING (first 5 sizes)')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    for (const row of nonConsignedRows.slice(0, 5)) {
      console.log(`Size ${row.size_key}:`)
      console.log(`  Lowest Ask: $${row.lowest_ask || 0}`)
      console.log(`  Highest Bid: $${row.highest_bid || 0}`)
      console.log(`  Last Sale: $${row.last_sale_price || 0}`)
      console.log()
    }
  } else {
    console.log('⚠️  NO NON-CONSIGNED ROWS FOUND\n')
  }

  // Show sample consigned pricing
  if (consignedRows.length > 0) {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('SAMPLE CONSIGNED PRICING (first 5 sizes)')
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

    for (const row of consignedRows.slice(0, 5)) {
      console.log(`Size ${row.size_key}:`)
      console.log(`  Lowest Ask: $${row.lowest_ask || 0}`)
      console.log(`  Highest Bid: $${row.highest_bid || 0}`)
      console.log(`  Last Sale: $${row.last_sale_price || 0}`)
      console.log()
    }
  } else {
    console.log('⚠️  NO CONSIGNED ROWS FOUND\n')
  }

  // ========================================================================
  // Final verification
  // ========================================================================

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('FINAL VERIFICATION')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const hasNonConsigned = nonConsignedRows.length > 0
  const hasConsigned = consignedRows.length > 0
  const hasNonConsignedPricing = nonConsignedRows.some(r => r.lowest_ask > 0 || r.highest_bid > 0)
  const hasConsignedPricing = consignedRows.some(r => r.lowest_ask > 0 || r.highest_bid > 0)

  if (hasNonConsigned && hasConsigned) {
    console.log('✅ BOTH provider_source types present in database')
  } else if (hasNonConsigned) {
    console.log('⚠️  ONLY non-consigned data found (missing consigned)')
  } else if (hasConsigned) {
    console.log('⚠️  ONLY consigned data found (missing non-consigned)')
  } else {
    console.log('❌ NO DATA FOUND!')
  }

  if (hasNonConsignedPricing) {
    console.log('✅ Non-consigned pricing has real values')
  } else if (hasNonConsigned) {
    console.log('⚠️  Non-consigned rows exist but all prices are $0')
  }

  if (hasConsignedPricing) {
    console.log('✅ Consigned pricing has real values')
  } else if (hasConsigned) {
    console.log('⚠️  Consigned rows exist but all prices are $0')
  }

  console.log()

  if (hasNonConsigned && hasConsigned && hasNonConsignedPricing && hasConsignedPricing) {
    console.log('🎉 SUCCESS! Dual pricing sync working perfectly!')
    console.log('   - Both consigned and non-consigned data stored')
    console.log('   - Both have real pricing values')
    console.log('   - Ready for production use')
  } else {
    console.log('⚠️  Partial success - see warnings above')
  }

  console.log()
  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
