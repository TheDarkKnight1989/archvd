#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function investigate() {
  console.log('🔍 PRODUCT CATALOG INVESTIGATION\n');
  console.log('═'.repeat(80) + '\n');

  // Get all products
  const { data: allProducts } = await supabase
    .from('product_catalog')
    .select('sku, brand, stockx_product_id, alias_catalog_id, gender, category')
    .order('sku');

  console.log('TOTAL PRODUCTS:', allProducts?.length || 0, '\n');

  // Categorize products
  const withStockX = allProducts?.filter(p => p.stockx_product_id) || [];
  const withAlias = allProducts?.filter(p => p.alias_catalog_id) || [];
  const withNeither = allProducts?.filter(p => !p.stockx_product_id && !p.alias_catalog_id) || [];
  const withBoth = allProducts?.filter(p => p.stockx_product_id && p.alias_catalog_id) || [];

  console.log('MAPPING STATUS:\n');
  console.log('  Products with StockX ID:  ', withStockX.length);
  console.log('  Products with Alias ID:   ', withAlias.length);
  console.log('  Products with BOTH:       ', withBoth.length);
  console.log('  Products with NEITHER:    ', withNeither.length);

  console.log('\n' + '─'.repeat(80) + '\n');
  console.log('PRODUCTS WITH STOCKX IDS:\n');
  withStockX.forEach((p, i) => {
    console.log(`  ${(i+1).toString().padStart(2)}. ${p.sku.padEnd(15)} | ${(p.brand || 'NULL').padEnd(15)} | Gender: ${p.gender || 'NULL'}`);
  });

  console.log('\n' + '─'.repeat(80) + '\n');
  console.log('PRODUCTS WITHOUT ANY MAPPING (sample of first 20):\n');
  withNeither.slice(0, 20).forEach((p, i) => {
    console.log(`  ${(i+1).toString().padStart(2)}. ${p.sku.padEnd(15)} | ${(p.brand || 'NULL').padEnd(15)}`);
  });

  if (withNeither.length > 20) {
    console.log(`\n  ... and ${withNeither.length - 20} more\n`);
  }

  // Check stockx_products table
  console.log('\n' + '─'.repeat(80) + '\n');
  console.log('STOCKX_PRODUCTS TABLE:\n');

  const { count: stockxProductsCount } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact', head: true });

  console.log('  Total entries in stockx_products:', stockxProductsCount);

  const { data: stockxProducts } = await supabase
    .from('stockx_products')
    .select('style_id, stockx_product_id, brand')
    .order('style_id')
    .limit(20);

  console.log('\n  Sample entries:\n');
  stockxProducts?.forEach((p, i) => {
    console.log(`    ${(i+1).toString().padStart(2)}. SKU: ${p.style_id.padEnd(15)} | Brand: ${(p.brand || 'NULL').padEnd(15)}`);
  });

  console.log('\n' + '═'.repeat(80));
  console.log('\nCONCLUSION:\n');
  console.log('The product_catalog table has', allProducts?.length, 'products total.');
  console.log('Of these, only', withStockX.length, 'have been mapped to StockX.');
  console.log('The stockx_products table has', stockxProductsCount, 'entries.');
  console.log('\nThis suggests the mapping between product_catalog and stockx_products');
  console.log('may be incomplete - there might be more products that could be synced.');
}

investigate();
