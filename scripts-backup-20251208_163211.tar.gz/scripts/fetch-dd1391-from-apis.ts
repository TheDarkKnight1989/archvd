#!/usr/bin/env npx tsx

/**
 * Fetch DD1391-100 market data from StockX and Alias APIs
 * Display clean format: one line per size showing all price points
 */

import { getCatalogService } from '../src/lib/services/stockx/catalog'
import { StockxMarketService } from '../src/lib/services/stockx/market'
import { createAliasClient } from '../src/lib/services/alias/client'

const SKU = 'DD1391-100'
const UK_SIZES = [6, 7, 8, 9, 10, 11, 12]

interface PriceData {
  size: number
  stockx_ask: string
  stockx_bid: string
  alias_ask: string
  alias_bid: string
  alias_last_sale: string
}

async function fetchStockXData(): Promise<Map<number, { ask: string; bid: string }>> {
  const priceMap = new Map<number, { ask: string; bid: string }>()

  try {
    console.log('🔍 Searching StockX for', SKU)

    // Search for product
    const catalogService = getCatalogService()
    const searchResults = await catalogService.searchProducts(SKU)

    if (!searchResults || searchResults.length === 0) {
      console.log('❌ StockX: Product not found')
      return priceMap
    }

    const product = searchResults[0]
    console.log('✅ StockX: Found product', product.productId)

    // Get variants for this product
    const variants = await catalogService.getProductVariants(product.productId)
    console.log('📊 StockX: Got', variants.length, 'variants with size info')

    // Get market data for all variants
    const marketData = await StockxMarketService.getProductMarketData(
      product.productId,
      'GBP'
    )
    console.log('📊 StockX: Got market data for', marketData.length, 'variants')

    // Build a map of variantId -> market data
    const marketDataMap = new Map(
      marketData.map(v => [v.variantId, v])
    )

    // Match variants with market data
    for (const variant of variants) {
      const marketInfo = marketDataMap.get(variant.variantId)
      if (!marketInfo) continue

      // Parse size from variantValue (e.g., "7" or "7.0")
      const sizeUS = parseFloat(variant.variantValue || '0')
      const sizeUK = sizeUS - 1

      if (UK_SIZES.includes(sizeUK)) {
        const askValue = marketInfo.lowestAsk
          ? parseFloat(marketInfo.lowestAsk.toString())
          : null
        const bidValue = marketInfo.highestBid
          ? parseFloat(marketInfo.highestBid.toString())
          : null

        const ask = askValue ? `£${askValue.toFixed(2)}` : '-'
        const bid = bidValue ? `£${bidValue.toFixed(2)}` : '-'

        priceMap.set(sizeUK, { ask, bid })
      }
    }

    console.log(`✅ StockX: Collected ${priceMap.size} sizes\n`)
  } catch (error: any) {
    console.error('❌ StockX Error:', error.message)
  }

  return priceMap
}

async function fetchAliasData(): Promise<
  Map<number, { ask: string; bid: string; lastSale: string }>
> {
  const priceMap = new Map<number, { ask: string; bid: string; lastSale: string }>()

  try {
    console.log('🔍 Searching Alias for', SKU)
    const aliasClient = createAliasClient()

    // Search catalog
    const searchResults = await aliasClient.searchCatalog(SKU)
    if (!searchResults?.items || searchResults.items.length === 0) {
      console.log('❌ Alias: Product not found')
      return priceMap
    }

    const catalogItem = searchResults.items[0]
    const catalogId = catalogItem.id
    console.log('✅ Alias: Found catalog ID', catalogId)

    // Get pricing insights for all variations
    const pricingData = await aliasClient.listPricingInsights(catalogId)
    console.log('📊 Alias: Got pricing data')

    // Get recent sales for last sale prices
    const recentSales = await aliasClient.getRecentSales({
      catalog_id: catalogId,
      limit: 100,
    })

    // Build a map of size -> last sale price
    const lastSaleMap = new Map<number, number>()
    if (recentSales?.sales) {
      for (const sale of recentSales.sales) {
        if (!lastSaleMap.has(sale.size)) {
          lastSaleMap.set(sale.size, sale.price_cents)
        }
      }
    }

    // Extract pricing by size
    if (pricingData?.availabilities) {
      for (const avail of pricingData.availabilities) {
        const sizeValue = avail.size
        const sizeUK = Math.round(sizeValue)

        if (UK_SIZES.includes(sizeUK)) {
          const ask = avail.lowest_listing_price_cents
            ? `$${(avail.lowest_listing_price_cents / 100).toFixed(2)}`
            : '-'
          const bid = avail.highest_offer_price_cents
            ? `$${(avail.highest_offer_price_cents / 100).toFixed(2)}`
            : '-'
          const lastSale = lastSaleMap.has(sizeValue)
            ? `$${(lastSaleMap.get(sizeValue)! / 100).toFixed(2)}`
            : '-'

          priceMap.set(sizeUK, { ask, bid, lastSale })
        }
      }
    }

    console.log(`✅ Alias: Collected ${priceMap.size} sizes\n`)
  } catch (error: any) {
    console.error('❌ Alias Error:', error.message)
  }

  return priceMap
}

async function main() {
  console.log('\n' + '='.repeat(120))
  console.log(`SKU: ${SKU} - Market Data from APIs`)
  console.log('='.repeat(120) + '\n')

  // Fetch from both APIs in parallel
  const [stockxData, aliasData] = await Promise.all([
    fetchStockXData(),
    fetchAliasData(),
  ])

  // Print header
  console.log(
    'SIZE'.padEnd(10) +
      'STOCKX ASK'.padEnd(16) +
      'STOCKX BID'.padEnd(16) +
      'ALIAS ASK'.padEnd(16) +
      'ALIAS BID'.padEnd(16) +
      'ALIAS LAST SALE'.padEnd(16)
  )
  console.log('='.repeat(120))

  // Print each size
  for (const sizeUK of UK_SIZES) {
    const stockx = stockxData.get(sizeUK)
    const alias = aliasData.get(sizeUK)

    console.log(
      `UK ${sizeUK}`.padEnd(10) +
        (stockx?.ask || '-').padEnd(16) +
        (stockx?.bid || '-').padEnd(16) +
        (alias?.ask || '-').padEnd(16) +
        (alias?.bid || '-').padEnd(16) +
        (alias?.lastSale || '-').padEnd(16)
    )
  }

  console.log('='.repeat(120))
  console.log('\nNOTES:')
  console.log('- StockX prices are in GBP (£)')
  console.log('- Alias prices are in USD ($)')
  console.log('- Alias Last Sale = most recent completed transaction')
  console.log('='.repeat(120) + '\n')
}

main().catch(console.error)
