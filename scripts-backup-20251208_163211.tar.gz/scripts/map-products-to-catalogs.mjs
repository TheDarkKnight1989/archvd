#!/usr/bin/env node
/**
 * Map products to Alias/StockX catalog IDs
 *
 * For each product without catalog mappings:
 * 1. Search Alias API by SKU
 * 2. Search StockX API by SKU
 * 3. Update product with brand/model/colorway/image
 * 4. Update variants with catalog IDs
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('🔍 Mapping products to catalog IDs...\n')

// Get products without Alias catalog IDs
const { data: products } = await supabase
  .from('products')
  .select(`
    id,
    sku,
    brand,
    model,
    colorway,
    image_url,
    product_variants (
      id,
      alias_catalog_id,
      stockx_product_id,
      stockx_variant_id
    )
  `)
  .eq('brand', 'Unknown') // Products that weren't mapped during seeding

console.log(`Found ${products?.length || 0} products to map\n`)

let aliasFound = 0
let stockxFound = 0
let notFound = 0
let errors = 0

for (const product of products || []) {
  try {
    console.log(`Processing: ${product.sku}`)

    // Check if any variant already has mapping
    const hasAlias = product.product_variants.some(v => v.alias_catalog_id)
    const hasStockX = product.product_variants.some(v => v.stockx_product_id)

    if (hasAlias && hasStockX) {
      console.log('  ⏭️  Already mapped')
      continue
    }

    let updated = false

    // Try Alias first
    if (!hasAlias) {
      const aliasData = await searchAlias(product.sku)
      if (aliasData) {
        await updateProductWithAlias(product, aliasData)
        aliasFound++
        updated = true
        console.log(`  ✅ Mapped to Alias: ${aliasData.catalogId}`)
      }
    }

    // Try StockX
    if (!hasStockX) {
      const stockxData = await searchStockX(product.sku)
      if (stockxData) {
        await updateProductWithStockX(product, stockxData)
        stockxFound++
        updated = true
        console.log(`  ✅ Mapped to StockX: ${stockxData.productId}`)
      }
    }

    if (!updated) {
      console.log('  ⚠️  Not found in catalogs')
      notFound++
    }

    // Rate limit
    await new Promise(resolve => setTimeout(resolve, 1000))

  } catch (error) {
    console.log(`  ❌ Error: ${error.message}`)
    errors++
  }
}

console.log('\n' + '='.repeat(80))
console.log('📊 MAPPING COMPLETE')
console.log('='.repeat(80))
console.log(`✅ Mapped to Alias: ${aliasFound}`)
console.log(`✅ Mapped to StockX: ${stockxFound}`)
console.log(`⚠️  Not found: ${notFound}`)
console.log(`❌ Errors: ${errors}`)
console.log(`📦 Total processed: ${products?.length || 0}`)
console.log('')

// Search Alias catalog by SKU
async function searchAlias(sku) {
  try {
    // Search in existing alias_catalog_items table
    const normalizedSku = sku.toUpperCase().replace(/[-\s]/g, ' ')

    const { data } = await supabase
      .from('alias_catalog_items')
      .select('*')
      .or(`sku.eq.${normalizedSku},sku.eq.${sku},sku.eq.${sku.replace(/[-\s]/g, '')}`)
      .maybeSingle()

    if (data) {
      return {
        catalogId: data.catalog_id,
        brand: data.brand,
        model: data.model,
        colorway: data.colorway,
        imageUrl: data.image_url
      }
    }

    // TODO: If not in local DB, query Alias API directly
    // For now, we only use cached catalog items
    return null

  } catch (error) {
    console.error(`    Alias search error: ${error.message}`)
    return null
  }
}

// Search StockX catalog by SKU
async function searchStockX(sku) {
  try {
    // Search in existing stockx_products table
    const normalizedSku = sku.toUpperCase().replace(/[-\s]/g, ' ')

    const { data } = await supabase
      .from('stockx_products')
      .select('*')
      .or(`style_id.eq.${normalizedSku},style_id.eq.${sku},style_id.eq.${sku.replace(/[-\s]/g, '')}`)
      .maybeSingle()

    if (data) {
      return {
        productId: data.stockx_product_id,
        brand: data.brand,
        model: data.title,
        colorway: data.colorway,
        imageUrl: data.image_url
      }
    }

    // TODO: If not in local DB, query StockX API directly
    return null

  } catch (error) {
    console.error(`    StockX search error: ${error.message}`)
    return null
  }
}

// Update product with Alias data
async function updateProductWithAlias(product, aliasData) {
  // Update product details
  await supabase
    .from('products')
    .update({
      brand: aliasData.brand || product.brand,
      model: aliasData.model || product.model,
      colorway: aliasData.colorway,
      image_url: aliasData.imageUrl || product.image_url
    })
    .eq('id', product.id)

  // Update all variants with catalog ID
  await supabase
    .from('product_variants')
    .update({
      alias_catalog_id: aliasData.catalogId
    })
    .eq('product_id', product.id)
}

// Update product with StockX data
async function updateProductWithStockX(product, stockxData) {
  // Update product details (only if not already set)
  const updates = {}
  if (product.brand === 'Unknown' || !product.brand) {
    updates.brand = stockxData.brand
  }
  if (!product.model || product.model === product.sku) {
    updates.model = stockxData.model
  }
  if (!product.colorway) {
    updates.colorway = stockxData.colorway
  }
  if (!product.image_url) {
    updates.image_url = stockxData.imageUrl
  }

  if (Object.keys(updates).length > 0) {
    await supabase
      .from('products')
      .update(updates)
      .eq('id', product.id)
  }

  // Update all variants with StockX product ID
  await supabase
    .from('product_variants')
    .update({
      stockx_product_id: stockxData.productId
    })
    .eq('product_id', product.id)
}
