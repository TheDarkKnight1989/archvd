#!/usr/bin/env npx tsx
/**
 * Test Alias API Pricing Endpoints (bypassing broken /regions)
 */

import { createAliasClient } from '@/lib/services/alias/client'

async function main() {
  console.log('🧪 Testing Alias API Pricing Endpoints\n')

  const client = createAliasClient()
  const catalogId = '2002r-protection-pack-phantom-m2002rdb'

  // Known working region IDs: 1=US, 2=EU, 3=UK
  const regions = [
    { id: '1', name: 'United States' },
    { id: '2', name: 'Europe' },
    { id: '3', name: 'United Kingdom' },
  ]

  try {
    console.log('1. Testing catalog endpoint...')
    const catalogItem = await client.getCatalogItem(catalogId)
    console.log(`  ✅ SUCCESS - Found product: ${catalogItem.name}`)

    console.log('\n2. Testing pricing insights for each region...')
    let totalVariants = 0

    for (const region of regions) {
      try {
        const pricing = await client.listPricingInsights(catalogId, region.id)
        const variantCount = pricing.variants?.length || 0
        totalVariants += variantCount
        console.log(`  ✅ ${region.name} (region ${region.id}): ${variantCount} variants`)

        if (variantCount > 0) {
          const firstVariant = pricing.variants[0]
          console.log(`     Sample: Size ${firstVariant.size}, Lowest Ask: $${firstVariant.availability?.lowest_listing_price_cents ? parseInt(firstVariant.availability.lowest_listing_price_cents) / 100 : 'N/A'}`)
        }
      } catch (error: any) {
        console.log(`  ❌ ${region.name} (region ${region.id}): ${error.message}`)
      }
    }

    console.log(`\n✅ ALIAS API WORKING!`)
    console.log(`   Total variants across all regions: ${totalVariants}`)
    console.log(`   Critical pricing endpoints functional!`)
  } catch (error: any) {
    console.error('\n❌ ALIAS API FAILED:', error.message)
    if (error.statusCode) {
      console.log(`   Status: ${error.statusCode}`)
    }
  }
}

main().catch(console.error)
