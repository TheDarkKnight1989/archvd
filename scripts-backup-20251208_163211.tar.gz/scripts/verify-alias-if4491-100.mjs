#!/usr/bin/env node
/**
 * Simple verification of Alias integration for IF4491-100
 * Reports exactly what we have with no errors
 */

import { createClient } from '@supabase/supabase-js'
import 'dotenv/config'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase credentials')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

const TEST_SKU = 'IF4491-100'

console.log('\n🧪 ALIAS INTEGRATION TEST: ' + TEST_SKU)
console.log('='.repeat(80))

let totalPassed = 0
let totalFailed = 0

// Test 1: Check master_market_data for Alias entries
console.log('\n1️⃣  MASTER_MARKET_DATA (Alias provider)')
const { data: aliasMarket, error: aliasMarketErr } = await supabase
  .from('master_market_data')
  .select('size_numeric, size_key, lowest_ask, highest_bid, last_sale_price, sales_last_72h, region_code, snapshot_at')
  .eq('sku', TEST_SKU)
  .eq('provider', 'alias')
  .limit(10)

if (aliasMarketErr) {
  console.log('   ❌ ERROR:', aliasMarketErr.message)
  totalFailed++
} else if (!aliasMarket || aliasMarket.length === 0) {
  console.log('   ❌ NO DATA FOUND')
  totalFailed++
} else {
  console.log('   ✅ FOUND:', aliasMarket.length, 'rows')
  const sample = aliasMarket[0]
  const formatPrice = (val) => val ? `£${(val / 100).toFixed(2)}` : 'N/A'
  console.log('   📊 Sample:', {
    size: sample.size_key || sample.size_numeric,
    lowestAsk: formatPrice(sample.lowest_ask),
    highestBid: formatPrice(sample.highest_bid),
    lastSale: formatPrice(sample.last_sale_price),
    salesLast72h: sample.sales_last_72h || 0,
    region: sample.region_code,
    updated: new Date(sample.snapshot_at).toLocaleString()
  })
  totalPassed++
}

// Test 2: Check alias_recent_sales_detail
console.log('\n2️⃣  ALIAS_RECENT_SALES_DETAIL')
const { data: salesDetail, error: salesErr } = await supabase
  .from('alias_recent_sales_detail')
  .select('*')
  .eq('sku', TEST_SKU)
  .limit(5)

if (salesErr) {
  console.log('   ❌ ERROR:', salesErr.message)
  totalFailed++
} else if (!salesDetail || salesDetail.length === 0) {
  console.log('   ❌ NO DATA FOUND')
  totalFailed++
} else {
  console.log('   ✅ FOUND:', salesDetail.length, 'sales')
  const sample = salesDetail[0]
  console.log('   📊 Sample:', {
    size: sample.size_value,
    price: sample.price_cents,
    purchasedAt: new Date(sample.purchased_at).toLocaleString(),
    region: sample.region_code
  })
  totalPassed++
}

// Test 3: Check alias_raw_snapshots
console.log('\n3️⃣  ALIAS_RAW_SNAPSHOTS')
const { data: rawSnaps, error: rawErr } = await supabase
  .from('alias_raw_snapshots')
  .select('id, endpoint, region_code, created_at')
  .order('created_at', { ascending: false })
  .limit(5)

if (rawErr) {
  console.log('   ❌ ERROR:', rawErr.message)
  totalFailed++
} else if (!rawSnaps || rawSnaps.length === 0) {
  console.log('   ❌ NO DATA FOUND')
  totalFailed++
} else {
  console.log('   ✅ FOUND:', rawSnaps.length, 'snapshots')
  const sample = rawSnaps[0]
  console.log('   📊 Latest:', {
    endpoint: sample.endpoint,
    region: sample.region_code,
    createdAt: new Date(sample.created_at).toLocaleString()
  })
  totalPassed++
}

// Test 4: Check product_catalog for price bounds
console.log('\n4️⃣  PRODUCT_CATALOG (Price Bounds)')
const { data: product, error: prodErr } = await supabase
  .from('product_catalog')
  .select('sku, min_listing_price, max_listing_price')
  .eq('sku', TEST_SKU)
  .single()

if (prodErr) {
  console.log('   ❌ ERROR:', prodErr.message)
  totalFailed++
} else if (!product.min_listing_price || !product.max_listing_price) {
  console.log('   ❌ PRICE BOUNDS NOT SET')
  console.log('   📊 Current:', {
    min: product.min_listing_price,
    max: product.max_listing_price
  })
  totalFailed++
} else {
  console.log('   ✅ PRICE BOUNDS SET')
  console.log('   📊 Range: £' + (product.min_listing_price / 100).toFixed(2) + ' - £' + (product.max_listing_price / 100).toFixed(2))
  totalPassed++
}

// Summary
console.log('\n' + '='.repeat(80))
console.log('RESULTS')
console.log('='.repeat(80))
console.log('✅ Passed:', totalPassed + '/4')
console.log('❌ Failed:', totalFailed + '/4')

if (totalFailed === 0) {
  console.log('\n🎉 100% PASS - Alias integration is working perfectly!')
  console.log('✨ Ready to ship!\n')
  process.exit(0)
} else {
  console.log('\n⚠️  Some tests failed - see details above')
  console.log('Next: Run Alias sync to populate missing data\n')
  process.exit(1)
}
