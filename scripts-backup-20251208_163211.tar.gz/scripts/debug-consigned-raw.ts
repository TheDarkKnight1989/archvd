/**
 * Show FULL raw consigned response to see what fields exist
 */

import { createAliasClient } from '@/lib/services/alias/client'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('RAW CONSIGNED API RESPONSE INSPECTOR')
  console.log('SKU:', SKU)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()

  // Search for product
  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const product = searchResults.catalog_items[0]

  console.log(`Product: ${product.name}`)
  console.log(`Catalog ID: ${product.catalog_id}\n`)

  // Fetch consigned=true
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('FETCHING: consigned=true')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const consignedData = await client.listPricingInsights(product.catalog_id, undefined, true)

  console.log('COMPLETE RAW RESPONSE:')
  console.log(JSON.stringify(consignedData, null, 2))
  console.log()

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('FIRST VARIANT ANALYSIS')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const firstVariant = consignedData.variants[0]
  console.log('All fields present:')
  for (const [key, value] of Object.entries(firstVariant)) {
    console.log(`  ${key}: ${typeof value === 'object' ? JSON.stringify(value) : value}`)
  }
  console.log()

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('CHECKING ALL VARIANTS FOR NON-ZERO PRICES')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const variantsWithPrices = consignedData.variants.filter(v => {
    if (!v.availability) return false
    const hasLowestAsk = v.availability.lowest_listing_price_cents && parseInt(v.availability.lowest_listing_price_cents) > 0
    const hasHighestBid = v.availability.highest_offer_price_cents && parseInt(v.availability.highest_offer_price_cents) > 0
    const hasLastSale = v.availability.last_sold_listing_price_cents && parseInt(v.availability.last_sold_listing_price_cents) > 0
    return hasLowestAsk || hasHighestBid || hasLastSale
  })

  console.log(`Variants with non-zero prices: ${variantsWithPrices.length} / ${consignedData.variants.length}`)
  console.log()

  if (variantsWithPrices.length > 0) {
    console.log('VARIANTS WITH ACTUAL PRICES:')
    for (const variant of variantsWithPrices.slice(0, 10)) {
      console.log(`\nSize ${variant.size}:`)
      console.log(`  Condition: ${variant.product_condition}`)
      console.log(`  Packaging: ${variant.packaging_condition}`)
      console.log(`  Consigned: ${variant.consigned}`)
      if (variant.availability) {
        const ask = variant.availability.lowest_listing_price_cents ? parseInt(variant.availability.lowest_listing_price_cents) : 0
        const bid = variant.availability.highest_offer_price_cents ? parseInt(variant.availability.highest_offer_price_cents) : 0
        const sale = variant.availability.last_sold_listing_price_cents ? parseInt(variant.availability.last_sold_listing_price_cents) : 0
        console.log(`  Lowest Ask: $${ask / 100}`)
        console.log(`  Highest Bid: $${bid / 100}`)
        console.log(`  Last Sale: $${sale / 100}`)
      }
    }
  } else {
    console.log('⚠️  NO VARIANTS WITH NON-ZERO PRICES FOUND')
    console.log('This suggests the consigned pricing is stored differently or needs different parameters')
  }
  console.log()

  // Compare consigned=false for reference
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('FOR COMPARISON: consigned=false (first variant)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const nonConsignedData = await client.listPricingInsights(product.catalog_id, undefined, false)
  const nonConsignedFirst = nonConsignedData.variants[0]

  console.log('All fields present:')
  for (const [key, value] of Object.entries(nonConsignedFirst)) {
    console.log(`  ${key}: ${typeof value === 'object' ? JSON.stringify(value) : value}`)
  }
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
