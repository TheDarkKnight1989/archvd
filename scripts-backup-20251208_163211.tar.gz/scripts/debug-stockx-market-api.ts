/**
 * Debug StockX Market Data API
 * Shows the exact API endpoint and payload
 */

import { StockxCatalogService } from '@/lib/services/stockx/catalog'

const STOCKX_PRODUCT_ID = '15795a80-5cc8-4d2d-9ed0-20250d83be7f' // FV5029-010
const CURRENCY = 'GBP'

async function main() {
  console.log('================================================================================')
  console.log('StockX Market Data API Debug')
  console.log('================================================================================\n')

  console.log('📋 Request Details:')
  console.log('   Endpoint: GET /v2/catalog/products/{productId}/market-data')
  console.log('   Product ID:', STOCKX_PRODUCT_ID)
  console.log('   Currency:', CURRENCY)
  console.log('   Full URL: https://api.stockx.com/v2/catalog/products/' + STOCKX_PRODUCT_ID + '/market-data?currencyCode=' + CURRENCY)
  console.log()

  const catalogService = new StockxCatalogService(undefined)
  const client = (catalogService as any).client

  try {
    console.log('🔄 Fetching market data from StockX...\n')

    const marketData = await client.request(
      `/v2/catalog/products/${STOCKX_PRODUCT_ID}/market-data?currencyCode=${CURRENCY}`
    )

    console.log('✅ Response received')
    console.log('   Type:', Array.isArray(marketData) ? 'Array' : 'Object')
    console.log('   Length:', Array.isArray(marketData) ? marketData.length : 'N/A')
    console.log()

    // Show first 3 variants in detail
    const variants = Array.isArray(marketData) ? marketData : marketData?.variants || []

    if (variants.length > 0) {
      console.log('📦 First 3 Variants (Full Structure):\n')

      for (let i = 0; i < Math.min(3, variants.length); i++) {
        console.log(`--- Variant ${i + 1} ---`)
        console.log(JSON.stringify(variants[i], null, 2))
        console.log()
      }

      // Check if ANY variant has size information
      console.log('🔍 Size Field Analysis:')
      console.log('   Has "size" field:', variants.some((v: any) => v.size !== undefined))
      console.log('   Has "variantValue" field:', variants.some((v: any) => v.variantValue !== undefined))
      console.log('   Has "variantName" field:', variants.some((v: any) => v.variantName !== undefined))
      console.log()

      // Show all unique keys across all variants
      const allKeys = new Set<string>()
      variants.forEach((v: any) => {
        Object.keys(v).forEach(k => allKeys.add(k))
      })
      console.log('📋 All fields in response:', Array.from(allKeys).sort().join(', '))
    }

  } catch (error: any) {
    console.error('❌ Error:', error.message)
    throw error
  }
}

main().catch(console.error)
