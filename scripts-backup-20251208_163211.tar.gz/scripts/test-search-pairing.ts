#!/usr/bin/env tsx

/**
 * Test search pairing for a specific SKU
 * Usage: npx tsx scripts/test-search-pairing.ts IH1493-600
 */

const sku = process.argv[2] || 'IH1493-600'

async function testSearchPairing() {
  console.log(`\n🔍 Testing search pairing for: ${sku}\n`)
  console.log('='.repeat(70))

  try {
    const response = await fetch(`http://localhost:3000/api/add-item/search?q=${encodeURIComponent(sku)}&limit=10`)

    if (!response.ok) {
      console.error('❌ Search failed:', response.statusText)
      process.exit(1)
    }

    const data = await response.json()

    console.log('\n📊 SEARCH RESULTS:')
    console.log(`  Total priceable: ${data.priceable?.length || 0}`)
    console.log(`  Total non-priceable: ${data.nonPriceable?.length || 0}`)
    console.log(`  Query mode: ${data.mode}`)
    console.log(`  Duration: ${data.duration_ms}ms`)

    if (data.priceable && data.priceable.length > 0) {
      console.log('\n✅ PRICEABLE RESULTS:')
      data.priceable.forEach((item: any, idx: number) => {
        console.log(`\n  ${idx + 1}. ${item.title}`)
        console.log(`     SKU: ${item.styleId}`)
        console.log(`     Source: ${item.source}`)
        console.log(`     Has StockX: ${item.hasStockx ? '✅' : '❌'}`)
        console.log(`     Has Alias: ${item.hasAlias ? '✅' : '❌'}`)
        console.log(`     StockX ID: ${item.stockxProductId || 'N/A'}`)
        console.log(`     Alias ID: ${item.aliasCatalogId || 'N/A'}`)
        console.log(`     Image: ${item.imageUrl ? '✅' : '❌'}`)

        if (!item.hasStockx && item.hasAlias) {
          console.log(`     ⚠️  ALIAS-ONLY (Why no StockX?)`)
        } else if (item.hasStockx && !item.hasAlias) {
          console.log(`     ⚠️  STOCKX-ONLY (Why no Alias?)`)
        } else if (item.hasStockx && item.hasAlias) {
          console.log(`     ✅ PAIRED CORRECTLY`)
        }
      })
    }

    console.log('\n' + '='.repeat(70))
    console.log('\n💡 Check server logs for detailed pairing diagnostics')
    console.log('   Look for: "PRE-MERGE DIAGNOSTIC" and "PAIRING STATS"\n')

  } catch (error: any) {
    console.error('❌ Error:', error.message)
    process.exit(1)
  }
}

testSearchPairing()
