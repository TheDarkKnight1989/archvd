#!/usr/bin/env node
/**
 * Simple Alias integration verification for IF4491-100
 * Just reports what exists without schema assumptions
 */

import { createClient } from '@supabase/supabase-js'
import 'dotenv/config'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ Missing Supabase credentials')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

const TEST_SKU = 'IF4491-100'

console.log('\n🧪 ALIAS INTEGRATION VERIFICATION: ' + TEST_SKU)
console.log('='.repeat(80))

let score = 0
const maxScore = 4

// Test 1: master_market_data with Alias provider
console.log('\n1. master_market_data (provider=alias)')
const { data: market, error: marketErr } = await supabase
  .from('master_market_data')
  .select('*')
  .eq('sku', TEST_SKU)
  .eq('provider', 'alias')
  .limit(1)

if (marketErr) {
  console.log('   ❌ ERROR:', marketErr.message)
} else if (!market || market.length === 0) {
  console.log('   ❌ NO DATA')
} else {
  console.log('   ✅ HAS DATA')
  console.log('   Sample:', JSON.stringify({
    size_key: market[0].size_key,
    lowest_ask: market[0].lowest_ask,
    highest_bid: market[0].highest_bid,
    last_sale_price: market[0].last_sale_price,
    region_code: market[0].region_code
  }, null, 2))
  score++
}

// Test 2: alias_recent_sales_detail
console.log('\n2. alias_recent_sales_detail')
const { data: sales, error: salesErr } = await supabase
  .from('alias_recent_sales_detail')
  .select('*')
  .eq('sku', TEST_SKU)
  .limit(1)

if (salesErr) {
  console.log('   ❌ ERROR:', salesErr.message)
} else if (!sales || sales.length === 0) {
  console.log('   ⚠️  NO DATA (table exists but empty)')
} else {
  console.log('   ✅ HAS DATA')
  score++
}

// Test 3: alias_raw_snapshots
console.log('\n3. alias_raw_snapshots')
const { data: snapshots, error: snapErr } = await supabase
  .from('alias_raw_snapshots')
  .select('*')
  .limit(1)

if (snapErr) {
  console.log('   ❌ ERROR:', snapErr.message)
} else if (!snapshots || snapshots.length === 0) {
  console.log('   ⚠️  NO DATA (table exists but empty)')
} else {
  console.log('   ✅ HAS DATA')
  score++
}

// Test 4: Price bounds
console.log('\n4. product_catalog (price bounds)')
const { data: product, error: prodErr } = await supabase
  .from('product_catalog')
  .select('min_listing_price, max_listing_price')
  .eq('sku', TEST_SKU)
  .single()

if (prodErr) {
  console.log('   ❌ ERROR:', prodErr.message)
} else if (!product.min_listing_price || !product.max_listing_price) {
  console.log('   ⚠️  NOT SET')
  console.log('   Current: min=' + product.min_listing_price + ', max=' + product.max_listing_price)
} else {
  console.log('   ✅ PRICE BOUNDS SET')
  console.log('   Range: £' + (product.min_listing_price / 100).toFixed(2) + ' - £' + (product.max_listing_price / 100).toFixed(2))
  score++
}

// Summary
console.log('\n' + '='.repeat(80))
console.log('SCORE:', score + '/' + maxScore)
console.log('='.repeat(80))

if (score === maxScore) {
  console.log('✅ 100% - All Alias features working!')
  console.log('🎉 Ready to ship!\n')
  process.exit(0)
} else {
  const percentage = Math.round((score / maxScore) * 100)
  console.log(`⚠️  ${percentage}% - Some features need work`)

  if (score >= 1) {
    console.log('\n📊 Core Alias market data IS working')
    console.log('   Missing features are enhancements only')
  }

  console.log('')
  process.exit(1)
}
