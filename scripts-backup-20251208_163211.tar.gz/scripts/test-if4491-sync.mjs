#!/usr/bin/env node
/**
 * Test Multi-Region + Metadata Enrichment for IF4491-100
 */

import { createClient } from '@supabase/supabase-js';

const SKU = 'IF4491-100';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

console.log('================================================================================');
console.log(`TESTING SKU: ${SKU}`);
console.log('================================================================================\n');

// ============================================================================
// STEP 1: Find Product
// ============================================================================

console.log('🔍 STEP 1: Looking up product in catalog...\n');

const { data: product, error: productError } = await supabase
  .from('product_catalog')
  .select('id, sku, stockx_product_id, colorway, retail_price, release_date, category, gender, image_url')
  .eq('sku', SKU)
  .single();

if (productError || !product) {
  console.log('❌ Product not found in catalog');
  console.log('Error:', productError?.message);
  process.exit(1);
}

console.log('✅ Product found in catalog:');
console.log('   ID:', product.id);
console.log('   SKU:', product.sku);
console.log('   StockX Product ID:', product.stockx_product_id);
console.log('\n📦 Current Metadata (BEFORE sync):');
console.log('   - Colorway:', product.colorway || '❌ NOT SET');
console.log('   - Retail Price:', product.retail_price ? `£${(product.retail_price / 100).toFixed(2)}` : '❌ NOT SET');
console.log('   - Release Date:', product.release_date || '❌ NOT SET');
console.log('   - Category:', product.category || '❌ NOT SET');
console.log('   - Gender:', product.gender || '❌ NOT SET');
console.log('   - Image URL:', product.image_url ? '✅ SET' : '❌ NOT SET');

console.log('\n' + '='.repeat(80) + '\n');

// ============================================================================
// STEP 2: Check Existing Market Data (BEFORE)
// ============================================================================

console.log('📊 STEP 2: Checking existing market data (BEFORE sync)...\n');

const { data: beforeData, count: beforeCount } = await supabase
  .from('master_market_data')
  .select('currency_code, region_code, size_key, lowest_ask, snapshot_at', { count: 'exact' })
  .eq('provider', 'stockx')
  .eq('sku', SKU)
  .gte('snapshot_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()) // Last 24h
  .order('currency_code')
  .order('size_key')
  .limit(20);

if (beforeCount > 0) {
  console.log(`✅ Found ${beforeCount} existing snapshots (last 24h)`);

  const byCurrency = beforeData.reduce((acc, row) => {
    if (!acc[row.currency_code]) acc[row.currency_code] = 0;
    acc[row.currency_code]++;
    return acc;
  }, {});

  console.log('\nExisting snapshots by currency:');
  for (const [currency, count] of Object.entries(byCurrency)) {
    console.log(`   ${currency}: ${count} snapshots`);
  }
} else {
  console.log('⚠️  No existing market data found (this will be first sync)');
}

console.log('\n' + '='.repeat(80) + '\n');

// ============================================================================
// STEP 3: Run Multi-Region Sync
// ============================================================================

console.log('🚀 STEP 3: Running multi-region sync + metadata enrichment...\n');

const { syncProductAllRegions } = await import('../src/lib/services/stockx/market-refresh.ts');

const startTime = Date.now();
const result = await syncProductAllRegions(
  undefined, // No user (app-level auth)
  product.stockx_product_id,
  'UK', // Primary region
  true  // Sync all regions
);
const duration = ((Date.now() - startTime) / 1000).toFixed(1);

console.log('\n' + '='.repeat(80));
console.log('SYNC RESULT:');
console.log('='.repeat(80) + '\n');

console.log('✅ Success:', result.success);
console.log('⏱️  Duration:', duration + 's');
console.log('🌍 Primary Region:', result.primaryRegion);
console.log('📊 Primary Snapshots:', result.primaryResult.snapshotsCreated);

if (result.primaryResult.warning) {
  console.log('⚠️  Primary Warning:', result.primaryResult.warning);
}

console.log('\n📦 Secondary Regions:');
for (const [currency, syncResult] of Object.entries(result.secondaryResults)) {
  const status = syncResult.success ? '✅' : '❌';
  console.log(`   ${status} ${currency}: ${syncResult.snapshotsCreated} snapshots`);
  if (syncResult.warning) {
    console.log(`      ⚠️  ${syncResult.warning}`);
  }
  if (syncResult.error) {
    console.log(`      ❌ ${syncResult.error}`);
  }
}

console.log('\n📈 Total Snapshots Created:', result.totalSnapshotsCreated);

console.log('\n' + '='.repeat(80) + '\n');

// ============================================================================
// STEP 4: Verify Metadata Enrichment
// ============================================================================

console.log('🔍 STEP 4: Verifying metadata enrichment...\n');

const { data: enrichedProduct } = await supabase
  .from('product_catalog')
  .select('colorway, retail_price, release_date, category, gender, image_url')
  .eq('stockx_product_id', product.stockx_product_id)
  .single();

if (enrichedProduct) {
  console.log('📦 Product Metadata (AFTER sync):');

  let changedCount = 0;

  const colorwayChanged = product.colorway !== enrichedProduct.colorway;
  const retailPriceChanged = product.retail_price !== enrichedProduct.retail_price;
  const releaseDateChanged = product.release_date !== enrichedProduct.release_date;
  const categoryChanged = product.category !== enrichedProduct.category;
  const genderChanged = product.gender !== enrichedProduct.gender;
  const imageUrlChanged = product.image_url !== enrichedProduct.image_url;

  if (colorwayChanged) changedCount++;
  if (retailPriceChanged) changedCount++;
  if (releaseDateChanged) changedCount++;
  if (categoryChanged) changedCount++;
  if (genderChanged) changedCount++;
  if (imageUrlChanged) changedCount++;

  console.log(`   - Colorway: ${enrichedProduct.colorway || 'N/A'} ${colorwayChanged ? '✨ NEW' : ''}`);
  console.log(`   - Retail Price: ${enrichedProduct.retail_price ? `£${(enrichedProduct.retail_price / 100).toFixed(2)}` : 'N/A'} ${retailPriceChanged ? '✨ NEW' : ''}`);
  console.log(`   - Release Date: ${enrichedProduct.release_date || 'N/A'} ${releaseDateChanged ? '✨ NEW' : ''}`);
  console.log(`   - Category: ${enrichedProduct.category || 'N/A'} ${categoryChanged ? '✨ NEW' : ''}`);
  console.log(`   - Gender: ${enrichedProduct.gender || 'N/A'} ${genderChanged ? '✨ NEW' : ''}`);
  console.log(`   - Image URL: ${enrichedProduct.image_url ? '✅ SET' : 'N/A'} ${imageUrlChanged ? '✨ NEW' : ''}`);

  console.log(`\n📊 Metadata fields updated: ${changedCount}`);
}

console.log('\n' + '='.repeat(80) + '\n');

// ============================================================================
// STEP 5: Verify Multi-Currency Data
// ============================================================================

console.log('💰 STEP 5: Verifying multi-currency data...\n');

const { data: afterData, count: afterCount } = await supabase
  .from('master_market_data')
  .select('currency_code, region_code, size_key, lowest_ask, highest_bid, snapshot_at')
  .eq('provider', 'stockx')
  .eq('sku', SKU)
  .gte('snapshot_at', new Date(Date.now() - 10 * 60 * 1000).toISOString()) // Last 10 minutes
  .order('currency_code')
  .order('size_numeric')
  .limit(50);

if (afterCount > 0) {
  console.log(`✅ Found ${afterCount} NEW snapshots (last 10 minutes)\n`);

  // Group by currency
  const byCurrency = afterData.reduce((acc, row) => {
    if (!acc[row.currency_code]) acc[row.currency_code] = [];
    acc[row.currency_code].push(row);
    return acc;
  }, {});

  const currencyEmoji = { USD: '🇺🇸', GBP: '🇬🇧', EUR: '🇪🇺' };

  for (const [currency, rows] of Object.entries(byCurrency)) {
    const emoji = currencyEmoji[currency] || '🌍';
    console.log(`${emoji} ${currency} Marketplace (${rows[0].region_code}):`);
    console.log('   Snapshots:', rows.length);
    console.log('   Sample (first 3 sizes):');

    rows.slice(0, 3).forEach(row => {
      const ask = row.lowest_ask ? `${currency} ${row.lowest_ask}` : 'NULL';
      const bid = row.highest_bid ? `${currency} ${row.highest_bid}` : 'NULL';
      const age = Math.floor((Date.now() - new Date(row.snapshot_at).getTime()) / 1000 / 60);
      console.log(`      Size ${row.size_key}: Ask=${ask}, Bid=${bid} (${age}m ago)`);
    });
    console.log('');
  }

  // Verify all 3 currencies present
  const currencies = Object.keys(byCurrency);
  console.log('✅ Currencies synced:', currencies.join(', '));

  if (currencies.length === 3) {
    console.log('🎉 All 3 regions synced successfully!');
  } else {
    console.log('⚠️  Missing currencies:', ['USD', 'GBP', 'EUR'].filter(c => !currencies.includes(c)).join(', '));
  }

} else {
  console.log('❌ No new market data found');
}

console.log('\n' + '='.repeat(80) + '\n');

// ============================================================================
// STEP 6: Sample Cross-Region Comparison
// ============================================================================

console.log('🔍 STEP 6: Cross-region price comparison (sample size)...\n');

// Find a common size with data in all regions
const { data: priceComparison } = await supabase
  .from('master_market_latest')
  .select('currency_code, region_code, size_key, lowest_ask, highest_bid')
  .eq('sku', SKU)
  .eq('is_flex', false)
  .eq('is_consigned', false)
  .in('currency_code', ['USD', 'GBP', 'EUR'])
  .not('lowest_ask', 'is', null)
  .order('size_numeric')
  .limit(15);

if (priceComparison && priceComparison.length > 0) {
  // Find a size that exists in multiple regions
  const sizeCounts = priceComparison.reduce((acc, row) => {
    if (!acc[row.size_key]) acc[row.size_key] = 0;
    acc[row.size_key]++;
    return acc;
  }, {});

  const bestSize = Object.entries(sizeCounts)
    .sort((a, b) => b[1] - a[1])[0][0];

  const sizeData = priceComparison.filter(r => r.size_key === bestSize);

  if (sizeData.length > 1) {
    console.log(`Size ${bestSize} pricing across regions:\n`);

    sizeData.forEach(row => {
      const emoji = { USD: '🇺🇸', GBP: '🇬🇧', EUR: '🇪🇺' }[row.currency_code] || '🌍';
      console.log(`${emoji} ${row.region_code} (${row.currency_code}):`);
      console.log(`   Lowest Ask: ${row.currency_code} ${row.lowest_ask}`);
      console.log(`   Highest Bid: ${row.currency_code} ${row.highest_bid || 'N/A'}`);
      console.log('');
    });
  } else {
    console.log('⚠️  No common size found across multiple regions yet');
  }
} else {
  console.log('⚠️  No price data available in materialized view yet (may need manual refresh)');
}

console.log('='.repeat(80));
console.log('✅ TEST COMPLETE');
console.log('='.repeat(80));

console.log('\n📋 Summary:\n');
console.log('   ✓ Multi-region sync tested (USD, GBP, EUR)');
console.log('   ✓ Product metadata enrichment verified');
console.log('   ✓ Currency fields populated correctly');
console.log('   ✓ Cross-region comparison ready');
