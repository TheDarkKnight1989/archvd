#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

// Check one specific product that was mapped
const sku = 'U9060BPM' // Should have been mapped to '9060-triple-black-u9060bpm'

const { data: product } = await supabase
  .from('products')
  .select(`
    id,
    sku,
    brand,
    model,
    product_variants (
      id,
      alias_catalog_id,
      stockx_product_id
    )
  `)
  .eq('sku', sku)
  .single()

console.log(`Product: ${product.sku}`)
console.log(`Brand: ${product.brand}`)
console.log(`Model: ${product.model}`)
console.log(`Variants: ${product.product_variants.length}`)
console.log(`Sample variant:`)
const sample = product.product_variants[0]
console.log(`  Alias ID: ${sample.alias_catalog_id}`)
console.log(`  StockX ID: ${sample.stockx_product_id}`)
