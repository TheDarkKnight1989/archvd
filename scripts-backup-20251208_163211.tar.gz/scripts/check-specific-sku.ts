#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function check() {
  const { data } = await supabase
    .from('master_market_data')
    .select('sku, region_code, size_key, lowest_ask, provider_source')
    .eq('provider', 'stockx')
    .eq('sku', '1201A906-001')
    .limit(20);

  console.log('Data for SKU 1201A906-001:');
  console.log('Count:', data?.length || 0);
  if (data && data.length > 0) {
    console.log('\nSample rows:');
    data.slice(0, 5).forEach(row => {
      console.log(`  ${row.region_code} | ${row.size_key} | ${row.lowest_ask} | ${row.provider_source}`);
    });
  }
}

check();
