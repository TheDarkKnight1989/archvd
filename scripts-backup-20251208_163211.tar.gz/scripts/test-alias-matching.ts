/**
 * Test Alias SKU matching logic
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { matchInventoryToAliasCatalog } from '@/lib/services/alias/matching'

const TEST_SKU = 'FV5029-010' // Jordan 4 Black Cat (with dash)

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('TESTING ALIAS SKU MATCHING')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()

  console.log(`Testing SKU: "${TEST_SKU}"`)
  console.log()

  // Test the matching service
  const result = await matchInventoryToAliasCatalog(client, {
    sku: TEST_SKU,
    productName: 'Air Jordan 4 Black Cat',
    brand: 'Jordan'
  })

  console.log('MATCH RESULT:')
  console.log(JSON.stringify(result, null, 2))
  console.log()

  if (result.catalogId) {
    console.log('✅ SUCCESS! Match found:')
    console.log(`   Catalog ID: ${result.catalogId}`)
    console.log(`   Confidence: ${result.confidence}`)
    console.log(`   Method: ${result.matchMethod}`)
    if (result.catalogItem) {
      console.log(`   Name: ${result.catalogItem.name}`)
      console.log(`   SKU (Alias): ${result.catalogItem.sku}`)
      console.log(`   SKU (Input): ${TEST_SKU}`)
      console.log()
      console.log(`   ✅ Match successful despite SKU format difference:`)
      console.log(`      Alias has: "${result.catalogItem.sku}" (with space)`)
      console.log(`      We used: "${TEST_SKU}" (with dash)`)
    }
  } else {
    console.log('❌ FAILED! No match found')
    console.log(`   This means the normalization is NOT working`)
  }
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
