/**
 * Show complete market data for a SKU in table format
 */

import { createClient } from '@supabase/supabase-js'
import { StockxCatalogService } from '@/lib/services/stockx/catalog'
import { refreshStockxMarketData } from '@/lib/services/stockx/market-refresh'

const SKU = process.argv[2] || 'U992AC1'

async function main() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log(`COMPLETE DATA FOR SKU: ${SKU}`)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  // Step 1: Search StockX for the product
  console.log('🔍 Searching StockX...')
  const catalogService = new StockxCatalogService(undefined)

  try {
    const products = await catalogService.searchProducts(SKU, { limit: 5 })

    if (products.length === 0) {
      console.log('❌ Product not found on StockX')
      return
    }

    const product = products.find(p => p.styleId?.toUpperCase() === SKU.toUpperCase()) || products[0]
    console.log(`✅ Found: ${product.productName}`)
    console.log(`   Product ID: ${product.productId}`)
    console.log(`   Style ID: ${product.styleId}`)
    console.log()

    // Step 2: Fetch market data directly from StockX API
    console.log('📥 Fetching market data from StockX (GBP, UK)...')
    const client = (catalogService as any).client
    const rawMarketData = await client.request(
      `/v2/catalog/products/${product.productId}/market-data?currencyCode=GBP`
    )

    if (!Array.isArray(rawMarketData) || rawMarketData.length === 0) {
      console.log('❌ No market data returned')
      return
    }

    console.log(`✅ Fetched ${rawMarketData.length} size variants`)
    console.log()

    // Step 3: Get variant names - try database first, then fetch from StockX
    console.log('📊 Looking up size names...')
    const { data: dbVariants, error: variantsError } = await supabase
      .from('stockx_variants')
      .select('stockx_variant_id, variant_value')
      .eq('stockx_product_id', product.productId)

    let variantMap = new Map<string, string>()

    if (dbVariants && dbVariants.length > 0) {
      for (const v of dbVariants) {
        variantMap.set(v.stockx_variant_id, v.variant_value)
      }
      console.log(`✅ Found ${dbVariants.length} variant names in database`)
    } else {
      console.log('⚠️  No variants in database, fetching from StockX...')
      const stockxVariants = await catalogService.getProductVariants(product.productId)
      if (stockxVariants && stockxVariants.length > 0) {
        for (const v of stockxVariants) {
          variantMap.set(v.variantId, v.variantValue)
        }
        console.log(`✅ Fetched ${stockxVariants.length} variant names from StockX`)
      } else {
        console.log('❌ No variants found')
      }
    }
    console.log()

    // Step 4: Convert to rows format
    const latestRows: any[] = []
    for (const variant of rawMarketData) {
      const sizeKey = variantMap.get(variant.variantId) || 'Unknown'
      const numericMatch = sizeKey.match(/[\d.]+/)
      const sizeNumeric = numericMatch ? parseFloat(numericMatch[0]) : null

      // Standard row
      if (variant.standardMarketData) {
        latestRows.push({
          size_key: sizeKey,
          size_numeric: sizeNumeric,
          provider_source: 'stockx_market_data',
          lowest_ask: variant.standardMarketData.lowestAsk,
          highest_bid: variant.standardMarketData.highestBid,
          last_sale_price: variant.lastSaleAmount,
          sales_last_72h: variant.salesLast72Hours,
          sales_last_30d: variant.totalVolume,
          created_at: new Date().toISOString(),
        })
      }

      // Flex row
      if (variant.flexMarketData) {
        latestRows.push({
          size_key: sizeKey,
          size_numeric: sizeNumeric,
          provider_source: 'stockx_market_data_flex',
          lowest_ask: variant.flexMarketData.lowestAsk,
          highest_bid: variant.flexMarketData.highestBid,
          last_sale_price: variant.lastSaleAmount,
          sales_last_72h: variant.salesLast72Hours,
          sales_last_30d: variant.totalVolume,
          created_at: new Date().toISOString(),
        })
      }
    }

    console.log(`✅ Prepared ${latestRows.length} rows (Standard + Flex)`)
    console.log()

    // Step 4: Group by size and organize
    const sizeGroups = new Map<string, any[]>()
    for (const row of latestRows) {
      const size = row.size_key
      if (!sizeGroups.has(size)) {
        sizeGroups.set(size, [])
      }
      sizeGroups.get(size)!.push(row)
    }

    // Sort by numeric size
    const sortedSizes = Array.from(sizeGroups.entries()).sort((a, b) => {
      const numA = parseFloat(a[0]) || 999
      const numB = parseFloat(b[0]) || 999
      return numA - numB
    })

    // Step 5: Display as table
    console.log('═══════════════════════════════════════════════════════════════════════════')
    console.log('COMPLETE DATA TABLE')
    console.log('═══════════════════════════════════════════════════════════════════════════\n')

    // Table header
    console.log('┌──────────┬────────────┬────────────┬────────────┬────────────┬────────────┬─────────┬─────────┐')
    console.log('│   SIZE   │   SOURCE   │  LOWEST ASK│ HIGHEST BID│  LAST SALE │   SALES    │ SIZE    │ CREATED │')
    console.log('│          │            │    (GBP)   │    (GBP)   │    (GBP)   │   72h/30d  │ NUMERIC │   AT    │')
    console.log('├──────────┼────────────┼────────────┼────────────┼────────────┼────────────┼─────────┼─────────┤')

    for (const [size, rows] of sortedSizes) {
      // Standard row
      const standard = rows.find(r => r.provider_source === 'stockx_market_data')
      if (standard) {
        const lowestAsk = standard.lowest_ask !== null && standard.lowest_ask !== undefined ? `£${standard.lowest_ask}` : 'N/A'
        const highestBid = standard.highest_bid !== null && standard.highest_bid !== undefined ? `£${standard.highest_bid}` : 'N/A'
        const lastSale = standard.last_sale_price !== null && standard.last_sale_price !== undefined ? `£${standard.last_sale_price}` : 'N/A'
        const sales = `${standard.sales_last_72h || 0}/${standard.sales_last_30d || 0}`
        const numeric = standard.size_numeric !== null ? standard.size_numeric.toString() : 'null'
        const created = new Date(standard.created_at).toLocaleTimeString('en-GB', {
          hour: '2-digit',
          minute: '2-digit'
        })

        console.log(
          `│ ${size.padEnd(8)} │ Standard   │ ${lowestAsk.padEnd(10)} │ ${highestBid.padEnd(10)} │ ${lastSale.padEnd(10)} │ ${sales.padEnd(10)} │ ${numeric.padEnd(7)} │ ${created.padEnd(7)} │`
        )
      }

      // Flex row
      const flex = rows.find(r => r.provider_source === 'stockx_market_data_flex')
      if (flex) {
        const lowestAsk = flex.lowest_ask !== null && flex.lowest_ask !== undefined ? `£${flex.lowest_ask}` : 'N/A'
        const highestBid = flex.highest_bid !== null && flex.highest_bid !== undefined ? `£${flex.highest_bid}` : 'N/A'
        const lastSale = flex.last_sale_price !== null && flex.last_sale_price !== undefined ? `£${flex.last_sale_price}` : 'N/A'
        const sales = `${flex.sales_last_72h || 0}/${flex.sales_last_30d || 0}`
        const numeric = flex.size_numeric !== null ? flex.size_numeric.toString() : 'null'
        const created = new Date(flex.created_at).toLocaleTimeString('en-GB', {
          hour: '2-digit',
          minute: '2-digit'
        })

        console.log(
          `│ ${size.padEnd(8)} │ Flex 🚀    │ ${lowestAsk.padEnd(10)} │ ${highestBid.padEnd(10)} │ ${lastSale.padEnd(10)} │ ${sales.padEnd(10)} │ ${numeric.padEnd(7)} │ ${created.padEnd(7)} │`
        )
      }

      console.log('├──────────┼────────────┼────────────┼────────────┼────────────┼────────────┼─────────┼─────────┤')
    }

    console.log('└──────────┴────────────┴────────────┴────────────┴────────────┴────────────┴─────────┴─────────┘')
    console.log()

    // Summary
    console.log('═══════════════════════════════════════════════════════════════════════════')
    console.log('SUMMARY')
    console.log('═══════════════════════════════════════════════════════════════════════════\n')

    const totalRows = latestRows.length
    const standardRows = latestRows.filter(r => r.provider_source === 'stockx_market_data').length
    const flexRows = latestRows.filter(r => r.provider_source === 'stockx_market_data_flex').length
    const uniqueSizes = sizeGroups.size
    const unknownSizes = latestRows.filter(r => r.size_key === 'Unknown').length

    console.log(`Total rows: ${totalRows}`)
    console.log(`  Standard: ${standardRows}`)
    console.log(`  Flex: ${flexRows}`)
    console.log(`Unique sizes: ${uniqueSizes}`)
    console.log(`Unknown sizes: ${unknownSizes}`)
    console.log()

    if (unknownSizes === 0) {
      console.log('✅ All sizes properly mapped!')
    } else {
      console.log(`⚠️  ${unknownSizes} sizes showing as "Unknown"`)
    }
    console.log()

  } catch (error: any) {
    console.error('❌ Error:', error.message)
    throw error
  }
}

main().catch(console.error)
