/**
 * Find Alias catalog_id for a given SKU
 */

import { AliasClient } from '@/lib/services/alias/client'

const SKU = process.argv[2] || 'FV5029-010'

async function main() {
  const pat = process.env.ALIAS_PAT
  if (!pat) {
    throw new Error('ALIAS_PAT not found in environment')
  }

  const client = new AliasClient(pat)

  console.log(`\n🔍 Searching Alias for SKU: ${SKU}\n`)

  try {
    const results = await client.searchCatalog(SKU, { limit: 10 })

    if (!results.items || results.items.length === 0) {
      console.log('❌ No results found')
      return
    }

    console.log(`✅ Found ${results.items.length} results:\n`)

    for (const item of results.items) {
      console.log(`---`)
      console.log(`catalog_id: ${item.id}`)
      console.log(`name: ${item.name}`)
      console.log(`style_code: ${item.style_code || 'N/A'}`)
      console.log(`brand: ${item.brand}`)
      console.log(`release_year: ${item.release_year || 'N/A'}`)
      console.log()
    }

    // Return the first exact match by style_code
    const exactMatch = results.items.find(
      (item) => item.style_code?.toUpperCase() === SKU.toUpperCase()
    )

    if (exactMatch) {
      console.log(`\n🎯 EXACT MATCH:`)
      console.log(`catalog_id: ${exactMatch.id}`)
      console.log(`name: ${exactMatch.name}`)
    } else {
      console.log(`\n⚠️  No exact style_code match, showing first result:`)
      console.log(`catalog_id: ${results.items[0].id}`)
      console.log(`name: ${results.items[0].name}`)
    }
  } catch (error: any) {
    console.error('❌ Error searching Alias:', error.message)
    throw error
  }
}

main().catch(console.error)
