#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js';

const SKU = 'IO3372-700';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function testSync() {
  console.log('================================================================================');
  console.log('FULL STOCKX SYNC TEST: ' + SKU);
  console.log('================================================================================\n');

  // Step 1: Search StockX for the SKU
  console.log('🔍 Searching StockX for:', SKU);

  const { StockxCatalogService } = await import('../src/lib/services/stockx/catalog.ts');
  const catalogService = new StockxCatalogService(undefined);

  const searchResults = await catalogService.searchProducts(SKU);

  if (!searchResults || searchResults.length === 0) {
    console.log('❌ No results found');
    return;
  }

  const product = searchResults[0];
  console.log('✅ Found:', product.productName);
  console.log('   Product ID:', product.productId);
  console.log('   Style ID:', product.styleId);
  console.log('\n' + '='.repeat(80) + '\n');

  // Step 2: Fetch market data directly from StockX API
  console.log('📥 Fetching market data from StockX API...\n');

  const { StockxClient } = await import('../src/lib/services/stockx/client.ts');
  const client = new StockxClient();

  const rawPayload = await client.request(
    `/v2/catalog/products/${product.productId}/market-data?currencyCode=GBP`
  );

  console.log('DEBUG: Raw response structure:');
  console.log(JSON.stringify(rawPayload, null, 2));
  console.log('\n');

  if (!rawPayload) {
    console.log('❌ No market data returned');
    return;
  }

  // Check different possible structures
  const variants = rawPayload.variants || rawPayload.data?.variants || rawPayload;

  if (!variants || (Array.isArray(variants) && variants.length === 0)) {
    console.log('❌ No variants found in response');
    console.log('Response keys:', Object.keys(rawPayload));
    return;
  }

  const variantsArray = Array.isArray(variants) ? variants : [variants];

  console.log('✅ Received data for', variantsArray.length, 'variants\n');
  console.log('='.repeat(80) + '\n');

  // Step 3: Create raw snapshot entry
  console.log('💾 Creating raw snapshot entry...\n');

  const snapshotAt = new Date();
  const { data: rawSnapshot, error: snapshotError } = await supabase
    .from('stockx_raw_snapshots')
    .insert({
      endpoint: 'market_data',
      product_id: product.productId,
      style_id: product.styleId,
      currency_code: 'GBP',
      http_status: 200,
      raw_payload: rawPayload,
      requested_at: snapshotAt,
    })
    .select()
    .single();

  if (snapshotError) {
    console.error('❌ Failed to create raw snapshot:', snapshotError.message);
    return;
  }

  console.log('✅ Raw snapshot created:', rawSnapshot.id);
  console.log('\n' + '='.repeat(80) + '\n');

  // Step 4: Run ingestion mapper directly
  console.log('⚙️  Running ingestion mapper...\n');

  const { ingestStockXMarketData } = await import('../src/lib/services/ingestion/stockx-mapper.ts');

  await ingestStockXMarketData(
    rawSnapshot.id,
    variantsArray,
    {
      currencyCode: 'GBP',
      productId: product.productId,
      styleId: product.styleId,
      sku: SKU,
      regionCode: 'uk',
      snapshotAt: snapshotAt,
    }
  );

  console.log('✅ Ingestion complete\n');
  console.log('='.repeat(80) + '\n');

  // Step 5: Query the database to show EVERYTHING
  console.log('📊 QUERYING DATABASE - ALL FIELDS FOR ' + SKU + '\n');

  const { data: rows } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')
    .eq('sku', SKU)
    .order('size_numeric', { ascending: true })
    .order('is_flex', { ascending: true })
    .order('is_consigned', { ascending: true })
    .limit(12);

  if (!rows || rows.length === 0) {
    console.log('❌ No data found in database');
    return;
  }

  console.log('✅ Found', rows.length, 'rows (showing first 12)\n');

  // Display first row with ALL fields
  console.log('='.repeat(80));
  console.log('SAMPLE ROW - ALL FIELDS:');
  console.log('='.repeat(80) + '\n');

  const sample = rows[0];
  const fieldOrder = [
    // Identification
    'provider', 'provider_source', 'sku', 'size_key', 'size_numeric',
    // Pricing
    'lowest_ask', 'highest_bid', 'last_sale_price',
    // NEW: Pricing suggestions
    'sell_faster_price', 'earn_more_price', 'beat_us_price',
    // Flags
    'is_flex', 'is_consigned',
    // Volume
    'sales_last_72h', 'sales_last_30d',
    // Currency
    'currency_code', 'region_code',
  ];

  fieldOrder.forEach(field => {
    if (field in sample) {
      let value = sample[field];
      if (value === null) value = 'NULL';
      else if (typeof value === 'boolean') value = value ? 'TRUE' : 'FALSE';
      else if (typeof value === 'number') value = value.toString();
      else if (typeof value === 'object') value = JSON.stringify(value).substring(0, 50) + '...';

      console.log(field.padEnd(25), value);
    }
  });

  console.log('\n' + '='.repeat(80));
  console.log('PRICING BREAKDOWN BY SIZE & TYPE:');
  console.log('='.repeat(80) + '\n');

  console.log('Size'.padEnd(8), 'Type'.padEnd(12), 'Ask'.padEnd(8), 'Bid'.padEnd(8), 'SellFast'.padEnd(10), 'EarnMore'.padEnd(10), 'BeatUS'.padEnd(8));
  console.log('─'.repeat(80));

  rows.forEach(row => {
    const type = row.is_flex ? 'Flex' : (row.is_consigned ? 'Consigned' : 'Standard');
    console.log(
      (row.size_key || 'N/A').padEnd(8),
      type.padEnd(12),
      (row.lowest_ask || 'NULL').toString().padEnd(8),
      (row.highest_bid || 'NULL').toString().padEnd(8),
      (row.sell_faster_price || 'NULL').toString().padEnd(10),
      (row.earn_more_price || 'NULL').toString().padEnd(10),
      (row.beat_us_price || 'NULL').toString().padEnd(8)
    );
  });

  console.log('\n' + '='.repeat(80));
  console.log('✅ TEST COMPLETE!');
  console.log('='.repeat(80));
}

testSync().catch(err => {
  console.error('❌ ERROR:', err.message);
  console.error(err.stack);
  process.exit(1);
});
