import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

console.log('═══════════════════════════════════════════════════════════════════════════')
console.log('STOCKX ROWS IN MASTER_MARKET_DATA')
console.log('═══════════════════════════════════════════════════════════════════════════\n')

// Count total StockX rows
const { count, error } = await supabase
  .from('master_market_data')
  .select('*', { count: 'exact', head: true })
  .eq('provider', 'stockx')

if (error) {
  console.error('Error:', error)
  process.exit(1)
}

console.log(`Total StockX rows: ${count}\n`)

// Get breakdown by product
const { data: products, error: productsError } = await supabase
  .from('master_market_data')
  .select('provider_product_id, sku, created_at')
  .eq('provider', 'stockx')
  .order('created_at', { ascending: false })

if (productsError) {
  console.error('Error:', productsError)
  process.exit(1)
}

// Group by product ID
const productMap = new Map()
for (const row of products) {
  const key = row.provider_product_id
  if (!productMap.has(key)) {
    productMap.set(key, {
      productId: key,
      sku: row.sku,
      count: 0,
      firstCreated: row.created_at,
      lastCreated: row.created_at
    })
  }
  const entry = productMap.get(key)
  entry.count++
  if (new Date(row.created_at) < new Date(entry.firstCreated)) {
    entry.firstCreated = row.created_at
  }
  if (new Date(row.created_at) > new Date(entry.lastCreated)) {
    entry.lastCreated = row.created_at
  }
}

console.log('Breakdown by Product:\n')
console.log('┌─────────────┬──────────────────────────────────────┬───────┬─────────────────────┐')
console.log('│     SKU     │            Product ID                │ Rows  │    Created Range    │')
console.log('├─────────────┼──────────────────────────────────────┼───────┼─────────────────────┤')

for (const [productId, info] of productMap.entries()) {
  const sku = (info.sku || 'Unknown').padEnd(11).substring(0, 11)
  const id = productId.substring(0, 36).padEnd(36)
  const count = String(info.count).padStart(5)
  const firstTime = new Date(info.firstCreated).toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit'
  })
  const lastTime = new Date(info.lastCreated).toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit'
  })
  const timeRange = `${firstTime}-${lastTime}`.padEnd(19)

  console.log(`│ ${sku} │ ${id} │ ${count} │ ${timeRange} │`)
}

console.log('└─────────────┴──────────────────────────────────────┴───────┴─────────────────────┘\n')

// Check if these are all from today (test data)
const today = new Date().toISOString().split('T')[0]
const { data: todayRows, error: todayError } = await supabase
  .from('master_market_data')
  .select('id')
  .eq('provider', 'stockx')
  .gte('created_at', `${today}T00:00:00.000Z`)

if (!todayError) {
  console.log(`Rows created today: ${todayRows.length}`)
  console.log(`Rows from earlier: ${count - todayRows.length}\n`)
}

console.log('═══════════════════════════════════════════════════════════════════════════')
console.log('RECOMMENDATION')
console.log('═══════════════════════════════════════════════════════════════════════════\n')

if (count > 0 && todayRows.length === count) {
  console.log('✅ All StockX rows are from today (test data)')
  console.log('   Safe to delete all StockX rows\n')
} else if (count > 0) {
  console.log('⚠️  Some StockX rows are from earlier dates')
  console.log(`   Today: ${todayRows.length} rows`)
  console.log(`   Earlier: ${count - todayRows.length} rows`)
  console.log('   Consider selective deletion\n')
} else {
  console.log('✅ No StockX rows to clean up\n')
}
