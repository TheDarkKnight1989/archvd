#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function checkSource() {
  console.log('═══════════════════════════════════════════════════════════');
  console.log('STOCKX_PRODUCTS TABLE - SOURCE ANALYSIS');
  console.log('═══════════════════════════════════════════════════════════\n');

  // Get table info
  const { data: products, count } = await supabase
    .from('stockx_products')
    .select('*', { count: 'exact' })
    .order('created_at', { ascending: true });

  if (!products || products.length === 0) {
    console.log('❌ No products in stockx_products table\n');
    return;
  }

  console.log(`Total products: ${count}`);
  console.log(`First added: ${products[0].created_at}`);
  console.log(`Last added: ${products[products.length - 1].created_at}\n`);

  // Show first 10 products
  console.log('First 10 products added:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  products.slice(0, 10).forEach((p, i) => {
    console.log(`${i + 1}. ${p.style_id}`);
    console.log(`   StockX ID: ${p.stockx_product_id}`);
    console.log(`   Added: ${p.created_at}`);
    console.log('');
  });

  // Check if these match products table
  const { data: mainProducts } = await supabase
    .from('products')
    .select('sku, stockx_product_id')
    .not('stockx_product_id', 'is', null);

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('COMPARISON WITH MAIN PRODUCTS TABLE');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`Products with stockx_product_id: ${mainProducts?.length || 0}`);

  // Find overlap
  const stockxIds = new Set(products.map(p => p.stockx_product_id));
  const mainIds = new Set(mainProducts?.map(p => p.stockx_product_id) || []);

  const overlap = Array.from(stockxIds).filter(id => mainIds.has(id));
  const onlyInStockxProducts = products.filter(p => !mainIds.has(p.stockx_product_id));
  const onlyInProducts = mainProducts?.filter(p => !stockxIds.has(p.stockx_product_id)) || [];

  console.log(`\nOverlap: ${overlap.length} products exist in BOTH tables`);
  console.log(`Only in stockx_products: ${onlyInStockxProducts.length}`);
  console.log(`Only in products: ${onlyInProducts.length}\n`);

  if (onlyInStockxProducts.length > 0) {
    console.log('Products ONLY in stockx_products (not in main products):');
    onlyInStockxProducts.slice(0, 10).forEach(p => {
      console.log(`  - ${p.style_id}`);
    });
    if (onlyInStockxProducts.length > 10) {
      console.log(`  ... and ${onlyInStockxProducts.length - 10} more`);
    }
    console.log('');
  }

  console.log('═══════════════════════════════════════════════════════════');
  console.log('CONCLUSION');
  console.log('═══════════════════════════════════════════════════════════');
  console.log('The stockx_products table contains 125 StockX product mappings.');
  console.log('These were likely added separately from your main inventory.');
  console.log('');
  console.log('This is a CATALOG table - it just maps SKUs to StockX product IDs.');
  console.log('It allows you to sync market data for products you dont own yet.');
  console.log('');
}

checkSource();
