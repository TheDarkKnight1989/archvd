#!/usr/bin/env npx tsx
/**
 * Test Correct StockX API Endpoints
 *
 * Tests the CORRECT endpoint format per API docs:
 * 1. GET /v2/catalog/products/{productId}/variants (no params)
 * 2. GET /v2/catalog/products/{productId}/variants/{variantId}/market-data?currencyCode={currency}&country={country}
 */

import { createClient } from '@supabase/supabase-js'
import { getStockxClient } from '@/lib/services/stockx/client'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function testCorrectEndpoints() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗')
  console.log('║         Testing CORRECT StockX API Endpoint Format                   ║')
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n')

  // Get one product to test with
  const { data: products } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, brand')
    .limit(1)
    .single()

  if (!products) {
    console.error('❌ No products found')
    process.exit(1)
  }

  const { stockx_product_id: productId, style_id: sku } = products
  console.log(`📦 Testing with product: ${sku}`)
  console.log(`   Product ID: ${productId}\n`)

  const client = getStockxClient()

  // ========================================================================
  // TEST 1: Get Variants (CORRECT - No query params)
  // ========================================================================

  console.log('─'.repeat(75))
  console.log('TEST 1: GET /v2/catalog/products/{productId}/variants')
  console.log('─'.repeat(75))

  const variantsEndpoint = `/v2/catalog/products/${productId}/variants`
  console.log(`Endpoint: ${variantsEndpoint}`)
  console.log(`Expected: No query parameters\n`)

  let variants: any
  try {
    variants = await client.request(variantsEndpoint)
    console.log('✅ Variants endpoint SUCCESS\n')

    // Parse variants array
    const variantsArray = variants.variants || variants.data || (Array.isArray(variants) ? variants : [])
    console.log(`Found ${variantsArray.length} variants`)

    if (variantsArray.length > 0) {
      const firstVariant = variantsArray[0]
      console.log('\nFirst variant sample:')
      console.log(JSON.stringify(firstVariant, null, 2))

      console.log('\n📋 All variant IDs:')
      variantsArray.slice(0, 5).forEach((v: any, i: number) => {
        const variantId = v.id || v.variantId
        const size = v.size || v.variantValue
        console.log(`  ${i + 1}. ${size?.padEnd(8)} → ${variantId}`)
      })
      if (variantsArray.length > 5) {
        console.log(`  ... and ${variantsArray.length - 5} more`)
      }
    }
  } catch (error: any) {
    console.error('❌ Variants endpoint FAILED')
    console.error('Error:', error.message)
    console.error('\nFull error:', error)
    process.exit(1)
  }

  // ========================================================================
  // TEST 2: Get Market Data for ONE variant (CORRECT format)
  // ========================================================================

  console.log('\n' + '─'.repeat(75))
  console.log('TEST 2: GET /v2/catalog/products/{productId}/variants/{variantId}/market-data')
  console.log('─'.repeat(75))

  const variantsArray = variants.variants || variants.data || (Array.isArray(variants) ? variants : [])
  if (variantsArray.length === 0) {
    console.error('❌ No variants to test market data with')
    process.exit(1)
  }

  const testVariant = variantsArray[0]
  const variantId = testVariant.id || testVariant.variantId
  const variantSize = testVariant.size || testVariant.variantValue

  console.log(`Testing with variant: ${variantSize} (ID: ${variantId})\n`)

  // Test all three regions
  const regions = [
    { name: 'US', currency: 'USD', country: 'US' },
    { name: 'UK', currency: 'GBP', country: 'GB' },
    { name: 'EU', currency: 'EUR', country: 'DE' },
  ]

  for (const region of regions) {
    console.log(`\n🌍 Testing ${region.name} region (${region.currency})...`)

    const marketDataEndpoint = `/v2/catalog/products/${productId}/variants/${variantId}/market-data?currencyCode=${region.currency}&country=${region.country}`

    console.log(`Endpoint: ${marketDataEndpoint}`)
    console.log(`Expected: Market data for size ${variantSize} in ${region.currency}\n`)

    try {
      const marketData = await client.request(marketDataEndpoint)
      console.log(`✅ ${region.name} market data SUCCESS\n`)
      console.log('Response:')
      console.log(JSON.stringify(marketData, null, 2))
    } catch (error: any) {
      console.error(`❌ ${region.name} market data FAILED`)
      console.error('Error:', error.message)

      // Check if it's a 404 or other specific error
      if (error.message?.includes('404')) {
        console.error('⚠️  404 Not Found - Endpoint might not exist or variant ID is invalid')
      } else if (error.message?.includes('400')) {
        console.error('⚠️  400 Bad Request - Parameters might be wrong')
      } else if (error.message?.includes('401')) {
        console.error('⚠️  401 Unauthorized - Auth token might be invalid')
      }

      console.error('\nFull error:', error)
    }
  }

  // ========================================================================
  // TEST 3: Compare OLD vs NEW endpoint
  // ========================================================================

  console.log('\n' + '─'.repeat(75))
  console.log('TEST 3: Compare OLD (broken) vs NEW (correct) endpoint')
  console.log('─'.repeat(75))

  const oldEndpoint = `/v2/catalog/products/${productId}/market-data?currencyCode=USD`
  console.log('\n❌ OLD (BROKEN) endpoint:')
  console.log(`   ${oldEndpoint}`)
  console.log('   Missing: /variants/{variantId} and &country=US\n')

  try {
    await client.request(oldEndpoint)
    console.log('⚠️  OLD endpoint unexpectedly SUCCEEDED')
  } catch (error: any) {
    console.log('✅ OLD endpoint FAILED (as expected)')
    console.log(`   Error: ${error.message}`)
  }

  const newEndpoint = `/v2/catalog/products/${productId}/variants/${variantId}/market-data?currencyCode=USD&country=US`
  console.log('\n✅ NEW (CORRECT) endpoint:')
  console.log(`   ${newEndpoint}`)
  console.log('   Includes: /variants/{variantId} and &country=US\n')

  try {
    const result = await client.request(newEndpoint)
    console.log('✅ NEW endpoint SUCCEEDED')
    console.log('   Response:', JSON.stringify(result, null, 2).substring(0, 200) + '...')
  } catch (error: any) {
    console.log('❌ NEW endpoint FAILED')
    console.log(`   Error: ${error.message}`)
  }

  console.log('\n' + '═'.repeat(75))
  console.log('✅ Endpoint testing complete\n')
}

testCorrectEndpoints().catch(console.error)
