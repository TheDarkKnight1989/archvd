#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function showAllFields() {
  console.log('📋 COMPLETE FIELD LIST FOR master_market_data\n');
  console.log('='.repeat(80));

  // Get one complete record
  const { data, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'alias')
    .eq('sku', 'M2002RDB')
    .limit(1)
    .single();

  if (error || !data) {
    console.error('Error fetching data:', error);
    return;
  }

  console.log('\nSAMPLE RECORD (all fields):\n');
  
  // Show each field with its value
  Object.entries(data).forEach(([field, value]) => {
    const valueStr = value === null ? 'NULL' : 
                     typeof value === 'object' ? JSON.stringify(value) : 
                     String(value);
    console.log(`${field.padEnd(25)} | ${valueStr}`);
  });

  console.log('\n' + '='.repeat(80));
  console.log('\nFIELD CATEGORIES:\n');

  console.log('🔑 Primary Keys:');
  console.log('   - id (UUID)');
  console.log('   - created_at (timestamp)');
  console.log('   - updated_at (timestamp)');

  console.log('\n🏷️  Product Identification:');
  console.log('   - provider (alias, stockx, ebay)');
  console.log('   - sku (product SKU like M2002RDB)');
  console.log('   - size_key (size like 10, 10.5)');
  console.log('   - region_code (US, UK, EU)');

  console.log('\n💰 Pricing Data:');
  console.log('   - lowest_ask (best sell price)');
  console.log('   - highest_bid (best buy price)');
  console.log('   - last_sale_price (most recent sale)');
  console.log('   - last_sale_date (when last sale occurred)');

  console.log('\n📊 Volume Metrics:');
  console.log('   - volume_30d (30-day sales volume)');
  console.log('   - sales_last_72h (recent activity)');

  console.log('\n🏪 Source/Type:');
  console.log('   - provider_source (alias_availabilities, alias_availabilities_consigned)');
  console.log('   - is_consigned (true/false - FLEX consignment)');

  console.log('\n📅 Snapshot Info:');
  console.log('   - snapshot_at (when this data was captured)');
  console.log('   - raw_snapshot_id (link to raw API response)');

  console.log('\n💱 Currency:');
  console.log('   - currency_code (USD, GBP, EUR)');

  console.log('\n🔍 Price Bounds (optional):');
  console.log('   - min_price_bound (price floor)');
  console.log('   - max_price_bound (price ceiling)');

  console.log('\n📦 Metadata (optional):');
  console.log('   - variant_id (provider-specific variant ID)');
  console.log('   - raw_response_excerpt (sample of raw API data)');

  console.log('\n' + '='.repeat(80));
  console.log('\nTOTAL FIELDS: ' + Object.keys(data).length);
}

showAllFields();
