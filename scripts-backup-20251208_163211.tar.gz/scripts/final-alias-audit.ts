/**
 * Final Alias API Integration Audit
 * Tests complete end-to-end integration across multiple SKUs
 * Goal: 100% pass rate
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { syncAliasToMasterMarketData } from '@/lib/services/alias/sync'
import { createClient } from '@supabase/supabase-js'

const TEST_SKUS = ['II1493-600', 'IM3906-100', 'DZ4137-700']

interface AuditResult {
  sku: string
  productName: string
  catalogId: string
  tests: {
    catalogSearch: boolean
    availabilitiesSync: boolean
    recentSalesSync: boolean
    histogramsSync: boolean
    databaseStorage: boolean
    dataQuality: boolean
  }
  metrics: {
    variantsIngested: number
    volumeMetricsUpdated: number
    histogramsIngested: number
    sizesInDatabase: number
    avgLowestAsk: number | null
    avgHighestBid: number | null
    sizesWithSales: number
  }
  issues: string[]
  passed: boolean
}

async function auditSKU(
  client: ReturnType<typeof createAliasClient>,
  supabase: ReturnType<typeof createClient>,
  sku: string
): Promise<AuditResult> {
  const result: AuditResult = {
    sku,
    productName: '',
    catalogId: '',
    tests: {
      catalogSearch: false,
      availabilitiesSync: false,
      recentSalesSync: false,
      histogramsSync: false,
      databaseStorage: false,
      dataQuality: false,
    },
    metrics: {
      variantsIngested: 0,
      volumeMetricsUpdated: 0,
      histogramsIngested: 0,
      sizesInDatabase: 0,
      avgLowestAsk: null,
      avgHighestBid: null,
      sizesWithSales: 0,
    },
    issues: [],
    passed: false,
  }

  console.log(`\n${'═'.repeat(79)}`)
  console.log(`TESTING SKU: ${sku}`)
  console.log('═'.repeat(79))

  // TEST 1: Catalog Search
  console.log('\n[1/6] Testing catalog search...')
  try {
    const searchResults = await client.searchCatalog(sku, { limit: 1 })
    if (!searchResults.catalog_items || searchResults.catalog_items.length === 0) {
      result.issues.push('Catalog search returned no results')
      console.log('❌ No products found')
      return result
    }

    const product = searchResults.catalog_items[0]
    result.productName = product.name
    result.catalogId = product.catalog_id
    result.tests.catalogSearch = true
    console.log(`✅ Found: ${product.name}`)
    console.log(`   Catalog ID: ${product.catalog_id}`)
  } catch (error: any) {
    result.issues.push(`Catalog search failed: ${error.message}`)
    console.log(`❌ Catalog search failed: ${error.message}`)
    return result
  }

  // TEST 2: Sync with all features enabled
  console.log('\n[2/6] Testing full sync (availabilities + recent sales + histograms)...')
  try {
    const syncResult = await syncAliasToMasterMarketData(client, result.catalogId, {
      sku,
      includeConsigned: true,
    })

    if (!syncResult.success) {
      result.issues.push(`Sync failed: ${syncResult.error}`)
      console.log(`❌ Sync failed: ${syncResult.error}`)
      return result
    }

    result.metrics.variantsIngested = syncResult.variantsIngested || 0
    result.metrics.volumeMetricsUpdated = syncResult.volumeMetricsUpdated || 0
    result.metrics.histogramsIngested = syncResult.histogramsIngested || 0

    console.log(`✅ Sync completed`)
    console.log(`   Variants: ${result.metrics.variantsIngested}`)
    console.log(`   Volume metrics: ${result.metrics.volumeMetricsUpdated}`)
    console.log(`   Histogram bins: ${result.metrics.histogramsIngested}`)

    // Validate sync results
    if (result.metrics.variantsIngested === 0) {
      result.issues.push('No variants were ingested')
    } else {
      result.tests.availabilitiesSync = true
    }

    if (result.metrics.volumeMetricsUpdated > 0) {
      result.tests.recentSalesSync = true
    }

    if (result.metrics.histogramsIngested > 0) {
      result.tests.histogramsSync = true
    }
  } catch (error: any) {
    result.issues.push(`Sync error: ${error.message}`)
    console.log(`❌ Sync error: ${error.message}`)
    return result
  }

  // TEST 3: Verify data in master_market_data
  console.log('\n[3/6] Testing database storage (master_market_data)...')
  try {
    const { data: marketData, error } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('sku', sku)
      .eq('provider', 'alias')

    if (error) {
      result.issues.push(`Database query failed: ${error.message}`)
      console.log(`❌ Database query failed: ${error.message}`)
      return result
    }

    if (!marketData || marketData.length === 0) {
      result.issues.push('No data found in master_market_data')
      console.log('❌ No data in database')
      return result
    }

    result.metrics.sizesInDatabase = new Set(marketData.map(row => row.size_key)).size
    result.tests.databaseStorage = true

    console.log(`✅ Found ${marketData.length} rows in database`)
    console.log(`   Unique sizes: ${result.metrics.sizesInDatabase}`)
    console.log(`   Consigned rows: ${marketData.filter(r => r.is_consigned).length}`)
    console.log(`   Standard rows: ${marketData.filter(r => !r.is_consigned).length}`)
  } catch (error: any) {
    result.issues.push(`Database verification failed: ${error.message}`)
    console.log(`❌ Database verification failed: ${error.message}`)
    return result
  }

  // TEST 4: Data quality checks
  console.log('\n[4/6] Testing data quality...')
  try {
    const { data: marketData } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('sku', sku)
      .eq('provider', 'alias')

    if (!marketData) {
      result.issues.push('No data for quality check')
      console.log('❌ No data for quality check')
      return result
    }

    // Check for required fields
    const hasLowestAsk = marketData.filter(row => row.lowest_ask !== null)
    const hasHighestBid = marketData.filter(row => row.highest_bid !== null)
    const hasAskCount = marketData.filter(row => row.ask_count !== null)
    const hasBidCount = marketData.filter(row => row.bid_count !== null)

    console.log('   Data completeness:')
    console.log(`   - Lowest ask: ${hasLowestAsk.length}/${marketData.length} (${((hasLowestAsk.length / marketData.length) * 100).toFixed(1)}%)`)
    console.log(`   - Highest bid: ${hasHighestBid.length}/${marketData.length} (${((hasHighestBid.length / marketData.length) * 100).toFixed(1)}%)`)
    console.log(`   - Ask count: ${hasAskCount.length}/${marketData.length} (${((hasAskCount.length / marketData.length) * 100).toFixed(1)}%)`)
    console.log(`   - Bid count: ${hasBidCount.length}/${marketData.length} (${((hasBidCount.length / marketData.length) * 100).toFixed(1)}%)`)

    // Calculate averages
    const validAsks = hasLowestAsk.map(r => r.lowest_ask).filter((v): v is number => v !== null)
    const validBids = hasHighestBid.map(r => r.highest_bid).filter((v): v is number => v !== null)

    if (validAsks.length > 0) {
      result.metrics.avgLowestAsk = validAsks.reduce((sum, v) => sum + v, 0) / validAsks.length
    }

    if (validBids.length > 0) {
      result.metrics.avgHighestBid = validBids.reduce((sum, v) => sum + v, 0) / validBids.length
    }

    // Data quality thresholds
    const askCoverage = hasLowestAsk.length / marketData.length
    const bidCoverage = hasHighestBid.length / marketData.length

    if (askCoverage >= 0.5 && bidCoverage >= 0.5) {
      result.tests.dataQuality = true
      console.log('✅ Data quality passed (>50% coverage)')
    } else {
      result.issues.push(`Low data coverage: ask=${(askCoverage * 100).toFixed(1)}%, bid=${(bidCoverage * 100).toFixed(1)}%`)
      console.log(`⚠️  Data quality warning: low coverage`)
    }

    if (result.metrics.avgLowestAsk !== null) {
      console.log(`   Avg ask: $${result.metrics.avgLowestAsk.toFixed(2)}`)
    }
    if (result.metrics.avgHighestBid !== null) {
      console.log(`   Avg bid: $${result.metrics.avgHighestBid.toFixed(2)}`)
    }
  } catch (error: any) {
    result.issues.push(`Data quality check failed: ${error.message}`)
    console.log(`❌ Data quality check failed: ${error.message}`)
  }

  // TEST 5: Verify histogram data
  console.log('\n[5/6] Testing histogram data...')
  try {
    const { data: histograms, error } = await supabase
      .from('alias_offer_histograms')
      .select('*')
      .eq('sku', sku)

    if (error) {
      result.issues.push(`Histogram query failed: ${error.message}`)
      console.log(`❌ Histogram query failed: ${error.message}`)
    } else if (!histograms || histograms.length === 0) {
      console.log('⚠️  No histogram data (may be expected for low-liquidity products)')
    } else {
      const uniqueSizes = new Set(histograms.map(h => h.size_value)).size
      const totalOffers = histograms.reduce((sum, h) => sum + (h.offer_count || 0), 0)

      console.log(`✅ Found ${histograms.length} histogram bins`)
      console.log(`   Sizes with histograms: ${uniqueSizes}`)
      console.log(`   Total tracked offers: ${totalOffers}`)
    }
  } catch (error: any) {
    result.issues.push(`Histogram verification failed: ${error.message}`)
    console.log(`❌ Histogram verification failed: ${error.message}`)
  }

  // TEST 6: Verify recent sales data
  console.log('\n[6/6] Testing recent sales data...')
  try {
    const { data: salesData, error } = await supabase
      .from('master_market_data')
      .select('size_key, sales_last_72h')
      .eq('sku', sku)
      .eq('provider', 'alias')
      .not('sales_last_72h', 'is', null)

    if (error) {
      result.issues.push(`Sales data query failed: ${error.message}`)
      console.log(`❌ Sales data query failed: ${error.message}`)
    } else if (!salesData || salesData.length === 0) {
      console.log('⚠️  No recent sales data (may be expected for low-volume products)')
    } else {
      result.metrics.sizesWithSales = salesData.length
      const totalSales = salesData.reduce((sum, row) => sum + (row.sales_last_72h || 0), 0)

      console.log(`✅ Found sales data for ${salesData.length} sizes`)
      console.log(`   Total sales (72h): ${totalSales}`)
    }
  } catch (error: any) {
    result.issues.push(`Sales data verification failed: ${error.message}`)
    console.log(`❌ Sales data verification failed: ${error.message}`)
  }

  // Final pass/fail determination
  const criticalTests = [
    result.tests.catalogSearch,
    result.tests.availabilitiesSync,
    result.tests.databaseStorage,
  ]

  result.passed = criticalTests.every(t => t === true) && result.issues.length === 0

  console.log('\n' + '─'.repeat(79))
  console.log('TEST SUMMARY:')
  console.log(`  Catalog Search: ${result.tests.catalogSearch ? '✅' : '❌'}`)
  console.log(`  Availabilities Sync: ${result.tests.availabilitiesSync ? '✅' : '❌'}`)
  console.log(`  Recent Sales Sync: ${result.tests.recentSalesSync ? '✅' : '⚠️ '}`)
  console.log(`  Histograms Sync: ${result.tests.histogramsSync ? '✅' : '⚠️ '}`)
  console.log(`  Database Storage: ${result.tests.databaseStorage ? '✅' : '❌'}`)
  console.log(`  Data Quality: ${result.tests.dataQuality ? '✅' : '⚠️ '}`)
  console.log(`  OVERALL: ${result.passed ? '✅ PASSED' : '❌ FAILED'}`)

  if (result.issues.length > 0) {
    console.log(`\n  Issues (${result.issues.length}):`)
    result.issues.forEach(issue => console.log(`    - ${issue}`))
  }

  return result
}

async function main() {
  console.log('═'.repeat(79))
  console.log('ALIAS API INTEGRATION - FINAL AUDIT')
  console.log('═'.repeat(79))
  console.log(`Testing ${TEST_SKUS.length} SKUs: ${TEST_SKUS.join(', ')}`)
  console.log(`Feature Flags:`)
  console.log(`  ALIAS_RECENT_SALES_ENABLED: ${process.env.ALIAS_RECENT_SALES_ENABLED}`)
  console.log(`  ALIAS_HISTOGRAMS_ENABLED: ${process.env.ALIAS_HISTOGRAMS_ENABLED}`)
  console.log('═'.repeat(79))

  // Verify feature flags
  if (process.env.ALIAS_RECENT_SALES_ENABLED !== 'true') {
    console.log('\n⚠️  WARNING: ALIAS_RECENT_SALES_ENABLED is not "true"')
  }
  if (process.env.ALIAS_HISTOGRAMS_ENABLED !== 'true') {
    console.log('\n⚠️  WARNING: ALIAS_HISTOGRAMS_ENABLED is not "true"')
  }

  const client = createAliasClient()
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const results: AuditResult[] = []

  for (const sku of TEST_SKUS) {
    const result = await auditSKU(client, supabase, sku)
    results.push(result)
  }

  // Final summary
  console.log('\n\n' + '═'.repeat(79))
  console.log('FINAL AUDIT REPORT')
  console.log('═'.repeat(79))

  const passCount = results.filter(r => r.passed).length
  const failCount = results.filter(r => !r.passed).length
  const passRate = (passCount / results.length) * 100

  console.log(`\nTested SKUs: ${results.length}`)
  console.log(`Passed: ${passCount} ✅`)
  console.log(`Failed: ${failCount} ${failCount > 0 ? '❌' : ''}`)
  console.log(`Pass Rate: ${passRate.toFixed(1)}%`)

  console.log('\n' + '─'.repeat(79))
  console.log('DETAILED RESULTS:\n')

  results.forEach((result, index) => {
    console.log(`${index + 1}. ${result.sku} - ${result.productName}`)
    console.log(`   Status: ${result.passed ? '✅ PASSED' : '❌ FAILED'}`)
    console.log(`   Variants: ${result.metrics.variantsIngested}`)
    console.log(`   Database sizes: ${result.metrics.sizesInDatabase}`)
    console.log(`   Histogram bins: ${result.metrics.histogramsIngested}`)
    console.log(`   Volume metrics: ${result.metrics.volumeMetricsUpdated}`)
    if (result.metrics.avgLowestAsk) {
      console.log(`   Avg ask: $${result.metrics.avgLowestAsk.toFixed(2)}`)
    }
    if (result.issues.length > 0) {
      console.log(`   Issues: ${result.issues.join(', ')}`)
    }
    console.log()
  })

  console.log('═'.repeat(79))
  if (passRate === 100) {
    console.log('🎉 100% PASS RATE - ALL TESTS PASSED! 🎉')
    console.log('✅ Alias API integration is PRODUCTION READY')
  } else {
    console.log(`⚠️  ${passRate.toFixed(1)}% pass rate - Review failures above`)
  }
  console.log('═'.repeat(79))

  process.exit(passRate === 100 ? 0 : 1)
}

main().catch((error) => {
  console.error('\n❌ FATAL ERROR:', error)
  process.exit(1)
})
