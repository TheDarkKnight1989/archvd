#!/usr/bin/env node

/**
 * Show all market data for a specific SKU across all sizes
 * Clean format: one line per size showing StockX + Alias data
 */

import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

const SKU = 'DD1391-100'
const SIZES = [6, 7, 8, 9, 10, 11, 12] // UK sizes

async function showSkuData() {
  console.log('\n' + '='.repeat(120))
  console.log(`SKU: ${SKU} - Market Data Breakdown`)
  console.log('='.repeat(120))

  // Fetch all master_market_latest data for this SKU
  const { data: allData, error } = await supabase
    .from('master_market_latest')
    .select('*')
    .eq('sku', SKU)
    .order('size_numeric', { ascending: true })

  if (error) {
    console.error('❌ Error:', error.message)
    return
  }

  if (!allData || allData.length === 0) {
    console.log('❌ No data found for SKU:', SKU)
    return
  }

  console.log(`\n✅ Found ${allData.length} price records\n`)

  // Group by size
  const bySizeAndProvider = new Map()

  for (const record of allData) {
    const sizeKey = record.size_key || record.size_numeric || 'Unknown'
    if (!bySizeAndProvider.has(sizeKey)) {
      bySizeAndProvider.set(sizeKey, {})
    }

    const sizeData = bySizeAndProvider.get(sizeKey)
    const provider = record.provider
    const currency = record.currency_code

    if (!sizeData[provider]) {
      sizeData[provider] = {}
    }

    sizeData[provider][currency] = {
      lowest_ask: record.lowest_ask,
      highest_bid: record.highest_bid,
      last_sale: record.last_sale_price,
      snapshot_at: record.snapshot_at,
      provider_source: record.provider_source,
    }
  }

  // Print header
  console.log('SIZE'.padEnd(8) +
              'PROVIDER'.padEnd(12) +
              'CURRENCY'.padEnd(10) +
              'LOWEST ASK'.padEnd(14) +
              'HIGHEST BID'.padEnd(14) +
              'LAST SALE'.padEnd(14) +
              'SOURCE')
  console.log('-'.repeat(120))

  // Print each size
  const sortedSizes = Array.from(bySizeAndProvider.keys()).sort((a, b) => {
    const aNum = parseFloat(a)
    const bNum = parseFloat(b)
    return aNum - bNum
  })

  for (const size of sortedSizes) {
    const providers = bySizeAndProvider.get(size)
    let firstLine = true

    // StockX data
    if (providers.stockx) {
      for (const [currency, data] of Object.entries(providers.stockx)) {
        const sizeStr = firstLine ? `UK ${size}` : ''
        const ask = data.lowest_ask ? `${currency} ${data.lowest_ask}` : '-'
        const bid = data.highest_bid ? `${currency} ${data.highest_bid}` : '-'
        const sale = data.last_sale ? `${currency} ${data.last_sale}` : '-'

        console.log(
          sizeStr.padEnd(8) +
          'StockX'.padEnd(12) +
          currency.padEnd(10) +
          ask.padEnd(14) +
          bid.padEnd(14) +
          sale.padEnd(14) +
          (data.provider_source || '')
        )
        firstLine = false
      }
    }

    // Alias data
    if (providers.alias) {
      for (const [currency, data] of Object.entries(providers.alias)) {
        const sizeStr = firstLine ? `UK ${size}` : ''
        const ask = data.lowest_ask ? `${currency} ${data.lowest_ask}` : '-'
        const bid = data.highest_bid ? `${currency} ${data.highest_bid}` : '-'
        const sale = data.last_sale ? `${currency} ${data.last_sale}` : '-'

        console.log(
          sizeStr.padEnd(8) +
          'Alias'.padEnd(12) +
          currency.padEnd(10) +
          ask.padEnd(14) +
          bid.padEnd(14) +
          sale.padEnd(14) +
          (data.provider_source || '')
        )
        firstLine = false
      }
    }

    console.log('-'.repeat(120))
  }

  console.log('\n' + '='.repeat(120))
  console.log('SUMMARY')
  console.log('='.repeat(120))
  console.log(`Total sizes in DB: ${bySizeAndProvider.size}`)
  console.log(`StockX coverage: ${Array.from(bySizeAndProvider.values()).filter(p => p.stockx).length} sizes`)
  console.log(`Alias coverage: ${Array.from(bySizeAndProvider.values()).filter(p => p.alias).length} sizes`)
  console.log('='.repeat(120) + '\n')
}

showSkuData().catch(console.error)
