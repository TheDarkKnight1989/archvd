#!/usr/bin/env npx tsx
/**
 * Fix StockX Mapping - Best-in-Class Approach
 *
 * Problem: StockX search was returning wrong products, all mapped to same ID
 * Solution: Validate search results before mapping, only map exact matches
 */

import { createClient } from '@supabase/supabase-js'
import { searchProducts as searchStockX } from '../src/lib/services/stockx/products'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🔧 Fixing StockX Product Mapping')
  console.log('='.repeat(80))
  console.log('Step 1: Clear bad mappings')
  console.log('Step 2: Re-map with validation')
  console.log('='.repeat(80) + '\n')

  // ========================================================================
  // STEP 1: Clear all StockX mappings from product_variants
  // ========================================================================
  console.log('🧹 Clearing existing StockX mappings...')

  const { error: clearError } = await supabase
    .from('product_variants')
    .update({ stockx_product_id: null })
    .not('stockx_product_id', 'is', null)

  if (clearError) {
    console.error('Failed to clear mappings:', clearError.message)
    return
  }

  console.log('✅ Cleared all existing StockX mappings\n')

  // ========================================================================
  // STEP 2: Get all products and re-map with validation
  // ========================================================================
  const { data: products } = await supabase
    .from('products')
    .select('id, sku, brand, model')
    .order('sku')

  console.log(`📦 Processing ${products?.length || 0} products\n`)

  let exactMatches = 0
  let fuzzyMatches = 0
  let noMatches = 0
  let errors = 0

  for (const product of products || []) {
    try {
      console.log(`🔍 ${product.sku}`)

      // Search StockX (searchProducts signature: query, options)
      const searchResults = await searchStockX(product.sku, { limit: 5 })

      if (searchResults.products.length === 0) {
        console.log(`  ⏭️  No results found\n`)
        noMatches++
        await new Promise(resolve => setTimeout(resolve, 1000))
        continue
      }

      // Validate match quality
      let bestMatch = null
      let matchType = 'none'

      for (const result of searchResults.products) {
        // Note: searchProducts() maps API's styleId → result.sku
        const resultSku = result.sku?.toUpperCase() || ''
        const productSku = product.sku.toUpperCase()

        // EXACT match: result SKU === product SKU
        if (resultSku === productSku) {
          bestMatch = result
          matchType = 'exact'
          break
        }

        // FUZZY match: SKU appears in title or result SKU contains our SKU
        if (!bestMatch && (
          result.name?.toUpperCase().includes(productSku) ||
          resultSku.includes(productSku) ||
          productSku.includes(resultSku)
        )) {
          bestMatch = result
          matchType = 'fuzzy'
        }
      }

      if (!bestMatch) {
        console.log(`  ⚠️  No valid match found (searched ${searchResults.products.length} results)`)
        console.log(`      Best result: ${searchResults.products[0].sku} - ${searchResults.products[0].name}`)
        console.log(`      Does not match: ${product.sku}\n`)
        noMatches++
        await new Promise(resolve => setTimeout(resolve, 1000))
        continue
      }

      // Update product_variants with validated match
      const { error: updateError } = await supabase
        .from('product_variants')
        .update({ stockx_product_id: bestMatch.id })
        .eq('product_id', product.id)

      if (updateError) {
        console.log(`  ❌ Update failed: ${updateError.message}\n`)
        errors++
      } else {
        if (matchType === 'exact') {
          console.log(`  ✅ EXACT match: ${bestMatch.sku} → ${bestMatch.id}`)
          exactMatches++
        } else {
          console.log(`  ⚠️  FUZZY match: ${bestMatch.sku} → ${bestMatch.id}`)
          console.log(`      Title: ${bestMatch.name}`)
          fuzzyMatches++
        }

        // Update product metadata from StockX
        await supabase
          .from('products')
          .update({
            brand: bestMatch.brand || product.brand,
            model: bestMatch.name || product.model,
            image_url: bestMatch.media?.imageUrl || product.image_url,
          })
          .eq('id', product.id)
      }

      console.log('')

      // Rate limit
      await new Promise(resolve => setTimeout(resolve, 1500))

    } catch (error: any) {
      console.log(`  ❌ Error: ${error.message}\n`)
      errors++
      await new Promise(resolve => setTimeout(resolve, 2000))
    }
  }

  // ========================================================================
  // STEP 3: Summary
  // ========================================================================
  console.log('='.repeat(80))
  console.log('📊 MAPPING RESULTS')
  console.log('='.repeat(80))
  console.log(`✅ Exact matches: ${exactMatches}`)
  console.log(`⚠️  Fuzzy matches: ${fuzzyMatches}`)
  console.log(`⏭️  No matches: ${noMatches}`)
  console.log(`❌ Errors: ${errors}`)
  console.log(`📦 Total processed: ${products?.length || 0}`)
  console.log('')

  // Verify no duplicate mappings
  const { data: duplicateCheck } = await supabase
    .from('product_variants')
    .select('stockx_product_id')
    .not('stockx_product_id', 'is', null)

  const idCounts = new Map<string, number>()
  duplicateCheck?.forEach(v => {
    const id = v.stockx_product_id
    idCounts.set(id, (idCounts.get(id) || 0) + 1)
  })

  const duplicates = Array.from(idCounts.entries()).filter(([_, count]) => count > 1)

  if (duplicates.length > 0) {
    console.log('⚠️  WARNING: Duplicate mappings detected:')
    duplicates.forEach(([id, count]) => {
      console.log(`   ${id}: ${count} products`)
    })
  } else {
    console.log('✅ No duplicate mappings - all products have unique StockX IDs')
  }

  console.log('')
}

main().catch(console.error)
