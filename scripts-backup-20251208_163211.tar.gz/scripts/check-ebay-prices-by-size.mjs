/**
 * Query eBay prices by size for a specific SKU
 */

import 'dotenv/config'
import { createClient } from '@supabase/supabase-js'

const SKU = process.argv[2] || 'DZ4137-700'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

async function main() {
  const { data, error } = await supabase
    .from('master_market_data')
    .select('size_key, size_numeric, last_sale_price, currency_code')
    .eq('provider', 'ebay')
    .ilike('sku', `%${SKU}%`)
    .order('size_numeric', { ascending: true })

  if (error) {
    console.error('Error:', error)
    process.exit(1)
  }

  console.log('\n' + '═'.repeat(63))
  console.log(`${SKU} - eBay Market Data by Size`)
  console.log('═'.repeat(63) + '\n')

  if (!data || data.length === 0) {
    console.log('No data found')
    process.exit(0)
  }

  console.log('Size      | Price      | Currency')
  console.log('----------|------------|----------')

  data.forEach((row) => {
    const size = (row.size_key || 'N/A').padEnd(8)
    const price = row.last_sale_price
      ? '£' + row.last_sale_price.toFixed(2).padStart(7)
      : 'N/A'.padStart(9)
    const currency = row.currency_code || 'N/A'
    console.log(`${size} | ${price} | ${currency}`)
  })

  const validPrices = data.filter((r) => r.last_sale_price).map((r) => r.last_sale_price)

  if (validPrices.length > 0) {
    const avg = validPrices.reduce((sum, p) => sum + p, 0) / validPrices.length
    const min = Math.min(...validPrices)
    const max = Math.max(...validPrices)

    console.log('----------|------------|----------')
    console.log(`Average:  | £${avg.toFixed(2).padStart(7)} |`)
    console.log(`Min:      | £${min.toFixed(2).padStart(7)} |`)
    console.log(`Max:      | £${max.toFixed(2).padStart(7)} |`)
  }

  console.log('═'.repeat(63) + '\n')
}

main()
