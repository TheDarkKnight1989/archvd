#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function showStockXData() {
  console.log('🔍 ACTUAL STOCKX DATABASE DATA\n');
  console.log('='.repeat(80));

  // Query recent StockX data
  const { data, error } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')
    .order('snapshot_at', { ascending: false })
    .limit(100);

  if (error) {
    console.error('Query error:', error);
    return;
  }

  if (!data || data.length === 0) {
    console.log('❌ No StockX data found in master_market_data');
    return;
  }

  console.log(`\n📦 Total StockX Records: ${data.length}\n`);

  // Group by SKU
  const bySku = data.reduce((acc, row) => {
    if (!acc[row.sku]) acc[row.sku] = [];
    acc[row.sku].push(row);
    return acc;
  }, {} as Record<string, any[]>);

  console.log('PRODUCTS IN DATABASE:\n');
  Object.entries(bySku).forEach(([sku, records]) => {
    const sizes = Array.from(new Set(records.map(r => parseFloat(r.size_key)))).sort((a,b) => a-b);
    const regions = Array.from(new Set(records.map(r => r.region_code)));
    console.log(`${sku}:`);
    console.log(`  Records: ${records.length}`);
    console.log(`  Sizes: ${sizes[0]} - ${sizes[sizes.length-1]} (${sizes.length} unique)`);
    console.log(`  All sizes: ${sizes.join(', ')}`);
    console.log(`  Regions: ${regions.join(', ')}`);
    console.log('');
  });

  console.log('='.repeat(80));
  console.log('\nSAMPLE STOCKX RECORDS (first 10):\n');

  data.slice(0, 10).forEach((row, i) => {
    console.log(`Record ${i + 1}:`);
    console.log(`  SKU: ${row.sku}`);
    console.log(`  Size: ${row.size_key}`);
    console.log(`  Region: ${row.region_code}`);
    console.log(`  Currency: ${row.currency_code}`);
    console.log(`  Lowest Ask: ${row.lowest_ask ? `$${row.lowest_ask/100}` : 'NULL'}`);
    console.log(`  Highest Bid: ${row.highest_bid ? `$${row.highest_bid/100}` : 'NULL'}`);
    console.log(`  Last Sale: ${row.last_sale_price ? `$${row.last_sale_price/100}` : 'NULL'}`);
    console.log(`  Sales 72h: ${row.sales_last_72h ?? 'NULL'}`);
    console.log(`  Snapshot: ${row.snapshot_at}`);
    console.log('');
  });

  console.log('='.repeat(80));
  console.log('\nCOMPLETE FIELD LIST (one record):\n');

  const sampleRecord = data[0];
  Object.entries(sampleRecord).forEach(([field, value]) => {
    const valueStr = value === null ? 'NULL' : 
                     typeof value === 'object' ? JSON.stringify(value) : 
                     String(value);
    console.log(`${field.padEnd(25)} | ${valueStr}`);
  });

  console.log('\n' + '='.repeat(80));
  console.log('\nDATA QUALITY CHECK:\n');

  const withLowestAsk = data.filter(r => r.lowest_ask !== null).length;
  const withHighestBid = data.filter(r => r.highest_bid !== null).length;
  const withLastSale = data.filter(r => r.last_sale_price !== null).length;
  const withAnyPrice = data.filter(r => 
    r.lowest_ask !== null || r.highest_bid !== null || r.last_sale_price !== null
  ).length;

  console.log(`Records with ANY price:    ${withAnyPrice}/${data.length} (${Math.round(withAnyPrice/data.length*100)}%)`);
  console.log(`Records with lowest_ask:   ${withLowestAsk}/${data.length} (${Math.round(withLowestAsk/data.length*100)}%)`);
  console.log(`Records with highest_bid:  ${withHighestBid}/${data.length} (${Math.round(withHighestBid/data.length*100)}%)`);
  console.log(`Records with last_sale:    ${withLastSale}/${data.length} (${Math.round(withLastSale/data.length*100)}%)`);

  console.log('\n' + '='.repeat(80));
}

showStockXData();
