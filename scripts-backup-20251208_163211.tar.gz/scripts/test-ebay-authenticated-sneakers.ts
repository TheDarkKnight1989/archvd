/**
 * Test script for eBay Authenticated New Sneakers
 *
 * This demonstrates how to search for NEW sneakers with Authenticity Guarantee
 *
 * Usage:
 *   npx tsx scripts/test-ebay-authenticated-sneakers.ts
 */

import { searchAuthenticatedNewSneakers } from '@/lib/services/ebay/sneakers'
import { ebayConfig } from '@/lib/services/ebay/config'

async function main() {
  console.log('='.repeat(80))
  console.log('eBay Authenticated New Sneakers - Test Script')
  console.log('='.repeat(80))

  console.log('\nConfig:')
  console.log('  Environment:', ebayConfig.env)
  console.log('  Market Data Enabled:', ebayConfig.marketDataEnabled)

  if (!ebayConfig.marketDataEnabled) {
    console.error('\n❌ EBAY_MARKET_DATA_ENABLED is not true')
    process.exit(1)
  }

  // Test cases - popular sneaker models
  const testQueries = [
    'Jordan 4 Black Cat',
    'DD1391-100', // Jordan 4 Black Cat SKU
    'Nike Dunk Low Panda',
    'Yeezy 350',
    'New Balance 990v6',
  ]

  console.log('\n' + '='.repeat(80))
  console.log('Searching for NEW + AUTHENTICATED sneakers')
  console.log('='.repeat(80))

  for (const query of testQueries) {
    console.log(`\n🔍 Query: "${query}"`)

    try {
      const result = await searchAuthenticatedNewSneakers(query, {
        limit: 10, // Fewer results for testing
        soldItemsOnly: true, // Only sold items for market data
      })

      console.log(`   ✅ Found ${result.items.length} sold items`)

      if (result.items.length > 0) {
        // Show first 3 items
        console.log(`\n   Sample items:`)
        result.items.slice(0, 3).forEach((item, idx) => {
          console.log(`   ${idx + 1}. ${item.title}`)
          console.log(`      Price: ${item.currency} ${item.price}`)
          console.log(`      Sold: ${item.soldAt}`)
          console.log(`      Item ID: ${item.itemId}`)
        })

        // Calculate market stats
        const prices = result.items.map((i) => i.price)
        const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length
        const minPrice = Math.min(...prices)
        const maxPrice = Math.max(...prices)

        console.log(`\n   📊 Market Stats:`)
        console.log(`      Average: ${result.items[0].currency} ${avgPrice.toFixed(2)}`)
        console.log(`      Range: ${result.items[0].currency} ${minPrice} - ${maxPrice}`)
        console.log(`      Sales: ${result.items.length} items`)
      }
    } catch (error) {
      console.error(`   ❌ Error:`, error)
    }

    // Delay between requests
    await new Promise((resolve) => setTimeout(resolve, 1000))
  }

  console.log('\n' + '='.repeat(80))
  console.log('Test completed!')
  console.log('='.repeat(80))
  console.log('\nWhat you just searched for:')
  console.log('  ✅ NEW condition (conditionId: 1000)')
  console.log('  ✅ Authenticity Guarantee program')
  console.log('  ✅ Athletic sneaker categories')
  console.log('  ✅ Sold items only')
  console.log('\nNext steps:')
  console.log('  1. Use this data for market pricing insights')
  console.log('  2. Ingest into master_market_data for tracking')
  console.log('  3. Compare with StockX/Alias pricing')
}

main().catch((error) => {
  console.error('Fatal error:', error)
  process.exit(1)
})
