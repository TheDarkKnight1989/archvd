#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function check() {
  console.log('🔍 CHECKING STOCKX DATA\n');
  console.log('='.repeat(80));

  // Check for any recent StockX data
  const { data, error } = await supabase
    .from('master_market_data')
    .select('sku, size_key, provider, region_code, lowest_ask, highest_bid')
    .eq('provider', 'stockx')
    .order('snapshot_at', { ascending: false })
    .limit(50);

  if (error) {
    console.error('Query error:', error);
    return;
  }

  if (!data || data.length === 0) {
    console.log('❌ No StockX data found in master_market_data');
    console.log('\nStockX sync may not be implemented yet for master_market_data.');
    return;
  }

  console.log(`Found ${data.length} StockX records\n`);

  // Group by SKU
  const bySku = data.reduce((acc, row) => {
    if (!acc[row.sku]) acc[row.sku] = [];
    acc[row.sku].push(row);
    return acc;
  }, {} as Record<string, any[]>);

  console.log('SKUs with StockX data:');
  Object.entries(bySku).forEach(([sku, records]) => {
    const sizes = Array.from(new Set(records.map(r => parseFloat(r.size_key)))).sort((a,b) => a-b);
    console.log(`  ${sku}: ${records.length} records, sizes ${sizes[0]}-${sizes[sizes.length-1]}`);
  });

  console.log('\n' + '='.repeat(80));
  console.log('Sample StockX records:\n');
  data.slice(0, 10).forEach(row => {
    console.log(`${row.sku} | Size ${row.size_key} | ${row.region_code} | Ask: ${row.lowest_ask ? `$${row.lowest_ask}` : 'NULL'}`);
  });
}

check();
