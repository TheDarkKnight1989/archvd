/**
 * Test script for Alias recent_sales integration
 * Run with: ALIAS_RECENT_SALES_ENABLED=true TEST_ALIAS_CATALOG_ID=xxx npx tsx scripts/test-alias-integration.ts
 */

import { createAliasClient } from '../src/lib/services/alias/index';
import { syncAliasToMasterMarketData } from '../src/lib/services/alias/sync';
import { createClient } from '@supabase/supabase-js';

const TEST_CATALOG_ID = process.env.TEST_ALIAS_CATALOG_ID || 'tom-sachs-x-nikecraft-mars-yard-2-0-aa2261-100';
const TEST_SKU = 'AA2261-100';

async function main() {
  console.log('🧪 Testing Alias Recent Sales Integration');
  console.log('==========================================\n');

  // Check feature flag
  const recentSalesEnabled = process.env.ALIAS_RECENT_SALES_ENABLED === 'true';
  console.log('Feature flag ALIAS_RECENT_SALES_ENABLED:', recentSalesEnabled);

  if (!recentSalesEnabled) {
    console.warn('⚠️  Recent sales is DISABLED. Set ALIAS_RECENT_SALES_ENABLED=true to test.');
    console.warn('   Will still test availabilities ingestion only.\n');
  }

  // Validate environment
  if (!process.env.ALIAS_PAT) {
    console.error('❌ ALIAS_PAT environment variable not set');
    process.exit(1);
  }

  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    console.error('❌ Supabase environment variables not set');
    process.exit(1);
  }

  const client = createAliasClient();
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
  );

  console.log(`\n📦 Testing: Mars Yard 2.0`);
  console.log(`   Catalog ID: ${TEST_CATALOG_ID}`);
  console.log(`   SKU: ${TEST_SKU}`);
  console.log('   ' + '─'.repeat(60));

  try {
    // ========================================================================
    // Step 1: Sync to master_market_data
    // ========================================================================

    console.log('\n[1] Syncing to master_market_data...');
    const syncResult = await syncAliasToMasterMarketData(client, TEST_CATALOG_ID, {
      sku: TEST_SKU,
      regionId: undefined, // Global
      includeConsigned: true,
    });

    console.log('\nSync result:', {
      success: syncResult.success,
      variantsIngested: syncResult.variantsIngested,
      volumeMetricsUpdated: syncResult.volumeMetricsUpdated,
      error: syncResult.error,
    });

    if (!syncResult.success) {
      console.error('❌ Sync failed:', syncResult.error);
      process.exit(1);
    }

    // ========================================================================
    // Step 2: Query master_market_data to verify
    // ========================================================================

    console.log('\n[2] Querying master_market_data...');
    const { data: marketData, error: queryError } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('provider', 'alias')
      .eq('sku', TEST_SKU)
      .order('size_numeric', { ascending: true })
      .limit(5);

    if (queryError) {
      console.error('❌ Query failed:', queryError.message);
      process.exit(1);
    }

    if (!marketData || marketData.length === 0) {
      console.warn('⚠️  No data found in master_market_data');
      process.exit(1);
    }

    console.log(`\nFound ${marketData.length} rows in master_market_data:`);

    for (const row of marketData.slice(0, 3)) {
      console.log(`\n   Size ${row.size_key} (consigned: ${row.is_consigned}):`)
      console.log(`      Lowest Ask: $${row.lowest_ask || 'NULL'}`);
      console.log(`      Highest Bid: $${row.highest_bid || 'NULL'}`);
      console.log(`      Sales 72h: ${row.sales_last_72h !== null ? row.sales_last_72h : 'NULL'}`);
      console.log(`      Sales 30d: ${row.sales_last_30d !== null ? row.sales_last_30d : 'NULL'}`);
      console.log(`      Last Sale: $${row.last_sale_price || 'NULL'}`);
      console.log(`      Global Indicator: $${row.global_indicator_price || 'NULL'}`);
      console.log(`      Snapshot: ${new Date(row.snapshot_at).toLocaleString()}`);
    }

    // ========================================================================
    // Step 3: Validate volume metrics
    // ========================================================================

    console.log('\n[3] Validating volume metrics...');

    let volumeIssues = 0;
    for (const row of marketData) {
      if (row.sales_last_72h === null || row.sales_last_72h === undefined) {
        console.warn(`   ⚠️  Size ${row.size_key}: sales_last_72h is NULL`);
        volumeIssues++;
      }
      if (row.sales_last_30d === null || row.sales_last_30d === undefined) {
        console.warn(`   ⚠️  Size ${row.size_key}: sales_last_30d is NULL`);
        volumeIssues++;
      }
      if (row.last_sale_price === null || row.last_sale_price === undefined) {
        console.warn(`   ⚠️  Size ${row.size_key}: last_sale_price is NULL`);
        volumeIssues++;
      }
    }

    if (volumeIssues > 0 && recentSalesEnabled) {
      console.error(`\n   ❌ Found ${volumeIssues} volume metric issues (recent_sales should have populated these)`);
    } else if (volumeIssues > 0 && !recentSalesEnabled) {
      console.log(`\n   ℹ️  Volume metrics are NULL (expected when ALIAS_RECENT_SALES_ENABLED=false)`);
    } else {
      console.log('\n   ✅ All volume metrics populated!');
    }

    console.log('\n✅ Test completed successfully');

  } catch (error) {
    console.error('❌ Test failed:', error instanceof Error ? error.message : String(error));
    if (error instanceof Error && error.stack) {
      console.error(error.stack);
    }
    process.exit(1);
  }

  console.log('\n\n📊 Test Summary');
  console.log('================');
  console.log('Integration test complete.');
  console.log('\nNext steps:');
  console.log('1. Check output above for any issues');
  console.log('2. Enable feature flag in production: ALIAS_RECENT_SALES_ENABLED=true');
  console.log('3. Monitor logs for [AliasRecentSales] messages');
}

main().catch((err) => {
  console.error('❌ Script failed:', err);
  process.exit(1);
});
