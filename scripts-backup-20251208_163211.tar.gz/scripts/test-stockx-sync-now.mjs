#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js';

const SKU = 'II1493-600';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function testSync() {
  console.log('🔍 Testing StockX Sync for SKU:', SKU);
  console.log('='.repeat(80));

  // 1. Find product in catalog
  const { data: product, error: findError } = await supabase
    .from('product_catalog')
    .select('id, sku, stockx_product_id')
    .eq('sku', SKU)
    .single();

  if (findError || !product) {
    console.log('\n❌ Product not found in catalog:', SKU);
    console.log('   Error:', findError?.message);
    return;
  }

  console.log('\n✅ Found product:');
  console.log('   Catalog ID:', product.id);
  console.log('   SKU:', product.sku);
  console.log('   StockX Product ID:', product.stockx_product_id || 'NOT SET');

  if (!product.stockx_product_id) {
    console.log('\n❌ No stockx_product_id - cannot sync');
    return;
  }

  // 2. Import and run refresh
  console.log('\n🔄 Running refreshStockxMarketData...\n');

  const { refreshStockxMarketData } = await import('../src/lib/services/stockx/market-refresh.ts');

  const result = await refreshStockxMarketData(
    undefined, // no user ID
    product.stockx_product_id,
    'GBP' // currency
  );

  console.log('\n📊 RESULT:');
  console.log(JSON.stringify(result, null, 2));

  // 3. Check what was written to master_market_data
  if (result.success) {
    console.log('\n✅ Sync complete! Checking database...\n');

    const { data: rows } = await supabase
      .from('master_market_data')
      .select('provider, sku, size_key, lowest_ask, highest_bid, sales_last_30d, is_flex, snapshot_at')
      .eq('provider', 'stockx')
      .eq('sku', SKU)
      .order('size_numeric', { ascending: true })
      .limit(10);

    console.log('📦 Data in master_market_data:');
    if (rows && rows.length > 0) {
      rows.forEach(row => {
        console.log(
          '   Size', (row.size_key || '?').padEnd(5),
          'Ask:', (row.lowest_ask || 'NULL').toString().padStart(7),
          'Bid:', (row.highest_bid || 'NULL').toString().padStart(7),
          'Sales:', (row.sales_last_30d || 'NULL').toString().padStart(3),
          'Flex:', row.is_flex ? 'Y' : 'N'
        );
      });
    } else {
      console.log('   ❌ No rows found in master_market_data');
    }
  } else {
    console.log('\n❌ Sync failed:', result.error);
    if (result.warning) {
      console.log('   Warning:', result.warning);
    }
  }
}

testSync().catch(err => {
  console.error('\n❌ Error:', err.message);
  console.error(err.stack);
});
