/**
 * Test Master Market Data Integration
 *
 * Tests:
 * - PHASE 2: StockX → master_market_data (USD, US region)
 * - PHASE 3: Alias UK → master_market_data (GBP, UK region)
 *
 * Test SKU: DD1391-100 (Jordan 4 Black Cat)
 * Region: UK ONLY for Alias
 */

import { createClient } from '@supabase/supabase-js'
import { refreshStockxMarketData } from '@/lib/services/stockx/market-refresh'
import { syncAliasToMasterMarketData } from '@/lib/services/alias/sync'
import { AliasClient } from '@/lib/services/alias/client'

// ============================================================================
// Configuration
// ============================================================================

const TEST_SKU = 'FV5029-010' // Jordan 4 Black Cat
const ALIAS_REGION_ID_UK = '3' // UK region

// ============================================================================
// Helper: Display Results
// ============================================================================

function displayResults(results: any[], provider: string, region: string) {
  if (results.length === 0) {
    console.log(`\n❌ No rows found for ${provider} (${region})`)
    return
  }

  console.log(`\n✅ Found ${results.length} ${provider} (${region}) rows:\n`)

  // Group by SKU
  const groupedBySku = results.reduce((acc, row) => {
    const sku = row.sku || 'Unknown'
    if (!acc[sku]) acc[sku] = []
    acc[sku].push(row)
    return acc
  }, {} as Record<string, any[]>)

  for (const [sku, rows] of Object.entries(groupedBySku)) {
    console.log(`📦 SKU: ${sku}`)
    console.log(`   Currency: ${rows[0].currency_code}`)
    console.log(`   Region: ${rows[0].region_code}`)
    console.log(`   Sizes found: ${rows.length}`)

    // Sort by size
    const sortedRows = rows.sort((a, b) => (a.size_numeric || 0) - (b.size_numeric || 0))

    for (const row of sortedRows) {
      console.log(`   • Size ${row.size_key}:`)

      if (row.lowest_ask) {
        console.log(`     Lowest Ask: ${row.currency_code} ${row.lowest_ask.toFixed(2)}`)
      }

      if (row.highest_bid) {
        console.log(`     Highest Bid: ${row.currency_code} ${row.highest_bid.toFixed(2)}`)
      }

      if (row.last_sale_price) {
        console.log(`     Last Sale: ${row.currency_code} ${row.last_sale_price.toFixed(2)}`)
      }

      if (row.sales_last_72h !== null) {
        console.log(`     Sales (72h): ${row.sales_last_72h}`)
      }

      if (row.sales_last_30d !== null) {
        console.log(`     Sales (30d): ${row.sales_last_30d}`)
      }

      console.log(`     Flex: ${row.is_flex ? 'Yes' : 'No'}`)
      console.log(`     Consigned: ${row.is_consigned ? 'Yes' : 'No'}`)
    }

    console.log('')
  }
}

// ============================================================================
// Main Test Script
// ============================================================================

async function main() {
  console.log('================================================================================')
  console.log('Master Market Data Integration Test')
  console.log('================================================================================')
  console.log(`\n📋 Test Configuration:`)
  console.log(`  SKU: ${TEST_SKU}`)
  console.log(`  Alias Region: UK (region_id=${ALIAS_REGION_ID_UK})`)
  console.log(`  StockX Currency: USD`)
  console.log(`  Alias Currency: GBP`)

  // Check environment variables
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseKey) {
    console.error('\n❌ Missing environment variables:')
    console.error('   NEXT_PUBLIC_SUPABASE_URL:', supabaseUrl ? 'SET' : 'NOT SET')
    console.error('   SUPABASE_SERVICE_ROLE_KEY:', supabaseKey ? 'SET' : 'NOT SET')
    process.exit(1)
  }

  const supabase = createClient(supabaseUrl, supabaseKey)

  // ========================================================================
  // Step 1: Look up StockX product ID and Alias catalog ID
  // ========================================================================

  console.log('\n================================================================================')
  console.log('STEP 1: Look up product IDs for SKU:', TEST_SKU)
  console.log('================================================================================\n')

  // Look up StockX product ID from product_catalog
  const { data: catalogEntry, error: catalogError } = await supabase
    .from('product_catalog')
    .select('id, sku, stockx_product_id')
    .eq('sku', TEST_SKU)
    .single()

  if (catalogError || !catalogEntry) {
    console.error('❌ Product not found in catalog for SKU:', TEST_SKU)
    console.error('   Error:', catalogError?.message)
    console.error('\n💡 Make sure the product exists in product_catalog table')
    process.exit(1)
  }

  console.log('✅ Found product:')
  console.log('   Catalog ID:', catalogEntry.id)
  console.log('   SKU:', catalogEntry.sku)
  console.log('   StockX Product ID:', catalogEntry.stockx_product_id || 'NOT SET')

  // Look up Alias catalog ID from inventory_alias_links (via Inventory join)
  let aliasCatalogId: string | null = null
  const { data: aliasLink } = await supabase
    .from('inventory_alias_links')
    .select('alias_catalog_id, Inventory!inner(sku)')
    .eq('Inventory.sku', TEST_SKU)
    .limit(1)
    .single()

  if (aliasLink && aliasLink.alias_catalog_id) {
    aliasCatalogId = aliasLink.alias_catalog_id
    console.log('   Alias Catalog ID:', aliasCatalogId)
  } else {
    console.log('   Alias Catalog ID: NOT FOUND (no inventory linked)')
  }

  // ========================================================================
  // Step 2: Sync StockX Market Data (GBP, UK region)
  // ========================================================================

  if (catalogEntry.stockx_product_id) {
    console.log('\n================================================================================')
    console.log('STEP 2: Sync StockX Market Data → master_market_data (GBP, UK)')
    console.log('================================================================================\n')

    console.log('🔄 Syncing StockX data...')
    const stockxResult = await refreshStockxMarketData(
      undefined, // No user ID (uses client credentials)
      catalogEntry.stockx_product_id,
      'GBP' // Currency
    )

    if (stockxResult.success) {
      console.log('✅ StockX sync complete!')
      console.log('   Variants cached:', stockxResult.variantsCached)
      console.log('   Snapshots created:', stockxResult.snapshotsCreated)
      if (stockxResult.warning) {
        console.log('   ⚠️ Warning:', stockxResult.warning)
      }
    } else {
      console.error('❌ StockX sync failed:', stockxResult.error)
    }
  } else {
    console.log('\n⏭️  Skipping StockX sync (no stockx_product_id)')
  }

  // ========================================================================
  // Step 3: Sync Alias UK Market Data (GBP, UK region)
  // ========================================================================

  if (aliasCatalogId) {
    console.log('\n================================================================================')
    console.log('STEP 3: Sync Alias UK Market Data → master_market_data (GBP, UK)')
    console.log('================================================================================\n')

    console.log('🔄 Syncing Alias UK data...')
    const aliasClient = new AliasClient()
    const aliasResult = await syncAliasToMasterMarketData(
      aliasClient,
      aliasCatalogId,
      {
        sku: TEST_SKU,
        regionId: ALIAS_REGION_ID_UK, // UK region
        includeConsigned: true,
      }
    )

    if (aliasResult.success) {
      console.log('✅ Alias UK sync complete!')
      console.log('   Variants ingested:', aliasResult.variantsIngested)
      console.log('   Volume metrics updated:', aliasResult.volumeMetricsUpdated)
    } else {
      console.error('❌ Alias UK sync failed:', aliasResult.error)
    }
  } else {
    console.log('\n⏭️  Skipping Alias sync (no alias_catalog_id)')
  }

  // ========================================================================
  // Step 4: Query master_market_data to verify
  // ========================================================================

  console.log('\n================================================================================')
  console.log('STEP 4: Query master_market_data to Verify')
  console.log('================================================================================')

  // Query StockX data (USD, US)
  if (catalogEntry.stockx_product_id) {
    console.log('\n📊 Querying StockX data (USD, US)...')
    const { data: stockxRows, error: stockxQueryError } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('provider', 'stockx')
      .eq('sku', TEST_SKU)
      .eq('currency_code', 'USD')
      .order('size_numeric', { ascending: true })

    if (stockxQueryError) {
      console.error('❌ Query error:', stockxQueryError.message)
    } else {
      displayResults(stockxRows || [], 'StockX', 'US/USD')
    }
  }

  // Query Alias UK data (GBP, UK)
  if (aliasCatalogId) {
    console.log('\n📊 Querying Alias UK data (GBP, UK)...')
    const { data: aliasRows, error: aliasQueryError } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('provider', 'alias')
      .eq('sku', TEST_SKU)
      .eq('currency_code', 'GBP')
      .eq('region_code', 'UK')
      .order('size_numeric', { ascending: true })

    if (aliasQueryError) {
      console.error('❌ Query error:', aliasQueryError.message)
    } else {
      displayResults(aliasRows || [], 'Alias', 'UK/GBP')
    }
  }

  // ========================================================================
  // Step 5: Summary
  // ========================================================================

  console.log('\n================================================================================')
  console.log('Summary')
  console.log('================================================================================\n')

  // Count total rows for this SKU
  const { count: totalCount, error: countError } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('sku', TEST_SKU)

  if (!countError) {
    console.log('✅ Total master_market_data rows for SKU', TEST_SKU + ':', totalCount || 0)
  }

  // Count by provider
  const { data: providerCounts } = await supabase
    .from('master_market_data')
    .select('provider, currency_code, region_code')
    .eq('sku', TEST_SKU)

  if (providerCounts) {
    const grouped = providerCounts.reduce((acc, row) => {
      const key = `${row.provider}|${row.currency_code}|${row.region_code}`
      acc[key] = (acc[key] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    console.log('\n📊 Breakdown by provider:')
    for (const [key, count] of Object.entries(grouped)) {
      const [provider, currency, region] = key.split('|')
      console.log(`   ${provider} (${currency}, ${region}): ${count} rows`)
    }
  }

  console.log('\n🎉 Test complete!')
}

// ============================================================================
// Run
// ============================================================================

main().catch((error) => {
  console.error('\n❌ Fatal error:', error)
  process.exit(1)
})
