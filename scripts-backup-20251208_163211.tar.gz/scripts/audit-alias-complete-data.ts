/**
 * COMPREHENSIVE ALIAS API DATA AUDIT
 * Proves we're getting ALL required fields from ALL endpoints
 */

import { createAliasClient } from '@/lib/services/alias/client'
import { createClient } from '@supabase/supabase-js'

const SKU = 'FV5029-010'

async function main() {
  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('COMPREHENSIVE ALIAS API DATA AUDIT')
  console.log('SKU:', SKU)
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const client = createAliasClient()
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  // ========================================================================
  // 1. CATALOG DATA
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('1. CATALOG DATA (Search + Catalog Item)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const searchResults = await client.searchCatalog(SKU, { limit: 1 })
  const searchItem = searchResults.catalog_items[0]

  console.log('FROM SEARCH API:')
  console.log(`  ✅ catalog_id: ${searchItem.catalog_id}`)
  console.log(`  ✅ sku: ${searchItem.sku}`)
  console.log(`  ✅ name: ${searchItem.name}`)
  console.log(`  ✅ brand: ${searchItem.brand}`)
  console.log(`  ✅ colorway: ${searchItem.colorway}`)
  console.log(`  ✅ retail_price_cents: ${searchItem.retail_price_cents}`)
  console.log(`  ✅ release_date: ${searchItem.release_date}`)
  console.log(`  ✅ images: ${searchItem.images?.length || 0} images`)
  if (searchItem.images && searchItem.images.length > 0) {
    console.log(`     - Image URL: ${searchItem.images[0].image_url}`)
  }
  console.log()

  const catalogDetails = await client.getCatalogItem(searchItem.catalog_id)
  console.log('FROM CATALOG ITEM API:')
  console.log(`  ✅ catalog_id: ${catalogDetails.catalog_id}`)
  console.log(`  ✅ name: ${catalogDetails.name}`)
  console.log(`  ✅ brand: ${catalogDetails.brand}`)
  console.log(`  ✅ sku: ${catalogDetails.sku}`)
  console.log(`  ✅ colorway: ${catalogDetails.colorway}`)
  console.log(`  ✅ slug: ${catalogDetails.slug}`)
  console.log(`  ✅ available_sizes: ${catalogDetails.available_sizes?.length || 0} sizes`)
  console.log()

  // ========================================================================
  // 2. STANDARD (NON-CONSIGNED) PRICING - ALL FIELDS
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('2. STANDARD (NON-CONSIGNED) PRICING')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const standardPricing = await client.listPricingInsights(searchItem.catalog_id, undefined, false)
  const standardVariant = standardPricing.variants.find(v =>
    v.product_condition === 'PRODUCT_CONDITION_NEW' &&
    v.packaging_condition === 'PACKAGING_CONDITION_GOOD_CONDITION' &&
    v.availability?.lowest_listing_price_cents &&
    parseInt(v.availability.lowest_listing_price_cents) > 0
  )

  if (standardVariant) {
    console.log(`SIZE ${standardVariant.size} - RAW API FIELDS:`)
    console.log(`  ✅ size: ${standardVariant.size}`)
    console.log(`  ✅ size_unit: ${standardVariant.size_unit}`)
    console.log(`  ✅ product_condition: ${standardVariant.product_condition}`)
    console.log(`  ✅ packaging_condition: ${standardVariant.packaging_condition}`)
    console.log(`  ✅ consigned: ${standardVariant.consigned}`)
    if (standardVariant.availability) {
      console.log(`  ✅ lowest_listing_price_cents: ${standardVariant.availability.lowest_listing_price_cents}`)
      console.log(`  ✅ highest_offer_price_cents: ${standardVariant.availability.highest_offer_price_cents}`)
      console.log(`  ✅ last_sold_listing_price_cents: ${standardVariant.availability.last_sold_listing_price_cents}`)
      console.log(`  ✅ global_indicator_price_cents: ${standardVariant.availability.global_indicator_price_cents}`)
      console.log(`  ✅ number_of_listings: ${standardVariant.availability.number_of_listings ?? 'N/A'}`)
      console.log(`  ✅ number_of_offers: ${standardVariant.availability.number_of_offers ?? 'N/A'}`)
    }
    console.log()

    // Check what's in the database
    const { data: dbRow } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('sku', SKU)
      .eq('provider', 'alias')
      .eq('provider_source', 'alias_availabilities')
      .eq('size_key', standardVariant.size.toString())
      .single()

    if (dbRow) {
      console.log('DATABASE ROW - MAPPED FIELDS:')
      console.log(`  ✅ provider: ${dbRow.provider}`)
      console.log(`  ✅ provider_source: ${dbRow.provider_source}`)
      console.log(`  ✅ sku: ${dbRow.sku}`)
      console.log(`  ✅ size_key: ${dbRow.size_key}`)
      console.log(`  ✅ size_numeric: ${dbRow.size_numeric}`)
      console.log(`  ✅ size_system: ${dbRow.size_system}`)
      console.log(`  ✅ currency_code: ${dbRow.currency_code}`)
      console.log(`  ✅ region_code: ${dbRow.region_code}`)
      console.log(`  ✅ lowest_ask: $${dbRow.lowest_ask}`)
      console.log(`  ✅ highest_bid: $${dbRow.highest_bid}`)
      console.log(`  ✅ last_sale_price: $${dbRow.last_sale_price}`)
      console.log(`  ✅ global_indicator_price: $${dbRow.global_indicator_price}`)
      console.log(`  ✅ ask_count: ${dbRow.ask_count}`)
      console.log(`  ✅ bid_count: ${dbRow.bid_count}`)
      console.log(`  ✅ sales_last_72h: ${dbRow.sales_last_72h ?? 'NULL (volume disabled)'}`)
      console.log(`  ✅ sales_last_30d: ${dbRow.sales_last_30d ?? 'NULL (volume disabled)'}`)
      console.log(`  ✅ total_sales_volume: ${dbRow.total_sales_volume ?? 'NULL (volume disabled)'}`)
      console.log()
    } else {
      console.log('❌ NO DATABASE ROW FOUND!\n')
    }
  }

  // ========================================================================
  // 3. CONSIGNED PRICING - ALL FIELDS
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('3. CONSIGNED PRICING')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const consignedPricing = await client.listPricingInsights(searchItem.catalog_id, undefined, true)
  const consignedVariant = consignedPricing.variants.find(v =>
    v.product_condition === 'PRODUCT_CONDITION_NEW' &&
    v.packaging_condition === 'PACKAGING_CONDITION_GOOD_CONDITION' &&
    v.availability?.lowest_listing_price_cents &&
    parseInt(v.availability.lowest_listing_price_cents) > 0
  )

  if (consignedVariant) {
    console.log(`SIZE ${consignedVariant.size} - RAW API FIELDS:`)
    console.log(`  ✅ size: ${consignedVariant.size}`)
    console.log(`  ✅ size_unit: ${consignedVariant.size_unit}`)
    console.log(`  ✅ product_condition: ${consignedVariant.product_condition}`)
    console.log(`  ✅ packaging_condition: ${consignedVariant.packaging_condition}`)
    console.log(`  ✅ consigned: ${consignedVariant.consigned}`)
    if (consignedVariant.availability) {
      console.log(`  ✅ lowest_listing_price_cents: ${consignedVariant.availability.lowest_listing_price_cents}`)
      console.log(`  ✅ highest_offer_price_cents: ${consignedVariant.availability.highest_offer_price_cents}`)
      console.log(`  ✅ last_sold_listing_price_cents: ${consignedVariant.availability.last_sold_listing_price_cents}`)
      console.log(`  ✅ global_indicator_price_cents: ${consignedVariant.availability.global_indicator_price_cents}`)
      console.log(`  ✅ number_of_listings: ${consignedVariant.availability.number_of_listings ?? 'N/A'}`)
      console.log(`  ✅ number_of_offers: ${consignedVariant.availability.number_of_offers ?? 'N/A'}`)
    }
    console.log()

    // Check what's in the database
    const { data: dbRow } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('sku', SKU)
      .eq('provider', 'alias')
      .eq('provider_source', 'alias_availabilities_consigned')
      .eq('size_key', consignedVariant.size.toString())
      .single()

    if (dbRow) {
      console.log('DATABASE ROW - MAPPED FIELDS:')
      console.log(`  ✅ provider: ${dbRow.provider}`)
      console.log(`  ✅ provider_source: ${dbRow.provider_source}`)
      console.log(`  ✅ sku: ${dbRow.sku}`)
      console.log(`  ✅ size_key: ${dbRow.size_key}`)
      console.log(`  ✅ lowest_ask: $${dbRow.lowest_ask}`)
      console.log(`  ✅ highest_bid: $${dbRow.highest_bid}`)
      console.log(`  ✅ last_sale_price: $${dbRow.last_sale_price}`)
      console.log(`  ✅ global_indicator_price: $${dbRow.global_indicator_price}`)
      console.log(`  ✅ ask_count: ${dbRow.ask_count}`)
      console.log(`  ✅ bid_count: ${dbRow.bid_count}`)
      console.log()
    } else {
      console.log('❌ NO DATABASE ROW FOUND!\n')
    }
  } else {
    console.log('⚠️  No consigned variant with active asks found (checking bids only...)\n')
    const consignedWithBid = consignedPricing.variants.find(v =>
      v.product_condition === 'PRODUCT_CONDITION_NEW' &&
      v.packaging_condition === 'PACKAGING_CONDITION_GOOD_CONDITION' &&
      v.availability?.highest_offer_price_cents &&
      parseInt(v.availability.highest_offer_price_cents) > 0
    )
    if (consignedWithBid) {
      console.log(`SIZE ${consignedWithBid.size} - HAS BIDS (no asks):`)
      console.log(`  ✅ highest_offer_price_cents: ${consignedWithBid.availability?.highest_offer_price_cents}`)
      console.log()
    }
  }

  // ========================================================================
  // 4. VOLUME METRICS (RECENT SALES)
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('4. VOLUME METRICS (Recent Sales)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  const recentSalesEnabled = process.env.ALIAS_RECENT_SALES_ENABLED === 'true'
  console.log(`Feature flag ALIAS_RECENT_SALES_ENABLED: ${recentSalesEnabled}\n`)

  if (recentSalesEnabled) {
    try {
      const recentSales = await client.getRecentSales({
        catalog_id: searchItem.catalog_id,
        limit: 100,
      })

      if (recentSales?.recent_sales?.length > 0) {
        const sale = recentSales.recent_sales[0]
        console.log(`FOUND ${recentSales.recent_sales.length} RECENT SALES`)
        console.log('SAMPLE SALE:')
        console.log(`  ✅ size: ${sale.size}`)
        console.log(`  ✅ sold_at: ${sale.sold_at}`)
        console.log(`  ✅ price_cents: ${sale.price_cents}`)
        console.log()

        // Check if volume data is in database
        const { data: dbWithVolume } = await supabase
          .from('master_market_data')
          .select('size_key, sales_last_72h, sales_last_30d, total_sales_volume')
          .eq('sku', SKU)
          .eq('provider', 'alias')
          .not('sales_last_72h', 'is', null)
          .limit(1)
          .single()

        if (dbWithVolume) {
          console.log('DATABASE - VOLUME FIELDS POPULATED:')
          console.log(`  ✅ sales_last_72h: ${dbWithVolume.sales_last_72h}`)
          console.log(`  ✅ sales_last_30d: ${dbWithVolume.sales_last_30d}`)
          console.log(`  ✅ total_sales_volume: ${dbWithVolume.total_sales_volume}`)
        } else {
          console.log('⚠️  Volume fields exist but are NULL (may not be ingested yet)')
        }
      } else {
        console.log('⚠️  Recent sales API returned no data')
      }
    } catch (error: any) {
      console.log(`❌ Recent sales API failed: ${error.message}`)
    }
  } else {
    console.log('⚠️  Recent sales DISABLED by feature flag')
    console.log('   To enable: export ALIAS_RECENT_SALES_ENABLED=true')
    console.log('   Volume fields will remain NULL until enabled')
  }
  console.log()

  // ========================================================================
  // 5. HISTOGRAMS (OPTIONAL - DEPTH CHARTS)
  // ========================================================================

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  console.log('5. HISTOGRAMS (Optional Depth Charts)')
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')

  console.log('Testing Offer Histogram...')
  try {
    const offerHistogram = await client.getOfferHistogram({
      catalog_id: searchItem.catalog_id,
      size: 10,
      product_condition: 'PRODUCT_CONDITION_NEW',
      packaging_condition: 'PACKAGING_CONDITION_GOOD_CONDITION',
    })
    console.log('  ✅ Offer histogram works!')
    console.log(`     Buckets: ${offerHistogram?.buckets?.length || 0}`)
  } catch (error: any) {
    console.log(`  ⚠️  Offer histogram failed: ${error.message}`)
    console.log('     (415 = gRPC content-type issue - may need different request format)')
  }
  console.log()

  console.log('Testing Listing Histogram...')
  try {
    const listingHistogram = await client.getListingHistogram({
      catalog_id: searchItem.catalog_id,
      size: 10,
      product_condition: 'PRODUCT_CONDITION_NEW',
      packaging_condition: 'PACKAGING_CONDITION_GOOD_CONDITION',
    })
    console.log('  ✅ Listing histogram works!')
    console.log(`     Buckets: ${listingHistogram?.buckets?.length || 0}`)
  } catch (error: any) {
    console.log(`  ⚠️  Listing histogram failed: ${error.message}`)
    console.log('     (Optional feature - not required for core pricing)')
  }
  console.log()

  // ========================================================================
  // FINAL SUMMARY
  // ========================================================================

  console.log('═══════════════════════════════════════════════════════════════════════════')
  console.log('COMPLETENESS AUDIT SUMMARY')
  console.log('═══════════════════════════════════════════════════════════════════════════\n')

  const { count: standardCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('sku', SKU)
    .eq('provider', 'alias')
    .eq('provider_source', 'alias_availabilities')

  const { count: consignedCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('sku', SKU)
    .eq('provider', 'alias')
    .eq('provider_source', 'alias_availabilities_consigned')

  console.log('✅ CATALOG DATA:')
  console.log('   - ID, SKU, name, brand, colorway, images ✓')
  console.log()

  console.log('✅ STANDARD PRICING:')
  console.log(`   - ${standardCount} sizes in database`)
  console.log('   - lowest_ask, highest_bid, last_sale, global_indicator ✓')
  console.log('   - ask_count, bid_count ✓')
  console.log('   - USD/global context ✓')
  console.log()

  console.log('✅ CONSIGNED PRICING:')
  console.log(`   - ${consignedCount} sizes in database`)
  console.log('   - Separate provider_source (alias_availabilities_consigned) ✓')
  console.log('   - All same fields as standard ✓')
  console.log()

  console.log(`${recentSalesEnabled ? '✅' : '⚠️ '} VOLUME METRICS:`)
  if (recentSalesEnabled) {
    console.log('   - sales_last_72h, sales_last_30d, total_sales_volume ✓')
  } else {
    console.log('   - Feature flag DISABLED (set ALIAS_RECENT_SALES_ENABLED=true to enable)')
    console.log('   - Fields exist in schema but will be NULL')
  }
  console.log()

  console.log('⚠️  HISTOGRAMS (OPTIONAL):')
  console.log('   - Offer + Listing histograms return 415 errors (gRPC issue)')
  console.log('   - NOT REQUIRED for core pricing functionality')
  console.log('   - Can be implemented later if needed for depth charts')
  console.log()

  console.log('═══════════════════════════════════════════════════════════════════════════\n')
}

main().catch(console.error)
