#!/usr/bin/env npx tsx
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

async function showState() {
  console.log('═══════════════════════════════════════════════════════════');
  console.log('ACTUAL DATABASE STATE - master_market_data');
  console.log('═══════════════════════════════════════════════════════════\n');

  // Get ALL data grouped by provider
  const { data: allData } = await supabase
    .from('master_market_data')
    .select('provider, sku, region_code, created_at')
    .order('created_at', { ascending: false });

  if (!allData || allData.length === 0) {
    console.log('❌ NO DATA IN TABLE\n');
    return;
  }

  // Group by provider
  const byProvider = new Map<string, any[]>();
  allData.forEach(row => {
    if (!byProvider.has(row.provider)) {
      byProvider.set(row.provider, []);
    }
    byProvider.get(row.provider)!.push(row);
  });

  console.log(`Total rows in master_market_data: ${allData.length}\n`);

  // Show breakdown by provider
  for (const [provider, rows] of byProvider) {
    const uniqueSkus = new Set(rows.map(r => r.sku));
    const regions = new Set(rows.map(r => r.region_code));

    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`PROVIDER: ${provider.toUpperCase()}`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`Total rows: ${rows.length}`);
    console.log(`Unique products: ${uniqueSkus.size}`);
    console.log(`Regions: ${Array.from(regions).join(', ')}`);

    // Show oldest and newest
    const oldest = rows[rows.length - 1];
    const newest = rows[0];
    console.log(`\nOldest record: ${oldest.created_at}`);
    console.log(`Newest record: ${newest.created_at}`);

    // Show first 10 unique SKUs
    console.log(`\nProducts (first 10):`);
    Array.from(uniqueSkus).slice(0, 10).forEach(sku => {
      const skuRows = rows.filter(r => r.sku === sku);
      const skuRegions = new Set(skuRows.map(r => r.region_code));
      console.log(`  ${sku} - ${skuRows.length} rows - regions: ${Array.from(skuRegions).join(',')}`);
    });
    console.log('');
  }

  // Check if StockX data exists
  const stockxData = allData.filter(r => r.provider === 'stockx');
  if (stockxData.length === 0) {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('⚠️  NO STOCKX DATA IN DATABASE');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  }

  // Show what the user can query to verify
  console.log('═══════════════════════════════════════════════════════════');
  console.log('HOW TO VERIFY YOURSELF');
  console.log('═══════════════════════════════════════════════════════════');
  console.log('Run this in Supabase SQL editor:');
  console.log('');
  console.log('SELECT');
  console.log('  provider,');
  console.log('  COUNT(*) as total_rows,');
  console.log('  COUNT(DISTINCT sku) as unique_products,');
  console.log('  MIN(created_at) as oldest,');
  console.log('  MAX(created_at) as newest');
  console.log('FROM master_market_data');
  console.log('GROUP BY provider;');
  console.log('');
}

showState();
