#!/usr/bin/env npx tsx
/**
 * Test Alias Content-Type Fix
 */

import { createAliasClient } from '@/lib/services/alias/client'

async function main() {
  console.log('🧪 Testing Alias Content-Type Fix\n')

  const client = createAliasClient()

  try {
    console.log('1. Testing /regions endpoint...')
    const regions = await client.listRegions()
    console.log(`  ✅ SUCCESS - Found ${regions.regions.length} regions`)

    console.log('\n2. Testing pricing insights...')
    const catalogId = '2002r-protection-pack-phantom-m2002rdb'
    const regionId = regions.regions[0].id

    const pricing = await client.listPricingInsights({
      catalog_id: catalogId,
      region_id: regionId
    })
    console.log(`  ✅ SUCCESS - Found pricing data for ${pricing.variants.length} variants`)

    console.log('\n✅ ALIAS FIX VERIFIED - All endpoints working!')
  } catch (error: any) {
    console.error('\n❌ ALIAS STILL BROKEN:', error.message)
    if (error.statusCode) {
      console.log(`   Status: ${error.statusCode}`)
    }
  }
}

main().catch(console.error)
