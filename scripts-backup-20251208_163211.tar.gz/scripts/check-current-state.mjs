#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function check() {
  console.log('🔍 CHECKING ACTUAL CURRENT STATE\n');
  console.log('='.repeat(80));

  const { data: rows } = await supabase
    .from('master_market_data')
    .select('provider, sku, size_key, currency_code, lowest_ask, highest_bid, sales_last_30d, is_flex, is_consigned, snapshot_at')
    .order('snapshot_at', { ascending: false })
    .limit(10);

  console.log('\n📊 LATEST 10 ROWS:\n');
  rows?.forEach(row => {
    console.log(
      row.provider.padEnd(8),
      (row.sku || 'NULL').padEnd(12),
      (row.size_key || 'NULL').padEnd(6),
      (row.currency_code || 'NULL').padEnd(4),
      'Ask:', (row.lowest_ask || 'NULL').toString().padStart(7),
      'Bid:', (row.highest_bid || 'NULL').toString().padStart(7),
      'Sales:', (row.sales_last_30d || 'NULL').toString().padStart(3),
      new Date(row.snapshot_at).toISOString().split('T')[0]
    );
  });

  const { data: all } = await supabase
    .from('master_market_data')
    .select('provider, snapshot_at');

  console.log('\n' + '='.repeat(80));
  console.log('\n📈 PROVIDER BREAKDOWN:\n');
  const providerCounts = {};
  const latestByProvider = {};

  all?.forEach(row => {
    providerCounts[row.provider] = (providerCounts[row.provider] || 0) + 1;
    if (!latestByProvider[row.provider] || new Date(row.snapshot_at) > new Date(latestByProvider[row.provider])) {
      latestByProvider[row.provider] = row.snapshot_at;
    }
  });

  for (const [provider, count] of Object.entries(providerCounts)) {
    const latest = latestByProvider[provider];
    const daysAgo = Math.floor((Date.now() - new Date(latest).getTime()) / (1000 * 60 * 60 * 24));
    console.log(provider.padEnd(10), count.toString().padStart(4), 'rows  | Last sync:', daysAgo, 'days ago');
  }

  console.log('\n' + '='.repeat(80));
}

check().catch(console.error);
