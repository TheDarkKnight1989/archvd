/**
 * Test Script: eBay → Master Market Data Integration
 *
 * Tests the full pipeline:
 * 1. Search eBay for authenticated NEW sneakers (sold items)
 * 2. Ingest into master_market_data with SKU/size extraction
 * 3. Query master_market_data to verify data
 *
 * Usage:
 *   npx tsx scripts/test-ebay-to-master-market.ts
 *
 * Prerequisites:
 *   - EBAY_MARKET_DATA_ENABLED=true in .env.local
 *   - EBAY_CLIENT_ID and EBAY_CLIENT_SECRET configured
 *   - NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY configured
 */

import { syncEbaySneakersForQuery } from '@/lib/services/ebay/sync'
import { ebayConfig } from '@/lib/services/ebay/config'
import { createClient } from '@supabase/supabase-js'

async function main() {
  console.log('='.repeat(80))
  console.log('eBay → Master Market Data Integration Test')
  console.log('='.repeat(80))

  // Check config
  console.log('\n📋 Configuration:')
  console.log('  Environment:', ebayConfig.env)
  console.log('  Market Data Enabled:', ebayConfig.marketDataEnabled)
  console.log(
    '  Client ID:',
    ebayConfig.clientId ? `${ebayConfig.clientId.slice(0, 10)}...` : 'NOT SET'
  )
  console.log('  Client Secret:', ebayConfig.clientSecret ? 'SET' : 'NOT SET')

  if (!ebayConfig.marketDataEnabled) {
    console.error('\n❌ EBAY_MARKET_DATA_ENABLED is not true')
    console.error('   Set EBAY_MARKET_DATA_ENABLED=true in .env.local')
    process.exit(1)
  }

  if (!ebayConfig.clientId || !ebayConfig.clientSecret) {
    console.error('\n❌ Missing eBay credentials')
    console.error('   Set EBAY_CLIENT_ID and EBAY_CLIENT_SECRET in .env.local')
    process.exit(1)
  }

  // Test queries - use real SKUs for best results
  const testQueries = [
    { query: 'DD1391-100', description: 'Jordan 4 Black Cat (by SKU)' },
    { query: 'Jordan 4 Black Cat', description: 'Jordan 4 Black Cat (by name)' },
  ]

  console.log('\n' + '='.repeat(80))
  console.log('STEP 1: Sync eBay Data → master_market_data')
  console.log('='.repeat(80))

  for (const test of testQueries) {
    console.log(`\n🔄 Syncing: ${test.description}`)
    console.log(`   Query: "${test.query}"`)

    try {
      const result = await syncEbaySneakersForQuery(test.query, {
        currency: 'GBP',
        limit: 20, // Fewer items for testing
      })

      if (result.success) {
        console.log(`   ✅ Success!`)
        console.log(`      Items fetched: ${result.itemsCount}`)
        console.log(`      Currency: ${result.currency}`)
      } else {
        console.log(`   ❌ Failed: ${result.error}`)
      }
    } catch (error) {
      console.error(`   ❌ Error:`, error)
    }

    // Small delay between requests
    await new Promise((resolve) => setTimeout(resolve, 1000))
  }

  console.log('\n' + '='.repeat(80))
  console.log('STEP 2: Query master_market_data to Verify')
  console.log('='.repeat(80))

  // Query the database
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const { data, error } = await supabase
    .from('master_market_data')
    .select(
      `
      provider,
      sku,
      size_key,
      size_numeric,
      currency_code,
      last_sale_price,
      lowest_ask,
      snapshot_at,
      raw_response_excerpt
    `
    )
    .eq('provider', 'ebay')
    .order('snapshot_at', { ascending: false })
    .limit(10)

  if (error) {
    console.error('\n❌ Database query failed:', error)

    if (error.message?.includes('master_market_data')) {
      console.error('\n⚠️  The master_market_data table does not exist yet!')
      console.error('\n📋 To fix this, apply the migration:')
      console.error('   1. Go to Supabase Dashboard → SQL Editor')
      console.error('   2. Run: supabase/migrations/20251203_create_master_market_data.sql')
      console.error('\n   OR use the migration script:')
      console.error('   node scripts/apply-master-market-migrations.mjs')
    }

    process.exit(1)
  }

  if (!data || data.length === 0) {
    console.log('\n⚠️  No eBay data found in master_market_data')
    console.log('   This might mean:')
    console.log('   - No items matched the currency filter')
    console.log('   - SKU extraction failed for all items')
    console.log('   - eBay API returned no results')
  } else {
    console.log(`\n✅ Found ${data.length} eBay rows in master_market_data:\n`)

    // Group by SKU for better display
    const bySku = new Map<string, typeof data>()
    for (const row of data) {
      if (!bySku.has(row.sku)) {
        bySku.set(row.sku, [])
      }
      bySku.get(row.sku)!.push(row)
    }

    for (const [sku, rows] of bySku.entries()) {
      console.log(`📦 SKU: ${sku}`)
      console.log(`   Currency: ${rows[0].currency_code}`)
      console.log(`   Sizes found: ${rows.length}`)

      // Show first 3 sizes
      rows.slice(0, 3).forEach((row) => {
        console.log(`   • Size ${row.size_key}:`)
        console.log(
          `     Price: ${row.currency_code} ${row.last_sale_price || row.lowest_ask}`
        )
        console.log(`     Type: ${row.last_sale_price ? 'Sold' : 'Active Listing'}`)
        if (row.raw_response_excerpt) {
          console.log(`     Title: ${row.raw_response_excerpt.title?.substring(0, 60)}...`)
        }
      })

      if (rows.length > 3) {
        console.log(`   ... and ${rows.length - 3} more sizes`)
      }
      console.log('')
    }
  }

  console.log('='.repeat(80))
  console.log('✅ Test Complete!')
  console.log('='.repeat(80))

  console.log('\n📊 Sample SQL Query:')
  console.log(`
SELECT
  sku,
  size_key,
  currency_code,
  last_sale_price,
  snapshot_at
FROM master_market_data
WHERE provider = 'ebay'
ORDER BY sku, size_numeric;
  `)

  console.log('\n🎯 Next Steps:')
  console.log('  1. Verify the data looks correct (SKUs, sizes, prices)')
  console.log('  2. Compare eBay prices with StockX/Alias for same SKU')
  console.log('  3. If successful, consider adding more test queries')
  console.log('  4. Eventually: wire into automatic sync flows (Phase 2)')
}

main().catch((error) => {
  console.error('Fatal error:', error)
  process.exit(1)
})
