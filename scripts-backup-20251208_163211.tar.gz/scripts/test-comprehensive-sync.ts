#!/usr/bin/env npx tsx
/**
 * Test Comprehensive Sync - Verify all market data is being pulled
 */

import { createClient } from '@supabase/supabase-js'
import { AliasClient } from '../src/lib/services/alias/client'
import { syncAliasProductMultiRegion } from '../src/lib/services/alias/sync'
import { syncProductAllRegions } from '../src/lib/services/stockx/market-refresh'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🔄 Testing Comprehensive Market Data Sync\n')

  // Get a test product (Jordan 1 Panda)
  const { data: product } = await supabase
    .from('products')
    .select(`
      id,
      sku,
      brand,
      model,
      product_variants (
        id,
        size_key,
        alias_catalog_id,
        stockx_product_id
      )
    `)
    .eq('sku', 'DD1503-103')
    .single()

  if (!product) {
    console.error('Test product not found')
    return
  }

  console.log(`Testing with: ${product.sku} - ${product.brand} ${product.model}`)

  const aliasVariant = product.product_variants.find((v: any) => v.alias_catalog_id)
  const stockxVariant = product.product_variants.find((v: any) => v.stockx_product_id)

  console.log(`\nAlias catalog ID: ${aliasVariant?.alias_catalog_id}`)
  console.log(`StockX product ID: ${stockxVariant?.stockx_product_id}\n`)

  // ========================================================================
  // TEST 1: Alias Comprehensive Sync
  // ========================================================================
  console.log('='.repeat(80))
  console.log('📍 TEST 1: Alias Multi-Region Sync')
  console.log('='.repeat(80))

  if (aliasVariant?.alias_catalog_id) {
    const aliasClient = new AliasClient(undefined)

    try {
      const result = await syncAliasProductMultiRegion(
        aliasClient,
        aliasVariant.alias_catalog_id,
        {
          sku: product.sku,
          userRegion: 'UK',
          syncSecondaryRegions: true, // Sync US, UK, EU, global
        }
      )

      console.log(`\n✅ Alias sync ${result.success ? 'succeeded' : 'failed'}`)
      console.log(`   Primary region: ${result.primaryResult.region}`)
      console.log(`   Variants ingested: ${result.totalVariantsIngested}`)
      console.log(`   Secondary regions synced: ${result.secondaryResults?.length || 0}`)

      // Check what data was inserted
      const { data: masterData, count } = await supabase
        .from('master_market_data')
        .select('*', { count: 'exact' })
        .eq('provider', 'alias')
        .eq('sku', product.sku)
        .order('snapshot_at', { ascending: false })
        .limit(10)

      console.log(`\n   Records in master_market_data: ${count}`)
      if (masterData && masterData.length > 0) {
        console.log(`   Sample record (latest):`)
        const sample = masterData[0]
        console.log(`     Region: ${sample.region_code}`)
        console.log(`     Size: ${sample.size_key} (${sample.size_numeric})`)
        console.log(`     Lowest Ask: ${sample.lowest_ask}`)
        console.log(`     Highest Bid: ${sample.highest_bid}`)
        console.log(`     Last Sale: ${sample.last_sale_price}`)
        console.log(`     Global Indicator: ${sample.global_indicator_price}`)
        console.log(`     Ask Count: ${sample.ask_count}`)
        console.log(`     Bid Count: ${sample.bid_count}`)
        console.log(`     Is Consigned: ${sample.is_consigned}`)
      }

      // Check histograms
      const { count: histogramCount } = await supabase
        .from('alias_offer_histograms')
        .select('*', { count: 'exact', head: true })
        .eq('sku', product.sku)

      console.log(`\n   Histogram records: ${histogramCount || 0}`)

      // Check recent sales
      const { count: salesCount } = await supabase
        .from('alias_recent_sales')
        .select('*', { count: 'exact', head: true })
        .eq('sku', product.sku)

      console.log(`   Recent sales records: ${salesCount || 0}`)

    } catch (error: any) {
      console.error(`❌ Alias sync failed: ${error.message}`)
    }
  } else {
    console.log('⏭️  No Alias mapping')
  }

  // ========================================================================
  // TEST 2: StockX Comprehensive Sync
  // ========================================================================
  console.log('\n' + '='.repeat(80))
  console.log('🟢 TEST 2: StockX Multi-Region Sync')
  console.log('='.repeat(80))

  if (stockxVariant?.stockx_product_id) {
    try {
      const result = await syncProductAllRegions(
        undefined, // No user (app-level auth)
        stockxVariant.stockx_product_id,
        'UK',
        true // Sync all regions
      )

      console.log(`\n✅ StockX sync ${result.success ? 'succeeded' : 'failed'}`)
      console.log(`   Primary region: ${result.primaryResult.region}`)
      console.log(`   Snapshots created: ${result.totalSnapshotsCreated}`)
      console.log(`   Secondary regions synced: ${result.secondaryResults?.length || 0}`)

      // Check what data was inserted
      const { data: masterData, count } = await supabase
        .from('master_market_data')
        .select('*', { count: 'exact' })
        .eq('provider', 'stockx')
        .eq('sku', product.sku)
        .order('snapshot_at', { ascending: false })
        .limit(10)

      console.log(`\n   Records in master_market_data: ${count}`)
      if (masterData && masterData.length > 0) {
        // Find standard, flex, and consigned rows
        const standard = masterData.find(r => !r.is_flex && !r.is_consigned)
        const flex = masterData.find(r => r.is_flex)
        const consigned = masterData.find(r => r.is_consigned)

        if (standard) {
          console.log(`   Standard pricing (sample):`)
          console.log(`     Region: ${standard.region_code}`)
          console.log(`     Size: ${standard.size_key}`)
          console.log(`     Lowest Ask: ${standard.lowest_ask}`)
          console.log(`     Highest Bid: ${standard.highest_bid}`)
          console.log(`     Last Sale: ${standard.last_sale_price}`)
          console.log(`     Sell Faster: ${standard.sell_faster_price}`)
          console.log(`     Earn More: ${standard.earn_more_price}`)
          console.log(`     Beat US: ${standard.beat_us_price}`)
        }

        if (flex) {
          console.log(`\n   Flex pricing available: ✅`)
          console.log(`     Flex Lowest Ask: ${flex.lowest_ask}`)
          console.log(`     Flex Highest Bid: ${flex.highest_bid}`)
        }

        if (consigned) {
          console.log(`\n   Consigned pricing available: ✅`)
        }
      }

    } catch (error: any) {
      console.error(`❌ StockX sync failed: ${error.message}`)
    }
  } else {
    console.log('⏭️  No StockX mapping')
  }

  // ========================================================================
  // FINAL SUMMARY
  // ========================================================================
  console.log('\n' + '='.repeat(80))
  console.log('📊 COMPREHENSIVE DATA SUMMARY')
  console.log('='.repeat(80))

  const { count: totalRecords } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('sku', product.sku)

  const { count: aliasRecords } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('sku', product.sku)
    .eq('provider', 'alias')

  const { count: stockxRecords } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('sku', product.sku)
    .eq('provider', 'stockx')

  console.log(`\nTotal market data records for ${product.sku}: ${totalRecords}`)
  console.log(`  Alias: ${aliasRecords}`)
  console.log(`  StockX: ${stockxRecords}`)

  console.log('\n✅ Comprehensive sync test complete!')
  console.log('\nData being pulled:')
  console.log('  📍 Alias: Multi-region pricing (US, UK, EU, global) + histograms + recent sales')
  console.log('  🟢 StockX: Multi-currency pricing (USD, GBP, EUR) + flex + suggestions + consigned')
  console.log('')
}

main().catch(console.error)
