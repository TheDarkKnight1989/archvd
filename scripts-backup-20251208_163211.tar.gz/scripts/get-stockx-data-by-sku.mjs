#!/usr/bin/env node
/**
 * Get StockX Market Data by SKU
 *
 * Searches StockX API directly for the SKU and shows all market data
 */

const SKU = 'II1493-600';
const CURRENCY = 'GBP';

async function getStockXData() {
  console.log('================================================================================');
  console.log('STOCKX API - DIRECT SKU SEARCH');
  console.log('================================================================================');
  console.log('SKU:', SKU);
  console.log('Currency:', CURRENCY);
  console.log('================================================================================\n');

  // Import StockX catalog service
  const { StockxCatalogService } = await import('../src/lib/services/stockx/catalog.ts');

  const catalogService = new StockxCatalogService(undefined);

  // ========================================================================
  // Step 1: Search for the SKU on StockX
  // ========================================================================

  console.log('🔍 Searching StockX for SKU:', SKU);
  console.log('─'.repeat(80) + '\n');

  let searchResults;
  try {
    searchResults = await catalogService.searchProducts(SKU);
  } catch (error) {
    console.error('❌ Search failed:', error.message);
    process.exit(1);
  }

  if (!searchResults || searchResults.length === 0) {
    console.log('❌ No results found for SKU:', SKU);
    console.log('\nTried searching StockX catalog but no matches.');
    process.exit(1);
  }

  console.log(`✅ Found ${searchResults.length} result(s):\n`);

  searchResults.forEach((product, i) => {
    console.log(`${i + 1}. ${product.productName}`);
    console.log(`   Product ID: ${product.productId}`);
    console.log(`   Style ID: ${product.styleId || 'N/A'}`);
    console.log(`   Brand: ${product.brand || 'N/A'}`);
    console.log('');
  });

  // Use the first result
  const product = searchResults[0];
  const stockxProductId = product.productId;

  console.log('Using first result:', product.productName);
  console.log('Product ID:', stockxProductId);
  console.log('\n' + '='.repeat(80) + '\n');

  // ========================================================================
  // Step 2: Fetch Variants (to get size labels)
  // ========================================================================

  console.log('🔄 Fetching variants...\n');

  let variants;
  try {
    variants = await catalogService.getProductVariants(stockxProductId);
  } catch (error) {
    console.error('❌ Failed to fetch variants:', error.message);
    process.exit(1);
  }

  const sizeMap = {};
  variants.forEach(v => {
    sizeMap[v.variantId] = {
      size: v.variantName,
      value: v.variantValue,
    };
  });

  console.log(`✅ Found ${variants.length} sizes\n`);

  // ========================================================================
  // Step 3: Fetch Market Data
  // ========================================================================

  console.log('🔄 Fetching market data...\n');

  const client = catalogService.client;
  let marketData;
  try {
    marketData = await client.request(
      `/v2/catalog/products/${stockxProductId}/market-data?currencyCode=${CURRENCY}`
    );
  } catch (error) {
    console.error('❌ Failed to fetch market data:', error.message);
    process.exit(1);
  }

  const marketVariants = Array.isArray(marketData) ? marketData : marketData?.variants || [];

  console.log(`✅ Found market data for ${marketVariants.length} sizes\n`);
  console.log('================================================================================');
  console.log('SIZE-BY-SIZE BREAKDOWN');
  console.log('================================================================================\n');

  // ========================================================================
  // Step 4: Display Size-by-Size Breakdown
  // ========================================================================

  const sortedData = marketVariants
    .map(v => ({
      ...v,
      sizeInfo: sizeMap[v.variantId] || { size: 'Unknown', value: '0' },
    }))
    .sort((a, b) => {
      const aVal = parseFloat(a.sizeInfo.value) || 0;
      const bVal = parseFloat(b.sizeInfo.value) || 0;
      return aVal - bVal;
    });

  for (const variant of sortedData) {
    const size = variant.sizeInfo.size;

    console.log(`📏 SIZE: ${size}`);
    console.log('─'.repeat(80));

    console.log('\n  💰 PRIMARY PRICING:');
    console.log(`     Lowest Ask:          £${variant.lowestAskAmount || 'N/A'}`);
    console.log(`     Highest Bid:         £${variant.highestBidAmount || 'N/A'}`);
    console.log(`     Flex Lowest Ask:     ${variant.flexLowestAskAmount ? '£' + variant.flexLowestAskAmount : 'NOT AVAILABLE'}`);
    console.log(`     Sell Faster:         £${variant.sellFasterAmount || 'N/A'}`);
    console.log(`     Earn More:           £${variant.earnMoreAmount || 'N/A'}`);

    if (variant.standardMarketData) {
      console.log('\n  📊 STANDARD MARKET DATA:');
      console.log(`     Lowest Ask:          £${variant.standardMarketData.lowestAsk || 'N/A'}`);
      console.log(`     Highest Bid:         £${variant.standardMarketData.highestBidAmount || 'N/A'}`);
      console.log(`     Sell Faster:         £${variant.standardMarketData.sellFaster || 'N/A'}`);
      console.log(`     Earn More:           £${variant.standardMarketData.earnMore || 'N/A'}`);
      console.log(`     Beat US:             ${variant.standardMarketData.beatUS ? '£' + variant.standardMarketData.beatUS : 'N/A'}`);
    }

    if (variant.flexMarketData) {
      console.log('\n  ⚡ FLEX MARKET DATA:');
      console.log(`     Lowest Ask:          ${variant.flexMarketData.lowestAsk ? '£' + variant.flexMarketData.lowestAsk : 'NOT AVAILABLE'}`);
      console.log(`     Highest Bid:         £${variant.flexMarketData.highestBidAmount || 'N/A'}`);
      console.log(`     Sell Faster:         £${variant.flexMarketData.sellFaster || 'N/A'}`);
      console.log(`     Earn More:           £${variant.flexMarketData.earnMore || 'N/A'}`);
      console.log(`     Beat US:             ${variant.flexMarketData.beatUS ? '£' + variant.flexMarketData.beatUS : 'N/A'}`);
    }

    if (variant.directMarketData) {
      console.log('\n  🎯 DIRECT MARKET DATA (Consignment):');
      console.log(`     Lowest Ask:          ${variant.directMarketData.lowestAsk ? '£' + variant.directMarketData.lowestAsk : 'NOT AVAILABLE'}`);
      console.log(`     Highest Bid:         £${variant.directMarketData.highestBidAmount || 'N/A'}`);
      console.log(`     Sell Faster:         £${variant.directMarketData.sellFaster || 'N/A'}`);
      console.log(`     Earn More:           £${variant.directMarketData.earnMore || 'N/A'}`);
      console.log(`     Beat US:             ${variant.directMarketData.beatUS ? '£' + variant.directMarketData.beatUS : 'N/A'}`);
    }

    console.log('\n' + '='.repeat(80) + '\n');
  }

  // Summary
  console.log('\n📊 SUMMARY:');
  console.log('─'.repeat(80));
  console.log(`Total sizes: ${sortedData.length}`);

  const withFlex = sortedData.filter(v => v.flexLowestAskAmount !== null).length;
  console.log(`Sizes with Flex pricing: ${withFlex}`);
  console.log(`Sizes without Flex pricing: ${sortedData.length - withFlex}`);

  const avgAsk = sortedData.reduce((sum, v) => sum + parseFloat(v.lowestAskAmount || 0), 0) / sortedData.length;
  const avgBid = sortedData.reduce((sum, v) => sum + parseFloat(v.highestBidAmount || 0), 0) / sortedData.length;

  console.log(`Average Lowest Ask: £${avgAsk.toFixed(2)}`);
  console.log(`Average Highest Bid: £${avgBid.toFixed(2)}`);
  console.log(`Average Spread: £${(avgAsk - avgBid).toFixed(2)}`);

  console.log('\n' + '='.repeat(80));
}

getStockXData().catch(err => {
  console.error('\n❌ FATAL ERROR:', err.message);
  console.error(err.stack);
  process.exit(1);
});
