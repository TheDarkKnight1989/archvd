#!/usr/bin/env npx tsx
/**
 * Test Inngest Sync
 * Triggers sync for all products and monitors progress
 */

import { createClient } from '@supabase/supabase-js'
import { inngest } from '@/lib/inngest/client'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🚀 Testing Inngest Sync\n')

  // Check how many products we have
  const { data: products, error } = await supabase
    .from('products')
    .select(
      `
      id,
      sku,
      product_variants!inner (
        alias_catalog_id,
        stockx_product_id
      )
    `
    )
    .or('product_variants.alias_catalog_id.not.is.null,product_variants.stockx_product_id.not.is.null')

  if (error || !products) {
    console.error('❌ Failed to fetch products:', error?.message)
    return
  }

  console.log(`Found ${products.length} products to sync\n`)

  // Trigger sync via Inngest
  console.log('Triggering sync via Inngest...\n')

  try {
    await inngest.send({
      name: 'products/sync-all',
      data: {
        timestamp: new Date().toISOString(),
      },
    })

    console.log('✅ Sync triggered successfully!\n')
    console.log('📊 Inngest will now:')
    console.log('  1. Process max 10 products concurrently')
    console.log('  2. Auto-retry failures (3 attempts)')
    console.log('  3. Continue until all products synced')
    console.log('')
    console.log('🔍 Monitor progress at: http://localhost:8288')
    console.log('   (Run: npx inngest-cli@latest dev)')
    console.log('')
    console.log('📈 Check results in master_market_data table')
  } catch (error: any) {
    console.error('❌ Failed to trigger sync:', error.message)
    console.log('\n⚠️  Make sure:')
    console.log('  1. Dev server is running: npm run dev')
    console.log('  2. Inngest Dev Server is running: npx inngest-cli@latest dev')
  }
}

main().catch(console.error)
