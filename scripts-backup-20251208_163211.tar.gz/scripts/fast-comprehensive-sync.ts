#!/usr/bin/env npx tsx
/**
 * Comprehensive Sync with API Timeout Protection
 *
 * Strategy:
 * - Sequential processing (1 product at a time) - StockX API can't handle parallel load
 * - Conservative delays: 5s between products, 2s between regions
 * - Full data quality verification
 * - Retry logic with exponential backoff
 * - Estimated time: ~60-75 minutes for 125 products
 */

import { createClient } from '@supabase/supabase-js'
import { syncProductAllRegions } from '@/lib/services/stockx/market-refresh'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const DELAY_BETWEEN_PRODUCTS = 1000 // 1 second - function has internal 3s of region delays
const PARALLEL_PRODUCTS = 1 // Sequential processing - API can't handle parallel load
const MAX_RETRIES = 3 // Reduced from 5 to speed up
const RETRY_DELAY_BASE = 5000 // 5s base delay

interface ProductSync {
  stockxProductId: string
  sku: string
  brand: string
}

interface SyncResult {
  sku: string
  success: boolean
  retries: number
  dataQuality: {
    totalRows: number
    uniqueSizes: number
    regionsComplete: string[]
    hasDuplicates: boolean
    pricesInCents: boolean
  }
}

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

async function verifyProductData(stockxProductId: string): Promise<SyncResult['dataQuality']> {
  const { data } = await supabase
    .from('master_market_data')
    .select('id, size_key, region_code, currency_code, lowest_ask, is_flex, is_consigned, provider_source')
    .eq('provider', 'stockx')
    .eq('provider_product_id', stockxProductId)

  const regions = new Set(data?.map(r => r.region_code).filter(Boolean))
  const uniqueSizes = new Set(data?.map(r => r.size_key).filter(Boolean))
  const uniqueCombinations = new Set(
    data?.map(r => `${r.region_code}|${r.size_key}|${r.is_flex}|${r.is_consigned}|${r.provider_source}`)
  )

  const hasDuplicates = uniqueCombinations.size !== (data?.length || 0)
  const pricesInCents = data?.every(r => !r.lowest_ask || r.lowest_ask >= 1000) || false

  return {
    totalRows: data?.length || 0,
    uniqueSizes: uniqueSizes.size,
    regionsComplete: Array.from(regions),
    hasDuplicates,
    pricesInCents,
  }
}

async function syncSingleProduct(
  product: ProductSync,
  attempt: number = 1
): Promise<SyncResult> {
  const result: SyncResult = {
    sku: product.sku,
    success: false,
    retries: attempt - 1,
    dataQuality: {
      totalRows: 0,
      uniqueSizes: 0,
      regionsComplete: [],
      hasDuplicates: false,
      pricesInCents: true,
    },
  }

  // Sync all 3 regions at once (function handles sequential syncing internally)
  let allRegionsSucceeded = true

  try {
    const syncResult = await syncProductAllRegions(
      undefined,
      product.stockxProductId,
      'UK',  // Primary region
      true   // ✅ FIXED: Enable secondary region syncing (EU, US)
    )

    if (!syncResult.success) {
      console.error(`  ❌ Multi-region sync FAILED:`, syncResult.primaryResult.error || 'Unknown error')
      allRegionsSucceeded = false
    }

    // Check secondary results
    for (const [currency, result] of Object.entries(syncResult.secondaryResults)) {
      if (!result.success) {
        console.error(`  ❌ ${currency} region FAILED:`, result.error || 'Unknown error')
        allRegionsSucceeded = false
      }
    }
  } catch (error: any) {
    console.error(`  ❌ EXCEPTION:`, error.message || error)
    allRegionsSucceeded = false
  }

  // Verify data quality in database
  const dataQuality = await verifyProductData(product.stockxProductId)
  result.dataQuality = dataQuality

  // Check if data is good
  const hasAllRegions = dataQuality.regionsComplete.length === 3
  const noDuplicates = !dataQuality.hasDuplicates
  const goodPrices = dataQuality.pricesInCents

  if (hasAllRegions && noDuplicates && goodPrices && allRegionsSucceeded) {
    result.success = true
  } else if (dataQuality.totalRows > 0 && attempt < MAX_RETRIES) {
    // Data exists but has quality issues - retry
    const retryDelay = RETRY_DELAY_BASE * Math.pow(2, attempt - 1)
    await sleep(retryDelay)
    return syncSingleProduct(product, attempt + 1)
  } else if (dataQuality.totalRows === 0 && attempt < MAX_RETRIES) {
    // No data - retry
    const retryDelay = RETRY_DELAY_BASE * Math.pow(2, attempt - 1)
    await sleep(retryDelay)
    return syncSingleProduct(product, attempt + 1)
  }

  return result
}

async function main() {
  console.log('╔═══════════════════════════════════════════════════════════════════════╗')
  console.log('║      Comprehensive Sync - Sequential with Timeout Protection        ║')
  console.log('╚═══════════════════════════════════════════════════════════════════════╝\n')

  const startTime = Date.now()

  // ============================================================================
  // PHASE 1: CLEANUP
  // ============================================================================

  console.log('PHASE 1: Deleting all StockX data...\n')

  const { count: beforeCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('provider', 'stockx')

  console.log(`Current rows: ${beforeCount}`)

  const { error: deleteError } = await supabase
    .from('master_market_data')
    .delete()
    .eq('provider', 'stockx')

  if (deleteError) {
    console.error('❌ Failed to delete:', deleteError)
    process.exit(1)
  }

  console.log(`✅ Deleted ${beforeCount} rows\n`)
  console.log('═'.repeat(75) + '\n')

  // ============================================================================
  // PHASE 2: SEQUENTIAL SYNC WITH TIMEOUT PROTECTION
  // ============================================================================

  console.log('PHASE 2: Sequential sync with timeout protection\n')

  // Fetch all products
  const { data: allProducts } = await supabase
    .from('stockx_products')
    .select('stockx_product_id, style_id, brand')
    .order('style_id')

  if (!allProducts) {
    console.error('❌ Failed to fetch products')
    process.exit(1)
  }

  const productsToSync: ProductSync[] = allProducts.map((p) => ({
    stockxProductId: p.stockx_product_id,
    sku: p.style_id,
    brand: p.brand || 'Unknown',
  }))

  console.log(`Total products: ${productsToSync.length}`)
  console.log(`Processing: Sequential (1 at a time)`)
  console.log(`Multi-region sync: UK → EU → US (with 2s delays between regions)`)
  console.log(`Estimated time: ~${Math.ceil((productsToSync.length * 20) / 60)} minutes (20s avg per product)\n`)
  console.log('═'.repeat(75) + '\n')

  const results: SyncResult[] = []
  let perfectCount = 0
  let failureCount = 0

  // Process products sequentially (PARALLEL_PRODUCTS = 1)
  for (let i = 0; i < productsToSync.length; i += PARALLEL_PRODUCTS) {
    const batch = productsToSync.slice(i, i + PARALLEL_PRODUCTS)
    const productNum = i + 1
    const totalProducts = productsToSync.length

    console.log(`\n[Product ${productNum}/${totalProducts}] ${batch[0].sku}`)

    // Sync batch in parallel
    const batchResults = await Promise.all(
      batch.map(product => syncSingleProduct(product))
    )

    results.push(...batchResults)

    // Update counters
    for (const result of batchResults) {
      if (result.success && !result.dataQuality.hasDuplicates && result.dataQuality.pricesInCents) {
        perfectCount++
        console.log(`  ✅ ${result.sku}`)
      } else {
        failureCount++
        console.log(`  ❌ ${result.sku}`)
      }
    }

    console.log(`Progress: ${perfectCount}/${i + batch.length} perfect (${((perfectCount / (i + batch.length)) * 100).toFixed(1)}%)`)

    // Checkpoint at 10, 25, 50, 75, 100
    const productsSoFar = i + batch.length
    if ([10, 25, 50, 75, 100].includes(productsSoFar)) {
      console.log('\n' + '═'.repeat(75))
      console.log(`📊 CHECKPOINT: ${productsSoFar} PRODUCTS`)

      const { data: checkpointData } = await supabase
        .from('master_market_data')
        .select('provider_product_id')
        .eq('provider', 'stockx')

      const uniqueProducts = new Set(checkpointData?.map(r => r.provider_product_id))
      console.log(`   Database: ${uniqueProducts.size} unique products`)
      console.log(`   Success rate: ${((perfectCount / productsSoFar) * 100).toFixed(1)}%`)
      console.log('═'.repeat(75) + '\n')
    }

    // Short delay before next batch
    if (i + PARALLEL_PRODUCTS < productsToSync.length) {
      await sleep(DELAY_BETWEEN_PRODUCTS)
    }
  }

  const totalDuration = ((Date.now() - startTime) / 1000 / 60).toFixed(1)

  // ============================================================================
  // FINAL VERIFICATION
  // ============================================================================

  console.log('\n' + '═'.repeat(75))
  console.log('FINAL VERIFICATION\n')

  const { data: finalData } = await supabase
    .from('master_market_data')
    .select('*')
    .eq('provider', 'stockx')

  const uniqueProducts = new Set(finalData?.map(r => r.provider_product_id))
  const totalRows = finalData?.length || 0
  const uniqueCombinations = new Set(
    finalData?.map(r => `${r.provider_product_id}|${r.region_code}|${r.size_key}|${r.is_flex}|${r.is_consigned}|${r.provider_source}`)
  )
  const hasDuplicates = uniqueCombinations.size !== totalRows
  const pricesInCents = finalData?.filter(r => r.lowest_ask && r.lowest_ask >= 1000).length || 0
  const pricesInDollars = finalData?.filter(r => r.lowest_ask && r.lowest_ask < 1000 && r.lowest_ask > 0).length || 0

  console.log(`Total products: ${allProducts.length}`)
  console.log(`Successfully synced: ${uniqueProducts.size}`)
  console.log(`Coverage: ${((uniqueProducts.size / allProducts.length) * 100).toFixed(1)}%`)
  console.log(`Total rows: ${totalRows}`)
  console.log(`\nData Quality:`)
  console.log(`  Duplicates: ${hasDuplicates ? '❌ YES' : '✅ NO'}`)
  console.log(`  Prices in cents: ${pricesInCents} rows ✅`)
  console.log(`  Prices in dollars: ${pricesInDollars} rows ${pricesInDollars > 0 ? '❌' : '✅'}`)
  console.log(`\nSync Results:`)
  console.log(`  Perfect: ${perfectCount}`)
  console.log(`  Failed: ${failureCount}`)
  console.log(`  Duration: ${totalDuration} minutes`)
  console.log(`  Success rate: ${((perfectCount / productsToSync.length) * 100).toFixed(1)}%`)

  if (failureCount > 0) {
    console.log(`\n❌ Failed Products:`)
    results
      .filter((r) => !r.success)
      .slice(0, 10)
      .forEach((r, i) => {
        console.log(`  ${i + 1}. ${r.sku}`)
      })
  }

  console.log('\n' + '═'.repeat(75))

  if (perfectCount === productsToSync.length && !hasDuplicates && pricesInDollars === 0) {
    console.log('\n✅ 100% SUCCESS - PERFECT DATA QUALITY!\n')
  } else {
    console.log(`\n⚠️  ${failureCount} products with issues\n`)
  }
}

main().catch(console.error)
