#!/usr/bin/env npx tsx
/**
 * Test Downsampling - Verify SQL functions work correctly
 *
 * Creates fake old data, runs downsampling, verifies results
 */

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

async function main() {
  console.log('🧪 Testing Downsampling Functions\n')

  // Step 1: Create fake old hourly data (3 months + 1 day ago)
  const oldDate = new Date()
  oldDate.setMonth(oldDate.getMonth() - 3)
  oldDate.setDate(oldDate.getDate() - 1)

  console.log(`Creating fake hourly data for date: ${oldDate.toISOString().split('T')[0]}`)

  const fakeData = []
  for (let hour = 0; hour < 24; hour++) {
    const timestamp = new Date(oldDate)
    timestamp.setHours(hour)

    fakeData.push({
      sku: 'TEST-SKU-123',
      size_key: 'US 10',
      size_numeric: 10,
      provider: 'alias',
      provider_source: 'alias_availabilities',
      region_code: 'UK',
      currency_code: 'USD',
      snapshot_at: timestamp.toISOString(),
      lowest_ask: 100 + Math.random() * 10,
      highest_bid: 90 + Math.random() * 10,
      last_sale_price: 95 + Math.random() * 10,
      ask_count: 50,
      bid_count: 30,
      is_flex: false,
      is_consigned: false,
    })
  }

  const { error: insertError } = await supabase
    .from('master_market_data')
    .insert(fakeData)

  if (insertError) {
    console.error('Failed to insert fake data:', insertError.message)
    return
  }

  console.log(`✅ Inserted 24 fake hourly snapshots\n`)

  // Step 2: Run downsampling
  console.log('Running downsample_to_daily()...')

  const cutoffDate = oldDate.toISOString().split('T')[0]
  const { data: rowsCreated, error: downsampleError } = await supabase
    .rpc('downsample_to_daily', { cutoff_date: cutoffDate })

  if (downsampleError) {
    console.error('Downsampling failed:', downsampleError.message)
    return
  }

  console.log(`✅ Created ${rowsCreated} daily aggregate row(s)\n`)

  // Step 3: Verify the results
  const { data: dailyData } = await supabase
    .from('master_market_data_daily')
    .select('*')
    .eq('sku', 'TEST-SKU-123')

  if (!dailyData || dailyData.length === 0) {
    console.error('❌ No daily data found!')
    return
  }

  console.log('📊 Daily Aggregate Result:')
  const daily = dailyData[0]
  console.log(`  Date: ${daily.date}`)
  console.log(`  Sample Count: ${daily.sample_count} (should be 24)`)
  console.log(`  Avg Lowest Ask: $${daily.avg_lowest_ask.toFixed(2)}`)
  console.log(`  Min Lowest Ask: $${daily.min_lowest_ask.toFixed(2)}`)
  console.log(`  Max Lowest Ask: $${daily.max_lowest_ask.toFixed(2)}`)

  // Step 4: Check hourly data was deleted
  const { count: hourlyCount } = await supabase
    .from('master_market_data')
    .select('*', { count: 'exact', head: true })
    .eq('sku', 'TEST-SKU-123')

  console.log(`\n✅ Hourly data deleted: ${hourlyCount === 0 ? 'YES' : `NO (${hourlyCount} remain)`}`)

  // Step 5: Cleanup
  await supabase
    .from('master_market_data_daily')
    .delete()
    .eq('sku', 'TEST-SKU-123')

  await supabase
    .from('master_market_data')
    .delete()
    .eq('sku', 'TEST-SKU-123')

  console.log('\n🎉 Downsampling test PASSED!\n')
  console.log('The SQL functions work correctly. They will automatically run:')
  console.log('  - Monthly (1st of month) via /api/cron/downsample-data')
  console.log('  - Downsample data older than 3 months → daily')
  console.log('  - Downsample data older than 1 year → weekly')
  console.log('')
}

main().catch(console.error)
