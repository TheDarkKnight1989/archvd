#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js';

const SKU = 'II1493-600';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function test() {
  console.log('🔍 FULL STOCKX SYNC TEST - SKU:', SKU);
  console.log('='.repeat(80));

  // Check catalog
  const { data: products } = await supabase
    .from('product_catalog')
    .select('id, sku, stockx_product_id')
    .eq('sku', SKU);

  console.log('\n📦 Catalog lookup:');
  if (!products || products.length === 0) {
    console.log('   ❌ No products found for', SKU);
    return;
  }

  console.log('   Found', products.length, 'product(s)');
  products.forEach(p => {
    console.log('   - ID:', p.id, '| StockX ID:', p.stockx_product_id || 'NULL');
  });

  const product = products[0];
  if (!product.stockx_product_id) {
    console.log('\n❌ No stockx_product_id');
    return;
  }

  console.log('\n' + '='.repeat(80));
  console.log('🔄 RUNNING SYNC...\n');

  const { refreshStockxMarketData } = await import('../src/lib/services/stockx/market-refresh.ts');

  const result = await refreshStockxMarketData(
    undefined,
    product.stockx_product_id,
    'GBP'
  );

  console.log('\n' + '='.repeat(80));
  console.log('📊 FULL API RESPONSE:\n');
  console.log(JSON.stringify(result, null, 2));

  // Check database
  if (result.success) {
    console.log('\n' + '='.repeat(80));
    console.log('💾 DATABASE CHECK:\n');

    const { data: rows, error } = await supabase
      .from('master_market_data')
      .select('*')
      .eq('provider', 'stockx')
      .eq('sku', SKU)
      .order('size_numeric', { ascending: true });

    if (error) {
      console.log('❌ Query error:', error.message);
    } else if (!rows || rows.length === 0) {
      console.log('❌ No rows in master_market_data');
    } else {
      console.log('✅ Found', rows.length, 'rows in master_market_data\n');
      console.log('First 5 rows:');
      rows.slice(0, 5).forEach(row => {
        console.log('  Size', row.size_key, '| Ask:', row.lowest_ask, '| Sales:', row.sales_last_30d, '| Flex:', row.is_flex);
      });
    }
  }
}

test().catch(err => {
  console.error('\n❌ FATAL ERROR:', err.message);
  console.error(err.stack);
  process.exit(1);
});
